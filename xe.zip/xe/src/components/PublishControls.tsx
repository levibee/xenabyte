
import { useState } from "react";

export default function PublishControls() {
  const [username, setUsername] = useState("");
  const [publishing, setPublishing] = useState(false);
  const [publishedUrl, setPublishedUrl] = useState("");

  const handlePreview = () => {
    window.open("/dist/index.html", "_blank");
  };

  const handlePublish = async () => {
    setPublishing(true);
    const res = await fetch("/api/publish", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username }),
    });
    const data = await res.json();
    setPublishedUrl(data.url);
    setPublishing(false);
  };

  return (
    <div className="p-6 bg-white rounded-xl shadow-lg space-y-4 max-w-md mx-auto">
      <h2 className="text-xl font-semibold">Publish Your Site</h2>
      <input
        type="text"
        placeholder="Enter your username"
        value={username}
        onChange={(e) => setUsername(e.target.value)}
        className="border p-2 w-full rounded-md"
      />
      <button onClick={handlePreview} className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600">
        Preview My Site
      </button>
      <button
        onClick={handlePublish}
        disabled={publishing || !username}
        className="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700 disabled:opacity-50"
      >
        {publishing ? "Publishing..." : "Publish Now"}
      </button>

      {publishedUrl && (
        <div className="mt-4 text-green-700">
          ✅ Site published at:{" "}
          <a href={publishedUrl} className="underline text-blue-600" target="_blank" rel="noopener noreferrer">
            {publishedUrl}
          </a>
        </div>
      )}
    </div>
  );
}
