
const express = require('express');
const fs = require('fs-extra');
const path = require('path');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

// Change this path to match your real server structure where you serve static files
const DIST_DIR = path.join(__dirname, 'dist');
const PUBLISH_ROOT = path.join(__dirname, 'public', 'sites');

app.post('/api/publish', async (req, res) => {
  const { username } = req.body;
  if (!username || !/^[a-zA-Z0-9_-]+$/.test(username)) {
    return res.status(400).json({ error: 'Invalid username' });
  }

  const userDir = path.join(PUBLISH_ROOT, username);

  try {
    await fs.ensureDir(userDir);
    await fs.copy(DIST_DIR, userDir, { overwrite: true });

    const publicUrl = `https://www.xenabyte.com/sites/${username}/index.html`;
    res.json({ url: publicUrl });
  } catch (error) {
    console.error("Publishing failed:", error);
    res.status(500).json({ error: 'Publishing failed' });
  }
});

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => {
  console.log(`✅ Publish server running at http://localhost:${PORT}`);
});
