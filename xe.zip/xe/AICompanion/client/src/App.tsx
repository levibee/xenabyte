import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ThemeProvider } from "next-themes";
import NotFound from "@/pages/not-found";
import Home from "@/pages/home";
import Builder from "@/pages/builder";
import AIBuilder from "@/pages/ai-builder";
import AIBuilderResult from "@/pages/ai-builder-result";
import AdminDashboard from "@/pages/admin-dashboard";
import Signup from "@/pages/signup";
import Pricing from "@/pages/pricing";
import Templates from "@/pages/templates";
import Domains from "@/pages/domains";
import Navbar from "@/components/shared/navbar";
import Footer from "@/components/shared/footer";
import Chatbot from "@/components/shared/chatbot";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/builder" component={Builder} />
      <Route path="/ai-builder" component={AIBuilder} />
      <Route path="/ai-builder-result" component={AIBuilderResult} />
      <Route path="/admin" component={AdminDashboard} />
      <Route path="/admin/dashboard" component={AdminDashboard} />
      <Route path="/signup" component={Signup} />
      <Route path="/pricing" component={Pricing} />
      <Route path="/templates" component={Templates} />
      <Route path="/domains" component={Domains} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider attribute="class" defaultTheme="dark">
        <TooltipProvider>
          <div className="min-h-screen flex flex-col">
            <Navbar />
            <Router />
            <Footer />
            <Chatbot />
          </div>
          <Toaster />
        </TooltipProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;
