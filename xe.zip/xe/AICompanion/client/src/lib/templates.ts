import { Template } from "@/types";

// Define stock template library
export const templates: Template[] = [
  {
    id: 1,
    name: "Portfolio",
    description: "Perfect for showcasing your work and skills",
    popularity: "high",
    thumbnail: "https://images.unsplash.com/photo-1467232004584-a241de8bcf5d?auto=format&fit=crop&w=600&h=400&q=80",
    defaultSections: [
      {
        id: 1,
        type: "hero",
        title: "Hero Section",
        heading: "Hello, I'm a Creative Professional",
        subheading: "Specializing in web design and development",
        content: "Showcase your best work and skills with this clean portfolio template.",
      },
      {
        id: 2,
        type: "features",
        title: "My Skills",
        features: ["Web Design", "Frontend Development", "UI/UX Design", "Brand Identity"],
      },
      {
        id: 3,
        type: "gallery",
        title: "Recent Projects",
        items: [
          { title: "Project 1", description: "Description of project 1" },
          { title: "Project 2", description: "Description of project 2" },
          { title: "Project 3", description: "Description of project 3" },
        ],
      },
      {
        id: 4,
        type: "contact",
        title: "Contact Me",
        content: "Get in touch for collaborations and projects.",
      },
    ],
  },
  {
    id: 2,
    name: "Business",
    description: "Professional layout for companies and services",
    popularity: "high",
    thumbnail: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=600&h=400&q=80",
    defaultSections: [
      {
        id: 1,
        type: "hero",
        title: "Hero Section",
        heading: "Grow Your Business with Us",
        subheading: "Professional solutions for your needs",
        content: "We help businesses like yours thrive in today's competitive market.",
      },
      {
        id: 2,
        type: "features",
        title: "Our Services",
        features: ["Strategic Consulting", "Marketing & Branding", "Business Development", "Financial Analysis"],
      },
      {
        id: 3,
        type: "testimonials",
        title: "What Our Clients Say",
        items: [
          { title: "John Doe", description: "CEO, Company Inc.", content: "Working with them has transformed our business." },
          { title: "Jane Smith", description: "Marketing Director, Brand Co.", content: "Exceptional service and results." },
        ],
      },
      {
        id: 4,
        type: "contact",
        title: "Get in Touch",
        content: "Ready to take your business to the next level? Contact us today.",
      },
    ],
  },
  {
    id: 3,
    name: "Blog",
    description: "Clean design focused on content and readability",
    popularity: "medium",
    thumbnail: "https://images.unsplash.com/photo-1499750310107-5fef28a66643?auto=format&fit=crop&w=600&h=400&q=80",
    defaultSections: [
      {
        id: 1,
        type: "hero",
        title: "Hero Section",
        heading: "Insights & Ideas",
        subheading: "A blog about thoughtful content",
        content: "Explore the latest articles, guides, and thought pieces.",
      },
      {
        id: 2,
        type: "features",
        title: "Featured Categories",
        features: ["Technology", "Design", "Business", "Lifestyle"],
      },
      {
        id: 3,
        type: "content",
        title: "Latest Articles",
        content: "Here you'll find our most recent blog posts and updates.",
      },
      {
        id: 4,
        type: "content",
        title: "Newsletter Signup",
        content: "Subscribe to our newsletter for regular updates.",
      },
    ],
  },
  {
    id: 4,
    name: "E-commerce",
    description: "Complete shop layout with product displays",
    popularity: "high",
    thumbnail: "https://images.unsplash.com/photo-1472851294608-062f824d29cc?auto=format&fit=crop&w=600&h=400&q=80",
    defaultSections: [
      {
        id: 1,
        type: "hero",
        title: "Hero Section",
        heading: "Shop the Latest Products",
        subheading: "Quality items for every need",
        content: "Discover our curated collection of products at competitive prices.",
      },
      {
        id: 2,
        type: "features",
        title: "Why Shop With Us",
        features: ["Free Shipping", "30-Day Returns", "Secure Checkout", "Quality Guarantee"],
      },
      {
        id: 3,
        type: "gallery",
        title: "Featured Products",
        items: [
          { title: "Product 1", description: "$99.99" },
          { title: "Product 2", description: "$149.99" },
          { title: "Product 3", description: "$79.99" },
          { title: "Product 4", description: "$199.99" },
        ],
      },
      {
        id: 4,
        type: "content",
        title: "Special Offers",
        content: "Limited time deals and special promotions for our customers.",
      },
    ],
  },
  {
    id: 5,
    name: "Landing Page",
    description: "Conversion-focused design with clear CTAs",
    popularity: "medium",
    thumbnail: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&w=600&h=400&q=80",
    defaultSections: [
      {
        id: 1,
        type: "hero",
        title: "Hero Section",
        heading: "The Perfect Solution",
        subheading: "For your specific needs",
        content: "Discover how our product can solve your problems and make your life easier.",
      },
      {
        id: 2,
        type: "features",
        title: "Key Benefits",
        features: ["Time-Saving", "Cost-Effective", "Easy to Use", "Reliable Support"],
      },
      {
        id: 3,
        type: "content",
        title: "How It Works",
        content: "A simple three-step process to get started and see results quickly.",
      },
      {
        id: 4,
        type: "testimonials",
        title: "Customer Testimonials",
        items: [
          { title: "Sarah Johnson", description: "Happy Customer", content: "This product exceeded my expectations!" },
          { title: "Mark Williams", description: "Loyal User", content: "I can't imagine working without it now." },
        ],
      },
    ],
  },
  {
    id: 6,
    name: "Documentation",
    description: "Organized structure for technical content",
    popularity: "low",
    thumbnail: "https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&w=600&h=400&q=80",
    defaultSections: [
      {
        id: 1,
        type: "hero",
        title: "Hero Section",
        heading: "Product Documentation",
        subheading: "Everything you need to know",
        content: "Comprehensive guides and documentation for our product and services.",
      },
      {
        id: 2,
        type: "features",
        title: "Documentation Sections",
        features: ["Getting Started", "API Reference", "Tutorials", "Troubleshooting"],
      },
      {
        id: 3,
        type: "content",
        title: "Quick Start Guide",
        content: "Follow these steps to get up and running quickly with our product.",
      },
      {
        id: 4,
        type: "content",
        title: "Resources",
        content: "Additional resources and support options for advanced users.",
      },
    ],
  },
];

export function getTemplateById(id: number | null): Template | null {
  if (!id) return null;
  return templates.find(template => template.id === id) || null;
}
