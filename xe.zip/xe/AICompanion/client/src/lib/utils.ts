import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";
import { WebsiteData } from "@/types";
 
export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function generateHtmlCode(websiteData: WebsiteData): string {
  const { content, style, settings } = websiteData;
  
  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${content.siteName}</title>
  <meta name="description" content="${settings.seo.metaDescription}">
  <link href="https://fonts.googleapis.com/css2?family=${style.fonts.heading.replace(' ', '+')}:wght@300;400;500;600;700&family=${style.fonts.body.replace(' ', '+')}:wght@300;400;500&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <header>
    <div class="container">
      <div class="logo">
        <span>${content.siteName}</span>
      </div>
      <nav>
        <a href="#" class="active">Home</a>
        <a href="#">Features</a>
        <a href="#">About</a>
        <a href="#">Contact</a>
      </nav>
      <button class="btn-primary">Get Started</button>
    </div>
  </header>

  <main>
    <section class="hero">
      <div class="container">
        <div class="hero-content">
          <h1>${content.sections.find(s => s.type === 'hero')?.heading || 'Welcome to our website'} <span>${content.sections.find(s => s.type === 'hero')?.subheading || 'Made with WebGen AI'}</span></h1>
          <p>${content.tagline}</p>
          <div class="buttons">
            <a href="#" class="btn-primary">Get started</a>
            <a href="#" class="btn-secondary">Learn more</a>
          </div>
        </div>
        <div class="hero-image">
          <img src="assets/hero-image.jpg" alt="Website Builder Demo">
        </div>
      </div>
    </section>

    <section class="features">
      <div class="container">
        <div class="section-header">
          <span>Features</span>
          <h2>${content.sections.find(s => s.type === 'features')?.title || 'Our Features'}</h2>
          <p>Everything you need to build amazing websites quickly and efficiently.</p>
        </div>

        <div class="features-grid">
          ${(content.sections.find(s => s.type === 'features')?.features || []).map(feature => `
          <div class="feature-card">
            <div class="icon">
              <i class="icon-feature"></i>
            </div>
            <h3>${feature}</h3>
            <p>Description of this amazing feature of your website.</p>
          </div>
          `).join('')}
        </div>
      </div>
    </section>
  </main>

  <footer>
    <div class="container">
      <div class="footer-content">
        <div class="footer-logo">
          <span>${content.siteName}</span>
          <p>${content.tagline}</p>
        </div>
        ${settings.components.socialLinks ? `
        <div class="social-links">
          <a href="#" aria-label="Facebook"><i class="icon-facebook"></i></a>
          <a href="#" aria-label="Twitter"><i class="icon-twitter"></i></a>
          <a href="#" aria-label="Instagram"><i class="icon-instagram"></i></a>
        </div>
        ` : ''}
      </div>
      <div class="footer-bottom">
        <p>&copy; ${new Date().getFullYear()} ${content.siteName}. All rights reserved.</p>
        <div class="footer-links">
          <a href="#">Privacy Policy</a>
          <a href="#">Terms of Service</a>
          <a href="#">Cookie Policy</a>
        </div>
      </div>
    </div>
  </footer>

  <script src="script.js"></script>
</body>
</html>`;
}

export function generateCssCode(websiteData: WebsiteData): string {
  const { style } = websiteData;
  
  return `/* Main Styles */
:root {
  --primary-color: ${style.colors.primary};
  --secondary-color: ${style.colors.secondary};
  --accent-color: ${style.colors.accent};
  --background-color: ${style.colors.background};
  --text-color: #333333;
  --heading-font: "${style.fonts.heading}", sans-serif;
  --body-font: "${style.fonts.body}", sans-serif;
}

* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

body {
  font-family: var(--body-font);
  color: var(--text-color);
  background-color: var(--background-color);
  line-height: 1.6;
}

.container {
  width: 100%;
  max-width: 1200px;
  margin: 0 auto;
  padding: 0 20px;
}

h1, h2, h3, h4, h5, h6 {
  font-family: var(--heading-font);
  font-weight: 700;
  line-height: 1.3;
}

a {
  text-decoration: none;
  color: var(--primary-color);
  transition: color 0.3s ease;
}

a:hover {
  color: var(--secondary-color);
}

.btn-primary {
  display: inline-block;
  background-color: var(--primary-color);
  color: white;
  padding: 12px 24px;
  border-radius: 6px;
  font-weight: 600;
  transition: background-color 0.3s ease;
  border: none;
  cursor: pointer;
}

.btn-primary:hover {
  background-color: var(--primary-color);
  opacity: 0.9;
}

.btn-secondary {
  display: inline-block;
  background-color: transparent;
  color: var(--primary-color);
  border: 2px solid var(--primary-color);
  padding: 12px 24px;
  border-radius: 6px;
  font-weight: 600;
  transition: all 0.3s ease;
  cursor: pointer;
}

.btn-secondary:hover {
  background-color: var(--primary-color);
  color: white;
}

/* Header */
header {
  background-color: white;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
  position: sticky;
  top: 0;
  z-index: 1000;
}

header .container {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 20px;
}

.logo {
  font-family: var(--heading-font);
  font-size: 24px;
  font-weight: 700;
}

nav {
  display: flex;
  gap: 24px;
}

nav a {
  color: #555;
  font-weight: 500;
}

nav a.active,
nav a:hover {
  color: var(--primary-color);
}

/* Hero Section */
.hero {
  padding: 80px 0;
  background-color: #f9fafb;
}

.hero .container {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 40px;
  align-items: center;
}

.hero-content h1 {
  font-size: 48px;
  margin-bottom: 20px;
}

.hero-content h1 span {
  color: var(--primary-color);
  display: block;
}

.hero-content p {
  font-size: 18px;
  color: #666;
  margin-bottom: 30px;
}

.buttons {
  display: flex;
  gap: 16px;
}

.hero-image img {
  width: 100%;
  border-radius: 10px;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
}

/* Features Section */
.features {
  padding: 80px 0;
}

.section-header {
  text-align: center;
  margin-bottom: 60px;
}

.section-header span {
  color: var(--primary-color);
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 1px;
}

.section-header h2 {
  font-size: 36px;
  margin: 10px 0;
}

.section-header p {
  max-width: 600px;
  margin: 0 auto;
  color: #666;
}

.features-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
  gap: 30px;
}

.feature-card {
  background-color: white;
  border-radius: 10px;
  padding: 30px;
  box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
  transition: transform 0.3s ease, box-shadow 0.3s ease;
}

.feature-card:hover {
  transform: translateY(-5px);
  box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
}

.feature-card .icon {
  width: 60px;
  height: 60px;
  background-color: var(--primary-color);
  color: white;
  border-radius: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 24px;
  margin-bottom: 20px;
}

.feature-card h3 {
  font-size: 20px;
  margin-bottom: 10px;
}

.feature-card p {
  color: #666;
}

/* Footer */
footer {
  background-color: #f9fafb;
  padding: 60px 0 20px;
  border-top: 1px solid #eee;
}

.footer-content {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  margin-bottom: 40px;
}

.footer-logo {
  font-family: var(--heading-font);
  font-size: 24px;
  font-weight: 700;
}

.footer-logo p {
  font-size: 14px;
  color: #666;
  margin-top: 10px;
  font-weight: normal;
}

.social-links {
  display: flex;
  gap: 16px;
}

.social-links a {
  width: 40px;
  height: 40px;
  border-radius: 50%;
  background-color: #eee;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: background-color 0.3s ease;
}

.social-links a:hover {
  background-color: var(--primary-color);
  color: white;
}

.footer-bottom {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding-top: 20px;
  border-top: 1px solid #eee;
}

.footer-bottom p {
  font-size: 14px;
  color: #666;
}

.footer-links {
  display: flex;
  gap: 20px;
}

.footer-links a {
  font-size: 14px;
  color: #666;
}

/* Responsive */
@media (max-width: 768px) {
  header .container {
    flex-direction: column;
    gap: 20px;
  }
  
  nav {
    width: 100%;
    justify-content: center;
  }
  
  .hero .container {
    grid-template-columns: 1fr;
  }
  
  .hero-content {
    text-align: center;
  }
  
  .buttons {
    justify-content: center;
  }
  
  .footer-content {
    flex-direction: column;
    gap: 20px;
  }
  
  .footer-bottom {
    flex-direction: column;
    gap: 10px;
    text-align: center;
  }
}`;
}

export function generateJsCode(websiteData: WebsiteData): string {
  const { settings } = websiteData;
  
  let jsCode = `// Main JavaScript file
document.addEventListener('DOMContentLoaded', function() {
  // Initialize the website
  console.log('Website initialized successfully!');
  
  // Mobile menu toggle
  const menuButton = document.querySelector('.menu-toggle');
  const mobileMenu = document.querySelector('nav');
  
  if (menuButton) {
    menuButton.addEventListener('click', function() {
      mobileMenu.classList.toggle('active');
    });
  }
`;

  // Add smooth scrolling if enabled
  if (settings.effects.smoothScroll) {
    jsCode += `
  // Smooth scrolling
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
      e.preventDefault();
      
      document.querySelector(this.getAttribute('href')).scrollIntoView({
        behavior: 'smooth'
      });
    });
  });`;
  }
  
  // Add fade-in animations if enabled
  if (settings.effects.fadeIn) {
    jsCode += `
  // Fade-in animations
  const fadeElements = document.querySelectorAll('.fade-in');
  
  const fadeInObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('visible');
        fadeInObserver.unobserve(entry.target);
      }
    });
  }, { threshold: 0.1 });
  
  fadeElements.forEach(element => {
    fadeInObserver.observe(element);
  });`;
  }
  
  // Add parallax effect if enabled
  if (settings.effects.parallax) {
    jsCode += `
  // Parallax scrolling
  const parallaxElements = document.querySelectorAll('.parallax');
  
  window.addEventListener('scroll', () => {
    const scrollY = window.scrollY;
    
    parallaxElements.forEach(element => {
      const speed = element.dataset.speed || 0.5;
      const yPos = -(scrollY * speed);
      element.style.transform = \`translateY(\${yPos}px)\`;
    });
  });`;
  }
  
  // Close the main function
  jsCode += `
});`;
  
  return jsCode;
}
