import { WebsiteData } from '@/types';

// Don't initialize Anthropic on the client side - we'll use API endpoints instead
export interface AIGeneratedWebsite {
  siteName: string;
  tagline: string;
  style: {
    colors: {
      primary: string;
      secondary: string;
      accent: string;
      background: string;
      text: string;
    };
    fonts: {
      heading: string;
      body: string;
    };
    layout: "standard" | "sidebar" | "minimal";
  };
  sections: Array<{
    type: string;
    title: string;
    content?: string;
    features?: string[];
    heading?: string;
    subheading?: string;
  }>;
}

export interface AIWebsiteResponse {
  designs: AIGeneratedWebsite[];
}

export async function generateWebsiteDesigns(prompt: string): Promise<AIWebsiteResponse> {
  try {
    // In a real implementation, make a request to our backend API endpoint
    // For now, use the mock data for display purposes
    // This will be replaced with actual API calls when the backend is connected
    
    // TODO: Replace with actual API call when backend is ready
    // const response = await fetch('/api/generate-website', {
    //   method: 'POST',
    //   headers: { 'Content-Type': 'application/json' },
    //   body: JSON.stringify({ prompt })
    // });
    // const data = await response.json();
    // return data;
    
    // For now, use mock data
    return getMockWebsiteDesigns(prompt);
  } catch (error) {
    console.error('Error generating website designs:', error);
    // Fallback to mock data in case of errors
    return getMockWebsiteDesigns(prompt);
  }
}

// Mock data in case the API key is not available
function getMockWebsiteDesigns(prompt: string): AIWebsiteResponse {
  // Extract keywords from the prompt to customize mock data
  const promptLower = prompt.toLowerCase();
  
  const businessType = promptLower.includes('restaurant') ? 'restaurant' :
                      promptLower.includes('dental') || promptLower.includes('dentist') ? 'dental' :
                      promptLower.includes('fitness') || promptLower.includes('gym') ? 'fitness' :
                      promptLower.includes('tech') || promptLower.includes('software') ? 'tech' :
                      'business';
  
  const colorPreference = promptLower.includes('blue') ? 'blue' :
                         promptLower.includes('green') ? 'green' :
                         promptLower.includes('red') ? 'red' :
                         promptLower.includes('purple') ? 'purple' :
                         'neutral';
  
  // Generate site name based on business type
  const generateSiteName = () => {
    switch (businessType) {
      case 'restaurant':
        return ['Gourmet Haven', 'Flavor Fusion', 'Culinary Corner'][Math.floor(Math.random() * 3)];
      case 'dental':
        return ['Bright Smile Dental', 'Perfect Teeth Clinic', 'Dental Wellness Center'][Math.floor(Math.random() * 3)];
      case 'fitness':
        return ['Peak Performance Fitness', 'Elevate Gym', 'FitLife Studio'][Math.floor(Math.random() * 3)];
      case 'tech':
        return ['Innovate Solutions', 'TechEdge Systems', 'Digital Frontier'][Math.floor(Math.random() * 3)];
      default:
        return ['Prestige Enterprises', 'Elite Services', 'Premier Solutions'][Math.floor(Math.random() * 3)];
    }
  };
  
  // Generate tagline based on business type
  const generateTagline = (name: string) => {
    switch (businessType) {
      case 'restaurant':
        return 'Culinary excellence in every bite';
      case 'dental':
        return 'Professional care for your brightest smile';
      case 'fitness':
        return 'Transform your body, elevate your life';
      case 'tech':
        return 'Innovative solutions for modern challenges';
      default:
        return 'Excellence in everything we do';
    }
  };
  
  // Generate color scheme based on preference
  const generateColors = () => {
    switch (colorPreference) {
      case 'blue':
        return {
          primary: '#3b82f6',
          secondary: '#60a5fa',
          accent: '#f59e0b',
          background: '#ffffff',
          text: '#1e293b'
        };
      case 'green':
        return {
          primary: '#10b981',
          secondary: '#34d399',
          accent: '#f59e0b',
          background: '#f8fafc',
          text: '#1e293b'
        };
      case 'red':
        return {
          primary: '#ef4444',
          secondary: '#f87171',
          accent: '#3b82f6',
          background: '#ffffff',
          text: '#1e293b'
        };
      case 'purple':
        return {
          primary: '#8b5cf6',
          secondary: '#a78bfa',
          accent: '#ec4899',
          background: '#ffffff',
          text: '#1e293b'
        };
      default:
        return {
          primary: '#475569',
          secondary: '#64748b',
          accent: '#0ea5e9',
          background: '#ffffff',
          text: '#1e293b'
        };
    }
  };
  
  // Generate mock sections based on business type
  const generateSections = () => {
    const commonSections = [
      {
        type: 'hero',
        title: 'Hero Section',
        heading: 'Welcome to Our Business',
        subheading: 'Professional services you can trust',
        content: 'We provide top-quality services to meet your needs.'
      },
      {
        type: 'features',
        title: 'Our Services',
        features: ['Professional Service', 'Quality Results', 'Customer Satisfaction', 'Trusted Expertise']
      }
    ];
    
    switch (businessType) {
      case 'restaurant':
        return [
          ...commonSections,
          {
            type: 'gallery',
            title: 'Our Menu',
            content: 'Explore our delicious offerings'
          },
          {
            type: 'testimonials',
            title: 'Customer Reviews',
            content: 'What our patrons say about us'
          }
        ];
      case 'dental':
        return [
          ...commonSections,
          {
            type: 'content',
            title: 'Our Approach',
            content: 'We focus on preventative care and patient comfort'
          },
          {
            type: 'contact',
            title: 'Book an Appointment',
            content: 'Schedule your visit today'
          }
        ];
      case 'fitness':
        return [
          ...commonSections,
          {
            type: 'gallery',
            title: 'Our Facilities',
            content: 'State-of-the-art equipment and spaces'
          },
          {
            type: 'content',
            title: 'Membership Plans',
            content: 'Find the right plan for your fitness journey'
          }
        ];
      default:
        return [
          ...commonSections,
          {
            type: 'content',
            title: 'About Us',
            content: 'Learn more about our company and mission'
          },
          {
            type: 'contact',
            title: 'Get in Touch',
            content: 'Contact us to learn more about our services'
          }
        ];
    }
  };
  
  // Generate 3 mock designs
  const designs: AIGeneratedWebsite[] = [];
  
  for (let i = 0; i < 3; i++) {
    const siteName = generateSiteName();
    designs.push({
      siteName,
      tagline: generateTagline(siteName),
      style: {
        colors: generateColors(),
        fonts: {
          heading: ['Inter', 'Montserrat', 'Poppins'][Math.floor(Math.random() * 3)],
          body: ['Inter', 'Roboto', 'Open Sans'][Math.floor(Math.random() * 3)]
        },
        layout: ['standard', 'minimal', 'sidebar'][i % 3] as "standard" | "sidebar" | "minimal"
      },
      sections: generateSections()
    });
  }
  
  return { designs };
}