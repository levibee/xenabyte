// Define component types for the website builder
export interface ComponentDefinition {
  id: string;
  name: string;
  description: string;
  category: "layout" | "content" | "media" | "interactive" | "form";
  icon: string;
  preview: string;
}

// Define component library
export const components: ComponentDefinition[] = [
  // Layout Components
  {
    id: "header",
    name: "Header",
    description: "Standard website header with navigation",
    category: "layout",
    icon: "layout",
    preview: `
      <header class="w-full bg-white p-4 shadow-md">
        <div class="flex justify-between items-center">
          <div class="font-bold text-xl">Logo</div>
          <nav class="flex gap-4">
            <a href="#" class="text-blue-600">Home</a>
            <a href="#" class="text-gray-600">About</a>
            <a href="#" class="text-gray-600">Services</a>
            <a href="#" class="text-gray-600">Contact</a>
          </nav>
        </div>
      </header>
    `,
  },
  {
    id: "footer",
    name: "Footer",
    description: "Standard website footer with links and copyright",
    category: "layout",
    icon: "layout",
    preview: `
      <footer class="w-full bg-gray-100 p-6">
        <div class="flex flex-col md:flex-row justify-between">
          <div class="mb-4 md:mb-0">
            <div class="font-bold text-lg mb-2">Company Name</div>
            <p class="text-sm text-gray-600">© 2023 All Rights Reserved</p>
          </div>
          <div class="grid grid-cols-2 md:grid-cols-3 gap-8">
            <div>
              <h3 class="font-semibold mb-2">Links</h3>
              <ul class="text-sm">
                <li><a href="#" class="text-gray-600">Home</a></li>
                <li><a href="#" class="text-gray-600">About</a></li>
                <li><a href="#" class="text-gray-600">Services</a></li>
                <li><a href="#" class="text-gray-600">Contact</a></li>
              </ul>
            </div>
            <div>
              <h3 class="font-semibold mb-2">Resources</h3>
              <ul class="text-sm">
                <li><a href="#" class="text-gray-600">Blog</a></li>
                <li><a href="#" class="text-gray-600">Documentation</a></li>
                <li><a href="#" class="text-gray-600">FAQ</a></li>
              </ul>
            </div>
            <div>
              <h3 class="font-semibold mb-2">Legal</h3>
              <ul class="text-sm">
                <li><a href="#" class="text-gray-600">Privacy Policy</a></li>
                <li><a href="#" class="text-gray-600">Terms of Service</a></li>
              </ul>
            </div>
          </div>
        </div>
      </footer>
    `,
  },
  {
    id: "hero",
    name: "Hero Section",
    description: "Large banner section with heading, text and CTA",
    category: "layout",
    icon: "layout",
    preview: `
      <section class="w-full bg-blue-600 text-white py-16 px-4">
        <div class="max-w-4xl mx-auto text-center">
          <h1 class="text-4xl font-bold mb-4">Welcome to Our Website</h1>
          <p class="text-xl mb-8">A brief description of what your company or service offers goes here.</p>
          <button class="bg-white text-blue-600 px-6 py-2 rounded-md font-medium">Get Started</button>
        </div>
      </section>
    `,
  },
  
  // Content Components
  {
    id: "text-block",
    name: "Text Block",
    description: "Standard text paragraph with heading",
    category: "content",
    icon: "type",
    preview: `
      <div class="max-w-3xl mx-auto p-4">
        <h2 class="text-2xl font-bold mb-4">Section Heading</h2>
        <p class="text-gray-700 mb-4">
          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam at dui augue. 
          Maecenas eu nisl eget massa iaculis ultricies. Vivamus condimentum tellus nec 
          ullamcorper tempor. Praesent pulvinar hendrerit felis a vulputate.
        </p>
        <p class="text-gray-700">
          Ut dignissim lectus velit, eget malesuada felis elementum a. Integer 
          elementum velit purus, et commodo sapien semper ut.
        </p>
      </div>
    `,
  },
  {
    id: "features",
    name: "Features List",
    description: "Grid of features with icons and descriptions",
    category: "content",
    icon: "list-checks",
    preview: `
      <div class="max-w-5xl mx-auto p-4">
        <h2 class="text-2xl font-bold text-center mb-8">Our Features</h2>
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div class="p-4 border rounded-lg">
            <div class="text-blue-500 mb-2">Icon</div>
            <h3 class="font-bold mb-2">Feature 1</h3>
            <p class="text-gray-600 text-sm">Description of this amazing feature and how it benefits the user.</p>
          </div>
          <div class="p-4 border rounded-lg">
            <div class="text-blue-500 mb-2">Icon</div>
            <h3 class="font-bold mb-2">Feature 2</h3>
            <p class="text-gray-600 text-sm">Description of this amazing feature and how it benefits the user.</p>
          </div>
          <div class="p-4 border rounded-lg">
            <div class="text-blue-500 mb-2">Icon</div>
            <h3 class="font-bold mb-2">Feature 3</h3>
            <p class="text-gray-600 text-sm">Description of this amazing feature and how it benefits the user.</p>
          </div>
        </div>
      </div>
    `,
  },
  
  // Media Components
  {
    id: "image",
    name: "Image",
    description: "Single responsive image with optional caption",
    category: "media",
    icon: "image",
    preview: `
      <div class="max-w-3xl mx-auto p-4">
        <figure>
          <img src="https://via.placeholder.com/800x400" alt="Placeholder" class="w-full rounded-lg">
          <figcaption class="text-sm text-gray-500 mt-2 text-center">Optional image caption</figcaption>
        </figure>
      </div>
    `,
  },
  {
    id: "gallery",
    name: "Image Gallery",
    description: "Grid of images with lightbox support",
    category: "media",
    icon: "grid",
    preview: `
      <div class="max-w-5xl mx-auto p-4">
        <h2 class="text-2xl font-bold mb-6">Image Gallery</h2>
        <div class="grid grid-cols-2 md:grid-cols-3 gap-4">
          <img src="https://via.placeholder.com/400x400" alt="Gallery image 1" class="w-full h-48 object-cover rounded-lg">
          <img src="https://via.placeholder.com/400x400" alt="Gallery image 2" class="w-full h-48 object-cover rounded-lg">
          <img src="https://via.placeholder.com/400x400" alt="Gallery image 3" class="w-full h-48 object-cover rounded-lg">
          <img src="https://via.placeholder.com/400x400" alt="Gallery image 4" class="w-full h-48 object-cover rounded-lg">
          <img src="https://via.placeholder.com/400x400" alt="Gallery image 5" class="w-full h-48 object-cover rounded-lg">
          <img src="https://via.placeholder.com/400x400" alt="Gallery image 6" class="w-full h-48 object-cover rounded-lg">
        </div>
      </div>
    `,
  },
  
  // Interactive Components
  {
    id: "testimonial",
    name: "Testimonials",
    description: "Customer testimonials with quotes and avatars",
    category: "interactive",
    icon: "quote",
    preview: `
      <div class="max-w-5xl mx-auto p-4">
        <h2 class="text-2xl font-bold text-center mb-8">What Our Customers Say</h2>
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div class="p-6 border rounded-lg">
            <div class="text-4xl text-blue-300 mb-4">"</div>
            <p class="text-gray-700 mb-4">This product completely transformed how we approach our work. The features and ease of use are unmatched in the industry.</p>
            <div class="flex items-center">
              <div class="w-10 h-10 bg-gray-300 rounded-full mr-3"></div>
              <div>
                <div class="font-semibold">Jane Doe</div>
                <div class="text-sm text-gray-500">CEO, Company Inc</div>
              </div>
            </div>
          </div>
          <div class="p-6 border rounded-lg">
            <div class="text-4xl text-blue-300 mb-4">"</div>
            <p class="text-gray-700 mb-4">I can't imagine running my business without this tool. It's become an essential part of our daily workflow.</p>
            <div class="flex items-center">
              <div class="w-10 h-10 bg-gray-300 rounded-full mr-3"></div>
              <div>
                <div class="font-semibold">John Smith</div>
                <div class="text-sm text-gray-500">Founder, Startup Ltd</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    `,
  },
  
  // Form Components
  {
    id: "contact-form",
    name: "Contact Form",
    description: "Standard contact form with name, email and message",
    category: "form",
    icon: "mail",
    preview: `
      <div class="max-w-3xl mx-auto p-4">
        <h2 class="text-2xl font-bold mb-6">Contact Us</h2>
        <form>
          <div class="mb-4">
            <label class="block text-gray-700 text-sm font-bold mb-2" for="name">Name</label>
            <input class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight" id="name" type="text" placeholder="Your name">
          </div>
          <div class="mb-4">
            <label class="block text-gray-700 text-sm font-bold mb-2" for="email">Email</label>
            <input class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight" id="email" type="email" placeholder="Your email">
          </div>
          <div class="mb-6">
            <label class="block text-gray-700 text-sm font-bold mb-2" for="message">Message</label>
            <textarea class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight" id="message" rows="4" placeholder="Your message"></textarea>
          </div>
          <div>
            <button class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded" type="button">
              Send Message
            </button>
          </div>
        </form>
      </div>
    `,
  },
];

export function getComponentsByCategory(category: string): ComponentDefinition[] {
  return components.filter(component => component.category === category);
}

export function getComponentById(id: string): ComponentDefinition | undefined {
  return components.find(component => component.id === id);
}
