import { apiRequest } from "./queryClient";

// Interface for image generation request
export interface ImageGenerationRequest {
  prompt: string;
  size?: "256x256" | "512x512" | "1024x1024" | "1024x1792" | "1792x1024";
  style?: "natural" | "vivid";
  quality?: "standard" | "hd";
}

// Interface for image generation response
export interface ImageGenerationResponse {
  url: string;
  generatedAt: string;
  prompt: string;
  size: string;
}

/**
 * Generates an image using AI based on the provided prompt
 * Requires OPENAI_API_KEY environment variable on the server
 */
export async function generateImage(options: ImageGenerationRequest): Promise<ImageGenerationResponse> {
  try {
    const response = await apiRequest("POST", "/api/generate-image", {
      prompt: options.prompt,
      size: options.size || "1024x1024",
      style: options.style || "vivid",
      quality: options.quality || "standard"
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(errorData.message || "Failed to generate image");
    }

    return await response.json();
  } catch (error: any) {
    console.error("Image generation error:", error);
    throw new Error(error.message || "Image generation failed");
  }
}

/**
 * Counts available image generation credits for the current user
 */
export async function getImageCredits(): Promise<{
  used: number;
  limit: number;
  remaining: number;
  resetDate: string;
}> {
  try {
    const response = await apiRequest("GET", "/api/image-credits");
    if (!response.ok) {
      throw new Error("Failed to fetch image credits");
    }
    return await response.json();
  } catch (error) {
    console.error("Error fetching image credits:", error);
    throw error;
  }
}