export interface Template {
  id: number;
  name: string;
  description: string;
  popularity: "low" | "medium" | "high";
  thumbnail: string;
  defaultSections: Section[];
}

export interface Section {
  id: number;
  type: "hero" | "features" | "content" | "gallery" | "testimonials" | "contact";
  title: string;
  heading?: string;
  subheading?: string;
  content?: string;
  image?: string;
  features?: string[];
  items?: { title: string; description: string; image?: string }[];
}

export interface WebsiteColors {
  primary: string;
  secondary: string;
  accent: string;
  background: string;
  text: string;
}

export interface WebsiteFonts {
  heading: string;
  body: string;
}

export interface WebsiteStyle {
  colors: WebsiteColors;
  fonts: WebsiteFonts;
  layout: "standard" | "sidebar" | "minimal";
}

export interface WebsiteContent {
  siteName: string;
  tagline: string;
  logo?: string;
  sections: Section[];
}

export interface WebsiteComponents {
  navigation: boolean;
  footer: boolean;
  contactForm: boolean;
  gallery: boolean;
  socialLinks: boolean;
}

export interface WebsiteEffects {
  parallax: boolean;
  fadeIn: boolean;
  smoothScroll: boolean;
}

export interface WebsiteSeo {
  metaTitle: string;
  metaDescription: string;
}

export interface WebsitePerformance {
  lazyLoading: boolean;
  minifyCode: boolean;
  caching: boolean;
}

export interface WebsiteSettings {
  components: WebsiteComponents;
  effects: WebsiteEffects;
  seo: WebsiteSeo;
  performance: WebsitePerformance;
}

export interface WebsiteData {
  templateId: number | null;
  style: WebsiteStyle;
  content: WebsiteContent;
  settings: WebsiteSettings;
}

// Schema types for API interfaces
export interface Website {
  id: number;
  userId: number;
  name: string;
  data: WebsiteData;
  created: string;
  updated: string;
}

export interface ExportedWebsite {
  id: number;
  websiteId: number;
  html: string;
  css: string;
  js: string;
  created: string;
}
