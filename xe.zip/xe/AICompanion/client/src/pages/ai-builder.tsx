import { useState } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/hooks/useAuth";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import {
  Brain,
  Laptop,
  Loader2,
  ArrowRight,
  RefreshCcw,
  Check,
  ChevronsUpDown,
  Sparkles,
  ImageIcon,
  Bot,
  Globe,
  LayoutGrid,
  Clock
} from "lucide-react";
import ImageGeneratorDialog from "@/components/image-generator/ImageGeneratorDialog";
import RequireAuthPrompt from "@/components/auth/RequireAuthPrompt";

import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import { Progress } from "@/components/ui/progress";

const siteCategories = [
  { value: "business", label: "Business/Corporate" },
  { value: "portfolio", label: "Portfolio" },
  { value: "ecommerce", label: "E-commerce" },
  { value: "blog", label: "Blog" },
  { value: "personal", label: "Personal" },
  { value: "event", label: "Event" },
  { value: "educational", label: "Educational" },
  { value: "nonprofit", label: "Non-profit" },
];

const colorSchemes = [
  { value: "modern", label: "Modern & Clean" },
  { value: "vibrant", label: "Vibrant & Colorful" },
  { value: "minimal", label: "Minimal & Elegant" },
  { value: "dark", label: "Dark Mode" },
  { value: "gradient", label: "Gradient-based" },
  { value: "corporate", label: "Corporate" },
  { value: "creative", label: "Creative & Artistic" },
];

const examplePrompts = [
  "A professional portfolio website for a photographer with a dark theme and minimal design",
  "A vibrant e-commerce site for a clothing brand with a focus on modern, urban fashion",
  "A clean business website for a tech startup with a gradient design and animated elements",
  "A blog for a food enthusiast with lots of image space and a warm color palette",
  "A non-profit organization website with a focus on environmental conservation",
];

export default function AIBuilder() {
  const [, navigate] = useLocation();
  const { isAuthenticated } = useAuth();
  const { toast } = useToast();
  const [prompt, setPrompt] = useState("");
  const [category, setCategory] = useState<string | undefined>();
  const [colorScheme, setColorScheme] = useState<string | undefined>();
  const [isGenerating, setIsGenerating] = useState(false);
  const [generationProgress, setGenerationProgress] = useState(0);
  const [generatedDesigns, setGeneratedDesigns] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [selectedDesign, setSelectedDesign] = useState<number | null>(null);
  const [generatedImages, setGeneratedImages] = useState<Record<string, string>>({});
  const [showLoginPrompt, setShowLoginPrompt] = useState(false);
  
  // Function to generate website designs using AI
  const handleGenerateWebsite = async () => {
    if (!prompt.trim()) {
      toast({
        title: "Please provide a description",
        description: "Tell us what kind of website you want to create",
        variant: "destructive",
      });
      return;
    }
    
    setIsGenerating(true);
    setGenerationProgress(0);
    
    // Simulate progress updates
    const progressInterval = setInterval(() => {
      setGenerationProgress(prev => {
        const newProgress = prev + Math.random() * 15;
        return newProgress >= 100 ? 99 : newProgress;
      });
    }, 1000);
    
    try {
      // Prepare the full prompt with any selected options
      let fullPrompt = prompt;
      if (category) {
        const categoryLabel = siteCategories.find(c => c.value === category)?.label;
        fullPrompt += ` | Category: ${categoryLabel}`;
      }
      if (colorScheme) {
        const schemeLabel = colorSchemes.find(c => c.value === colorScheme)?.label;
        fullPrompt += ` | Style: ${schemeLabel}`;
      }
      
      // Create website designs using AI
      const response = await apiRequest("POST", "/api/generate-website", {
        prompt: fullPrompt
      });
      
      if (!response.ok) {
        throw new Error("Failed to generate website");
      }
      
      const data = await response.json();
      setGeneratedDesigns(data.designs || []);
      setSelectedDesign(0); // Select first design by default
      
      // Store the generated website in localStorage
      if (data.designs?.length > 0) {
        localStorage.setItem('currentGeneratedWebsite', JSON.stringify(data.designs[0]));
      }
      
      clearInterval(progressInterval);
      setGenerationProgress(100);
      
      // Wait a moment to show 100% progress
      setTimeout(() => {
        setIsGenerating(false);
        navigate("/ai-builder-result");
      }, 500);
      
    } catch (error) {
      console.error("Generation error:", error);
      clearInterval(progressInterval);
      setIsGenerating(false);
      
      toast({
        title: "Generation failed",
        description: "There was a problem generating your website. Please try again.",
        variant: "destructive",
      });
    }
  };

  // Handle generated image from the image generator
  const handleImageGenerated = (section: string, imageUrl: string) => {
    setGeneratedImages(prev => ({
      ...prev,
      [section]: imageUrl
    }));
    
    toast({
      title: "Image added",
      description: `Your generated image has been added to the ${section} section`,
    });
  };

  // Select a design and navigate to preview
  const handleSelectDesign = (index: number) => {
    setSelectedDesign(index);
    localStorage.setItem('currentGeneratedWebsite', JSON.stringify(generatedDesigns[index]));
    navigate("/ai-builder-result");
  };

  // Use an example prompt
  const handleUseExample = (example: string) => {
    setPrompt(example);
  };

  return (
    <div className="container py-12">
      <div className="flex flex-col items-center text-center mb-12">
        <div className="inline-block bg-primary/10 p-3 rounded-full mb-4">
          <Brain className="h-8 w-8 text-primary" />
        </div>
        <h1 className="text-4xl md:text-5xl font-bold mb-4">AI Website Builder</h1>
        <p className="text-lg text-muted-foreground mb-6 max-w-3xl mx-auto">
          Describe the website you want to create, and our AI will generate a custom design for you in seconds.
        </p>
      </div>
      
      {isGenerating ? (
        <Card className="mb-10 max-w-3xl mx-auto">
          <CardHeader>
            <CardTitle>Generating Your Website</CardTitle>
            <CardDescription>
              Our AI is creating a custom website based on your description...
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Progress value={generationProgress} className="h-2" />
            <div className="grid grid-cols-3 gap-4 mt-6">
              <div className="bg-primary/5 rounded-lg p-4 flex flex-col items-center justify-center">
                <Bot className="h-10 w-10 text-primary/50 mb-2" />
                <div className="text-xs text-center text-muted-foreground">
                  <span className="block font-medium text-sm text-foreground">Understanding Prompt</span>
                  {generationProgress > 20 && <Check className="h-4 w-4 mx-auto mt-1 text-green-500" />}
                </div>
              </div>
              <div className="bg-primary/5 rounded-lg p-4 flex flex-col items-center justify-center">
                <LayoutGrid className="h-10 w-10 text-primary/50 mb-2" />
                <div className="text-xs text-center text-muted-foreground">
                  <span className="block font-medium text-sm text-foreground">Designing Layout</span>
                  {generationProgress > 50 && <Check className="h-4 w-4 mx-auto mt-1 text-green-500" />}
                </div>
              </div>
              <div className="bg-primary/5 rounded-lg p-4 flex flex-col items-center justify-center">
                <Globe className="h-10 w-10 text-primary/50 mb-2" />
                <div className="text-xs text-center text-muted-foreground">
                  <span className="block font-medium text-sm text-foreground">Creating Content</span>
                  {generationProgress > 80 && <Check className="h-4 w-4 mx-auto mt-1 text-green-500" />}
                </div>
              </div>
            </div>
          </CardContent>
          <CardFooter className="flex justify-end">
            <Button variant="outline" onClick={() => setIsGenerating(false)} disabled={generationProgress > 90}>
              Cancel
            </Button>
          </CardFooter>
        </Card>
      ) : (
        <Tabs defaultValue="prompt" className="max-w-3xl mx-auto">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="prompt">Text Prompt</TabsTrigger>
            <TabsTrigger value="guided">Guided Builder</TabsTrigger>
          </TabsList>
          
          <TabsContent value="prompt" className="space-y-4 pt-4">
            <Card>
              <CardHeader>
                <CardTitle>Describe Your Website</CardTitle>
                <CardDescription>
                  Tell us what kind of website you want, and our AI will generate it for you
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Textarea
                    placeholder="Describe the website you want to create. For example: 'A professional portfolio website for a photographer with dark theme and minimal design...'"
                    className="min-h-[120px] resize-none"
                    value={prompt}
                    onChange={(e) => setPrompt(e.target.value)}
                  />
                  <p className="text-xs text-muted-foreground">
                    Include details like purpose, style preferences, color schemes, and any specific sections you want
                  </p>
                </div>
                
                <Collapsible>
                  <CollapsibleTrigger asChild>
                    <div className="flex items-center justify-between cursor-pointer hover:bg-accent hover:text-accent-foreground px-2 py-1 rounded-md">
                      <span className="text-sm font-medium">Try example prompts</span>
                      <ChevronsUpDown className="h-4 w-4" />
                    </div>
                  </CollapsibleTrigger>
                  <CollapsibleContent className="space-y-2 mt-2">
                    {examplePrompts.map((example, index) => (
                      <div 
                        key={index}
                        className="p-2 rounded-md border hover:bg-accent hover:text-accent-foreground cursor-pointer"
                        onClick={() => handleUseExample(example)}
                      >
                        <p className="text-sm">{example}</p>
                      </div>
                    ))}
                  </CollapsibleContent>
                </Collapsible>
              </CardContent>
              <CardFooter className="flex justify-end">
                <Button 
                  onClick={handleGenerateWebsite} 
                  disabled={isGenerating || !prompt.trim()}
                  className="gap-2"
                >
                  {isGenerating ? (
                    <>
                      <Loader2 className="h-4 w-4 animate-spin" />
                      Creating...
                    </>
                  ) : (
                    <>
                      <Sparkles className="h-4 w-4" />
                      Generate Website
                    </>
                  )}
                </Button>
              </CardFooter>
            </Card>
            
            <Accordion type="single" collapsible className="w-full">
              <AccordionItem value="images">
                <AccordionTrigger>Add AI-Generated Images</AccordionTrigger>
                <AccordionContent className="space-y-6 pt-4">
                  <div className="grid gap-4 md:grid-cols-2">
                    <Card>
                      <CardHeader className="pb-2">
                        <CardTitle className="text-base flex items-center gap-2">
                          <ImageIcon className="h-4 w-4 text-primary" />
                          Hero Section Image
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="pt-0">
                        {generatedImages.hero ? (
                          <div className="aspect-video rounded-md overflow-hidden bg-muted mb-2">
                            <img 
                              src={generatedImages.hero} 
                              alt="Hero section" 
                              className="w-full h-full object-cover"
                            />
                          </div>
                        ) : (
                          <div className="aspect-video rounded-md bg-muted/50 flex flex-col items-center justify-center mb-2">
                            <ImageIcon className="h-10 w-10 text-muted-foreground/30" />
                            <p className="text-xs text-muted-foreground mt-2">Generate a hero image</p>
                          </div>
                        )}
                        
                        <ImageGeneratorDialog 
                          buttonLabel={generatedImages.hero ? "Regenerate Image" : "Generate Image"}
                          buttonVariant="outline"
                          defaultPrompt="Professional hero image for a website"
                          onImageGenerated={(url) => handleImageGenerated("hero", url)}
                        />
                      </CardContent>
                    </Card>
                    
                    <Card>
                      <CardHeader className="pb-2">
                        <CardTitle className="text-base flex items-center gap-2">
                          <ImageIcon className="h-4 w-4 text-primary" />
                          About Section Image
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="pt-0">
                        {generatedImages.about ? (
                          <div className="aspect-video rounded-md overflow-hidden bg-muted mb-2">
                            <img 
                              src={generatedImages.about} 
                              alt="About section" 
                              className="w-full h-full object-cover"
                            />
                          </div>
                        ) : (
                          <div className="aspect-video rounded-md bg-muted/50 flex flex-col items-center justify-center mb-2">
                            <ImageIcon className="h-10 w-10 text-muted-foreground/30" />
                            <p className="text-xs text-muted-foreground mt-2">Generate an image for the about section</p>
                          </div>
                        )}
                        
                        <ImageGeneratorDialog 
                          buttonLabel={generatedImages.about ? "Regenerate Image" : "Generate Image"}
                          buttonVariant="outline"
                          defaultPrompt="Professional image for about us section"
                          onImageGenerated={(url) => handleImageGenerated("about", url)}
                        />
                      </CardContent>
                    </Card>
                  </div>
                </AccordionContent>
              </AccordionItem>
            </Accordion>
          </TabsContent>
          
          <TabsContent value="guided" className="space-y-4 pt-4">
            <Card>
              <CardHeader>
                <CardTitle>Guided Website Builder</CardTitle>
                <CardDescription>
                  Configure your website step by step
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="category">Website Category</Label>
                    <Select value={category} onValueChange={setCategory}>
                      <SelectTrigger id="category">
                        <SelectValue placeholder="Select category" />
                      </SelectTrigger>
                      <SelectContent>
                        {siteCategories.map((category) => (
                          <SelectItem key={category.value} value={category.value}>
                            {category.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="colorScheme">Color Scheme</Label>
                    <Select value={colorScheme} onValueChange={setColorScheme}>
                      <SelectTrigger id="colorScheme">
                        <SelectValue placeholder="Select color scheme" />
                      </SelectTrigger>
                      <SelectContent>
                        {colorSchemes.map((scheme) => (
                          <SelectItem key={scheme.value} value={scheme.value}>
                            {scheme.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="description">Website Description</Label>
                  <Textarea
                    id="description"
                    placeholder="Describe the purpose and content of your website..."
                    className="min-h-[120px] resize-none"
                    value={prompt}
                    onChange={(e) => setPrompt(e.target.value)}
                  />
                </div>
                
                {/* More guided options could be added here */}
              </CardContent>
              <CardFooter className="flex justify-end">
                <Button
                  onClick={handleGenerateWebsite}
                  disabled={isGenerating || !prompt.trim()}
                  className="gap-2"
                >
                  {isGenerating ? (
                    <>
                      <Loader2 className="h-4 w-4 animate-spin" />
                      Creating...
                    </>
                  ) : (
                    <>
                      <Sparkles className="h-4 w-4" />
                      Generate Website
                    </>
                  )}
                </Button>
              </CardFooter>
            </Card>
          </TabsContent>
        </Tabs>
      )}
      
      {/* Features section */}
      <div className="pt-20 pb-10">
        <h2 className="text-2xl md:text-3xl font-bold text-center mb-10">
          Generate professional websites in minutes with AI
        </h2>
        
        <div className="grid md:grid-cols-3 gap-6">
          <Card className="bg-primary/5 border-0">
            <CardHeader>
              <div className="bg-primary/10 w-12 h-12 rounded-full flex items-center justify-center mb-2">
                <Sparkles className="h-6 w-6 text-primary" />
              </div>
              <CardTitle>AI-Powered Design</CardTitle>
              <CardDescription>
                Our advanced AI creates beautiful, professional websites based on your description
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                Simply describe what you want, and our AI will generate a complete website tailored to your needs – no coding required.
              </p>
            </CardContent>
          </Card>
          
          <Card className="bg-primary/5 border-0">
            <CardHeader>
              <div className="bg-primary/10 w-12 h-12 rounded-full flex items-center justify-center mb-2">
                <Clock className="h-6 w-6 text-primary" />
              </div>
              <CardTitle>Fast & Efficient</CardTitle>
              <CardDescription>
                Get a fully functional website in minutes, not days or weeks
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                Skip the lengthy design process and go from idea to live website in just a few minutes with our efficient AI builder.
              </p>
            </CardContent>
          </Card>
          
          <Card className="bg-primary/5 border-0">
            <CardHeader>
              <div className="bg-primary/10 w-12 h-12 rounded-full flex items-center justify-center mb-2">
                <Laptop className="h-6 w-6 text-primary" />
              </div>
              <CardTitle>Fully Customizable</CardTitle>
              <CardDescription>
                Easily edit and customize every aspect of your generated website
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                After the AI creates your website, you can edit content, change colors, add images, and make it truly yours.
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
      
      {/* Login prompt dialog */}
      <RequireAuthPrompt
        isOpen={showLoginPrompt}
        onClose={() => setShowLoginPrompt(false)}
        redirectUrl="/ai-builder-result"
      />
    </div>
  );
}