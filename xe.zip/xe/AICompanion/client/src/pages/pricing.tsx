import { useState } from "react";
import { Link } from "wouter";
import { useAuth } from "@/hooks/useAuth";
import { Check, X, Sparkles, ArrowRight, Globe, Download, Palette, Zap, Server, ShieldCheck } from "lucide-react";

import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

export default function Pricing() {
  const { user, isAuthenticated } = useAuth();
  const [billingCycle, setBillingCycle] = useState<"monthly" | "yearly">("monthly");

  const tiers = [
    {
      name: "Free",
      description: "Essential features for hobbyists and small personal projects",
      price: {
        monthly: 0,
        yearly: 0,
      },
      features: [
        { name: "1 Website Project", included: true },
        { name: "Free Subdomain (yoursite.xenabyte.com)", included: true },
        { name: "Publish Projects Online", included: true },
        { name: "Basic AI Image Generation (5/mo)", included: true },
        { name: "Custom Design Options", included: false },
        { name: "Export Projects", included: false },
        { name: "Download Projects", included: false },
        { name: "Premium Templates", included: false },
        { name: "Custom Domain", included: false },
        { name: "Remove Xenabyte Branding", included: false },
      ],
      cta: "Get Started",
      ctaLink: "/signup",
      popular: false,
      color: "default",
    },
    {
      name: "Basic",
      description: "Perfect for freelancers and growing businesses",
      price: {
        monthly: 5,
        yearly: 50,
      },
      features: [
        { name: "5 Website Projects", included: true },
        { name: "Free Subdomain (yoursite.xenabyte.com)", included: true },
        { name: "Publish Projects Online", included: true },
        { name: "Advanced AI Image Generation (50/mo)", included: true },
        { name: "Custom Design Options", included: true },
        { name: "Export Projects", included: true },
        { name: "Download Projects", included: true },
        { name: "Access to Premium Templates", included: true },
        { name: "Custom Domain", included: true },
        { name: "Remove Xenabyte Branding", included: false },
      ],
      cta: "Upgrade to Basic",
      ctaLink: "/signup?plan=basic",
      popular: true,
      color: "primary",
    },
    {
      name: "Premium",
      description: "Advanced solutions for agencies and large businesses",
      price: {
        monthly: 39,
        yearly: 390,
      },
      features: [
        { name: "100 Website Projects", included: true },
        { name: "Free Subdomain (yoursite.xenabyte.com)", included: true },
        { name: "Publish Projects Online", included: true },
        { name: "Unlimited AI Image Generation", included: true },
        { name: "Custom Design Options", included: true },
        { name: "Export Projects with Database", included: true },
        { name: "Download Projects with Source Code", included: true },
        { name: "All Premium Templates", included: true },
        { name: "Connect Multiple Custom Domains", included: true },
        { name: "Remove Xenabyte Branding", included: true },
      ],
      cta: "Upgrade to Premium",
      ctaLink: "/signup?plan=premium",
      popular: false,
      color: "secondary",
    },
  ];

  const faqs = [
    {
      question: "Can I upgrade or downgrade my plan later?",
      answer: "Yes, you can upgrade or downgrade your subscription plan at any time. When upgrading, the new features will be available immediately. When downgrading, you'll retain access to your current features until the end of your billing cycle."
    },
    {
      question: "What payment methods do you accept?",
      answer: "We accept credit/debit cards, PayPal, and M-Pesa for mobile payments. All payments are processed securely through our payment providers."
    },
    {
      question: "Is there a contract or minimum commitment?",
      answer: "No, our plans are subscription-based with no long-term commitment. You can cancel at any time and won't be charged for future billing cycles."
    },
    {
      question: "How does the AI image generation work?",
      answer: "Our AI image generation feature lets you create custom images for your website by describing what you want. The Free plan includes 5 images per month, Basic includes 50 images per month, and Enterprise offers unlimited image generation."
    },
    {
      question: "What is included in the database export feature?",
      answer: "The database export feature allows you to download your complete website data including content, user information, and settings in SQL format. This helps you back up your data or migrate to a different platform if needed."
    },
    {
      question: "Can I try premium features before subscribing?",
      answer: "We don't currently offer a free trial of our premium plans, but we have a 14-day money-back guarantee if you're not satisfied with your purchase."
    },
  ];

  return (
    <div className="container py-12 md:py-16">
      <div className="text-center mb-12">
        <h1 className="text-3xl md:text-5xl font-bold mb-4">Powerful Plans for Every Need</h1>
        <p className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto">
          Choose the perfect plan to bring your website vision to life with Xenabyte's powerful AI-driven tools
        </p>
        
        <Tabs 
          defaultValue="monthly" 
          className="inline-block"
          onValueChange={(value) => setBillingCycle(value as "monthly" | "yearly")}
        >
          <TabsList className="grid w-[300px] grid-cols-2">
            <TabsTrigger value="monthly">Monthly Billing</TabsTrigger>
            <TabsTrigger value="yearly">
              Yearly Billing
              <span className="ml-1.5 px-2 py-0.5 rounded text-xs font-medium bg-primary/10 text-primary">
                Save 20%
              </span>
            </TabsTrigger>
          </TabsList>
        </Tabs>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-16">
        {tiers.map((tier) => (
          <PricingCard
            key={tier.name}
            tier={tier}
            billingCycle={billingCycle}
            isAuthenticated={isAuthenticated}
            currentPlan={user?.subscriptionTier}
          />
        ))}
      </div>
      
      <div className="mb-16">
        <h2 className="text-2xl md:text-3xl font-bold text-center mb-10">
          Compare Features by Plan
        </h2>
        <div className="max-w-4xl mx-auto border rounded-lg overflow-hidden">
          <div className="grid grid-cols-4">
            <div className="p-4 border-b font-medium">Feature</div>
            <div className="p-4 border-b border-l text-center font-medium">Free</div>
            <div className="p-4 border-b border-l text-center font-medium">Basic</div>
            <div className="p-4 border-b border-l text-center font-medium">Enterprise</div>
            
            <FeatureRow 
              feature="Website Projects" 
              free="1 project" 
              basic="3 projects" 
              enterprise="Unlimited" 
              icon={<Globe className="h-4 w-4" />}
            />
            
            <FeatureRow 
              feature="AI Image Generation" 
              free="5 images/month" 
              basic="50 images/month" 
              enterprise="Unlimited" 
              icon={<Palette className="h-4 w-4" />}
            />
            
            <FeatureRow 
              feature="Custom Domains" 
              free="Free subdomain only" 
              basic="1 custom domain" 
              enterprise="Multiple domains" 
              icon={<Globe className="h-4 w-4" />}
            />
            
            <FeatureRow 
              feature="Database Export" 
              free={<X className="h-4 w-4 mx-auto text-red-500" />} 
              basic={<Check className="h-4 w-4 mx-auto text-green-500" />} 
              enterprise="Export + Auto Backups" 
              icon={<Server className="h-4 w-4" />}
            />
            
            <FeatureRow 
              feature="Premium Templates" 
              free={<X className="h-4 w-4 mx-auto text-red-500" />} 
              basic="Basic Access" 
              enterprise="Full Access" 
              icon={<Download className="h-4 w-4" />}
            />
            
            <FeatureRow 
              feature="Custom Design Options" 
              free="Limited" 
              basic="Standard" 
              enterprise="Advanced" 
              icon={<Palette className="h-4 w-4" />}
            />
            
            <FeatureRow 
              feature="Published Sites" 
              free={<Check className="h-4 w-4 mx-auto text-green-500" />} 
              basic={<Check className="h-4 w-4 mx-auto text-green-500" />} 
              enterprise={<Check className="h-4 w-4 mx-auto text-green-500" />} 
              icon={<Zap className="h-4 w-4" />}
            />
            
            <FeatureRow 
              feature="Xenabyte Branding" 
              free="Visible" 
              basic="Visible" 
              enterprise="Optional" 
              icon={<ShieldCheck className="h-4 w-4" />}
            />
          </div>
        </div>
      </div>
      
      <div className="max-w-3xl mx-auto mb-20">
        <h2 className="text-2xl md:text-3xl font-bold text-center mb-8">
          Frequently Asked Questions
        </h2>
        <Accordion type="single" collapsible className="w-full">
          {faqs.map((faq, index) => (
            <FaqItem 
              key={index} 
              question={faq.question} 
              answer={faq.answer} 
              index={`item-${index}`}
            />
          ))}
        </Accordion>
      </div>
      
      <div className="border-animated p-1 rounded-xl bg-gradient-to-br from-primary/5 to-secondary/5 max-w-4xl mx-auto">
        <div className="bg-card p-8 rounded-lg text-center">
          <h2 className="text-2xl md:text-3xl font-bold mb-4">
            Need a Custom Solution?
          </h2>
          <p className="text-muted-foreground mb-6 max-w-xl mx-auto">
            Contact our sales team to discuss your specific requirements and get a tailored solution for your business needs.
          </p>
          <Button size="lg" variant="default" className="font-medium">
            Contact Sales
            <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}

function PricingCard({ 
  tier, 
  billingCycle,
  isAuthenticated,
  currentPlan
}: { 
  tier: any; 
  billingCycle: "monthly" | "yearly";
  isAuthenticated: boolean;
  currentPlan?: string;
}) {
  const price = tier.price[billingCycle];
  const isCurrentPlan = currentPlan?.toLowerCase() === tier.name.toLowerCase();
  
  // Calculate effective price per month for yearly billing
  const effectiveMonthlyPrice = billingCycle === "yearly" 
    ? (tier.price.yearly / 12).toFixed(2) 
    : tier.price.monthly;
  
  return (
    <div className={`card-futuristic p-1 h-full ${tier.popular ? 'glow' : ''}`}>
      <Card className="h-full flex flex-col">
        <CardHeader>
          <div className="flex justify-between items-start">
            <div>
              <CardTitle className="text-xl">{tier.name}</CardTitle>
              <CardDescription className="mt-1.5">{tier.description}</CardDescription>
            </div>
            {tier.popular && (
              <div className="px-3 py-1 bg-primary/10 text-primary text-xs font-medium rounded-full uppercase">
                Popular
              </div>
            )}
          </div>
        </CardHeader>
        <CardContent className="space-y-4 flex-grow">
          <div className="space-y-1">
            <div className="flex items-baseline">
              <span className="text-3xl font-bold">
                {price === 0 ? "Free" : `$${price}`}
              </span>
              {price > 0 && (
                <span className="ml-1.5 text-muted-foreground">
                  /{billingCycle === "monthly" ? "mo" : "yr"}
                </span>
              )}
            </div>
            {billingCycle === "yearly" && price > 0 && (
              <div className="text-sm text-muted-foreground">
                ${effectiveMonthlyPrice}/month, billed annually
              </div>
            )}
          </div>
          
          <ul className="space-y-2.5">
            {tier.features.map((feature: any, i: number) => (
              <li key={i} className="flex items-start gap-2">
                {feature.included ? (
                  <Check className="h-4 w-4 text-green-500 mt-0.5" />
                ) : (
                  <X className="h-4 w-4 text-muted-foreground mt-0.5" />
                )}
                <span className={feature.included ? "" : "text-muted-foreground"}>
                  {feature.name}
                </span>
              </li>
            ))}
          </ul>
        </CardContent>
        <CardFooter>
          <Button 
            className={`w-full ${tier.color === "primary" ? "glow" : tier.color === "secondary" ? "glow-secondary" : ""}`} 
            variant={tier.color === "default" ? "outline" : "default"}
            asChild
            disabled={isCurrentPlan}
          >
            <a href={isAuthenticated ? "/account/billing" : tier.ctaLink}>
              {isCurrentPlan ? "Current Plan" : tier.cta}
            </a>
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
}

function FaqItem({ question, answer, index }: { question: string; answer: string; index: string }) {
  return (
    <AccordionItem value={index} className="border-b">
      <AccordionTrigger className="text-left hover:no-underline">
        <span className="font-medium">{question}</span>
      </AccordionTrigger>
      <AccordionContent className="text-muted-foreground">
        {answer}
      </AccordionContent>
    </AccordionItem>
  );
}

function FeatureRow({ 
  feature, 
  free, 
  basic, 
  enterprise,
  icon
}: { 
  feature: string; 
  free: React.ReactNode; 
  basic: React.ReactNode; 
  enterprise: React.ReactNode;
  icon: React.ReactNode;
}) {
  return (
    <>
      <div className="p-4 border-b flex items-center gap-2">
        {icon}
        <span>{feature}</span>
      </div>
      <div className="p-4 border-b border-l text-center">
        {free}
      </div>
      <div className="p-4 border-b border-l text-center">
        {basic}
      </div>
      <div className="p-4 border-b border-l text-center">
        {enterprise}
      </div>
    </>
  );
}