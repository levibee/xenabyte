import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import {
  ArrowRight,
  Code,
  PaintBucket,
  Layers,
  Eye,
  Download,
  Sparkles,
} from "lucide-react";

export default function Home() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="min-h-[80vh] relative overflow-hidden py-16 lg:py-24 flex items-center">
        {/* Background with animated gradient */}
        <div className="absolute inset-0 bg-background z-0">
          <div className="absolute inset-0 opacity-20 bg-[radial-gradient(circle_at_center,_var(--primary)_0%,_transparent_50%)]"></div>
          <div className="absolute inset-0 opacity-10">
            <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-primary to-transparent"></div>
            <div className="absolute bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-secondary to-transparent"></div>
            <div className="absolute top-0 bottom-0 left-0 w-px bg-gradient-to-b from-transparent via-primary to-transparent"></div>
            <div className="absolute top-0 bottom-0 right-0 w-px bg-gradient-to-b from-transparent via-secondary to-transparent"></div>
          </div>
        </div>
        
        {/* Floating particles effect */}
        <div className="absolute inset-0 z-0 opacity-30">
          {[...Array(20)].map((_, i) => (
            <div 
              key={i}
              className="absolute rounded-full bg-primary"
              style={{
                top: `${Math.random() * 100}%`,
                left: `${Math.random() * 100}%`,
                width: `${Math.random() * 4 + 1}px`,
                height: `${Math.random() * 4 + 1}px`,
                opacity: Math.random() * 0.5 + 0.3,
                animation: `float ${Math.random() * 10 + 10}s linear infinite`,
                animationDelay: `${Math.random() * 5}s`
              }}
            />
          ))}
        </div>

        <div className="container mx-auto px-4 md:px-6 relative z-10">
          <div className="flex flex-col lg:flex-row items-center gap-8 lg:gap-12">
            <div className="flex-1 space-y-8">
              <div className="inline-block px-4 py-1 rounded-full border border-primary/30 bg-primary/5 text-sm font-medium text-primary">
                The future of AI website creation
              </div>
              <h1 className="text-4xl md:text-5xl lg:text-7xl font-extrabold tracking-tight">
                Create websites with
                <div className="text-gradient mt-2">
                  AI-powered intelligence
                </div>
              </h1>
              <p className="text-xl text-muted-foreground max-w-2xl">
                Xenabyte uses advanced AI to generate complete websites from simple text prompts.
                Just describe what you want, and watch our AI build a beautiful, responsive 
                website that adapts to your vision.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Link href="/ai-builder">
                  <Button size="lg" className="gap-2 glow relative overflow-hidden group">
                    <span className="relative z-10 flex items-center gap-2">
                      Start with AI <ArrowRight className="h-4 w-4 group-hover:translate-x-1 transition-transform" />
                    </span>
                    <span className="absolute inset-0 bg-gradient-to-r from-primary via-secondary to-primary bg-[length:200%_100%] animate-shimmer"></span>
                  </Button>
                </Link>
                <Link href="/builder">
                  <Button variant="outline" size="lg" className="border-primary/50 hover:border-primary">
                    Manual Builder
                  </Button>
                </Link>
              </div>
            </div>
            <div className="flex-1 relative">
              <div className="border-animated rounded-lg overflow-hidden">
                <div className="rounded-lg overflow-hidden card-futuristic p-1">
                  <img
                    src="https://images.unsplash.com/photo-1581291518633-83b4ebd1d83e?auto=format&fit=crop&w=1200&q=80"
                    alt="AI-powered website builder interface"
                    className="w-full h-auto rounded-lg"
                  />
                </div>
              </div>
              
              {/* Floating UI elements */}
              <div className="absolute -top-4 -left-4 bg-card p-3 rounded-lg shadow-lg border border-border float" style={{animationDelay: "0.5s"}}>
                <Sparkles className="h-5 w-5 text-primary" />
              </div>
              <div className="absolute -bottom-4 -right-4 bg-card p-3 rounded-lg shadow-lg border border-border float" style={{animationDelay: "1s"}}>
                <Code className="h-5 w-5 text-secondary" />
              </div>
              <div className="absolute top-1/2 -right-4 transform -translate-y-1/2 bg-card p-3 rounded-lg shadow-lg border border-border float" style={{animationDelay: "1.5s"}}>
                <PaintBucket className="h-5 w-5 text-accent" />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 lg:py-28 relative overflow-hidden">
        {/* Cyberpunk grid background */}
        <div className="absolute inset-0 z-0 opacity-5">
          <div className="absolute inset-0" style={{
            backgroundImage: `linear-gradient(to right, var(--primary) 1px, transparent 1px), 
                             linear-gradient(to bottom, var(--primary) 1px, transparent 1px)`,
            backgroundSize: '40px 40px'
          }}></div>
        </div>
        
        <div className="container mx-auto px-4 md:px-6 relative z-10">
          <div className="divider-cyber w-24 mx-auto mb-8"></div>
          
          <div className="text-center mb-16">
            <span className="text-gradient font-bold tracking-wide uppercase text-sm mb-3 inline-block">Futuristic AI Technology</span>
            <h2 className="text-3xl md:text-5xl font-bold mb-6">
              The Future of Website Creation
            </h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Xenabyte harnesses cutting-edge artificial intelligence to transform your concepts into stunning, 
              functional websites with unprecedented speed and precision.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <FeatureCard
              icon={<Sparkles className="h-8 w-8 text-primary" />}
              title="AI-Powered Generation"
              description="Describe your vision in natural language and watch our advanced AI create a complete website design customized to your specifications."
            />
            <FeatureCard
              icon={<PaintBucket className="h-8 w-8 text-secondary" />}
              title="Intelligent Design System"
              description="Our AI analyzes your brand and industry to suggest optimal color schemes, typography, and layouts that resonate with your target audience."
            />
            <FeatureCard
              icon={<Eye className="h-8 w-8 text-accent" />}
              title="Adaptive Responsive Design"
              description="Every website automatically adapts to all screen sizes with our AI-powered responsive design system - no manual adjustments needed."
            />
            <FeatureCard
              icon={<Code className="h-8 w-8 text-primary" />}
              title="Clean, Optimized Code"
              description="Our AI generates semantically correct, high-performance code that follows modern web standards and best practices for SEO."
            />
            <FeatureCard
              icon={<Download className="h-8 w-8 text-secondary" />}
              title="Flexible Payment Options"
              description="Pay conveniently with both card and M-Pesa payment options to access premium features and unlock additional AI capabilities."
            />
            <FeatureCard
              icon={<Layers className="h-8 w-8 text-accent" />}
              title="AI Content Generation"
              description="Generate professionally written copy, headings, and content tailored to your industry, tone of voice, and target audience."
            />
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="py-24 lg:py-32 relative overflow-hidden">
        {/* Angled section dividers */}
        <div className="absolute top-0 left-0 right-0 h-24 bg-gradient-to-b from-background to-transparent z-10"></div>
        <div className="absolute bottom-0 left-0 right-0 h-24 bg-gradient-to-t from-background to-transparent z-10"></div>
        
        {/* Futuristic background */}
        <div className="absolute inset-0 bg-primary/5 -z-10">
          <div className="absolute inset-0 opacity-20" 
               style={{backgroundImage: "radial-gradient(circle at 25% 25%, var(--primary) 0%, transparent 50%), radial-gradient(circle at 75% 75%, var(--secondary) 0%, transparent 50%)"}}></div>
        </div>
        
        <div className="container mx-auto px-4 md:px-6 relative z-20">
          <div className="text-center mb-20">
            <div className="inline-block px-4 py-1 rounded-full border border-primary/30 bg-primary/5 text-sm font-medium text-primary mb-5">
              Simple 3-step process
            </div>
            <h2 className="text-3xl md:text-5xl font-bold mb-6">
              How <span className="text-gradient">Xenabyte</span> Works
            </h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Our AI platform transforms your ideas into beautiful websites in just three simple steps.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 md:gap-6 lg:gap-10 relative">
            {/* Connecting line between steps */}
            <div className="hidden md:block absolute top-24 left-[calc(16.67%+8px)] right-[calc(16.67%+8px)] h-0.5 bg-gradient-to-r from-primary via-secondary to-accent"></div>
            
            <StepCard
              number="1"
              title="Describe Your Vision"
              description="Tell our AI what kind of website you need using natural language. Be as specific or general as you like."
              image="https://images.unsplash.com/photo-1488190211105-8b0e65b80b4e?auto=format&fit=crop&w=600&h=400&q=80"
            />
            <StepCard
              number="2"
              title="Review AI Designs"
              description="Our AI generates multiple unique design options tailored to your description. Pick the one you like best."
              image="https://images.unsplash.com/photo-1558655146-9f40138edfeb?auto=format&fit=crop&w=600&h=400&q=80"
            />
            <StepCard
              number="3"
              title="Customize & Launch"
              description="Fine-tune your chosen design with our intuitive editor, then publish or export your finished website."
              image="https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&w=600&h=400&q=80"
            />
          </div>

          <div className="text-center mt-20">
            <Link href="/ai-builder">
              <Button size="lg" className="gap-2 glow relative overflow-hidden group">
                <span className="relative z-10 flex items-center gap-2">
                  Create Your Website <ArrowRight className="h-4 w-4 group-hover:translate-x-1 transition-transform" />
                </span>
                <span className="absolute inset-0 bg-gradient-to-r from-primary via-secondary to-primary bg-[length:200%_100%] animate-shimmer"></span>
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section className="py-20 lg:py-28 relative overflow-hidden">
        <div className="absolute inset-0 z-0 opacity-10">
          <div className="absolute inset-0" 
               style={{backgroundImage: "radial-gradient(circle at 20% 20%, var(--primary) 0%, transparent 40%), radial-gradient(circle at 80% 80%, var(--secondary) 0%, transparent 40%)"}}></div>
        </div>
        
        <div className="container mx-auto px-4 md:px-6 relative z-10">
          <div className="text-center mb-16">
            <div className="divider-cyber w-24 mx-auto mb-8"></div>
            <h2 className="text-3xl md:text-5xl font-bold mb-6">
              Choose Your <span className="text-gradient">Plan</span>
            </h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Select the perfect plan to unlock the full potential of our AI-powered website creation platform.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Free Plan */}
            <div className="card-futuristic p-1 overflow-hidden group">
              <div className="h-full flex flex-col rounded-lg overflow-hidden bg-card relative">
                <div className="p-6 md:p-8 flex-1">
                  <h3 className="text-lg font-medium text-muted-foreground mb-3">Free</h3>
                  <div className="flex items-baseline mb-5">
                    <span className="text-4xl font-bold">$0</span>
                    <span className="text-muted-foreground ml-2">/month</span>
                  </div>
                  <ul className="space-y-3 mb-8">
                    <li className="flex items-center">
                      <div className="mr-2 h-5 w-5 text-primary">✓</div>
                      <span>3 AI-generated websites</span>
                    </li>
                    <li className="flex items-center">
                      <div className="mr-2 h-5 w-5 text-primary">✓</div>
                      <span>Basic customization</span>
                    </li>
                    <li className="flex items-center">
                      <div className="mr-2 h-5 w-5 text-primary">✓</div>
                      <span>Free xenabyte.com subdomain</span>
                    </li>
                    <li className="flex items-center">
                      <div className="mr-2 h-5 w-5 text-primary">✓</div>
                      <span>Export HTML/CSS online</span>
                    </li>
                    <li className="flex items-center text-muted-foreground">
                      <div className="mr-2 h-5 w-5">✕</div>
                      <span>Download zip files</span>
                    </li>
                    <li className="flex items-center text-muted-foreground">
                      <div className="mr-2 h-5 w-5">✕</div>
                      <span>Custom domain</span>
                    </li>
                  </ul>
                </div>
                <div className="p-6 pt-0 md:p-8 md:pt-0 mt-auto">
                  <Link href="/signup">
                    <Button variant="outline" size="lg" className="w-full">Get Started</Button>
                  </Link>
                </div>
              </div>
            </div>
            
            {/* Premium Plan - Highlighted */}
            <div className="card-futuristic p-1 overflow-hidden border-animated group">
              <div className="h-full flex flex-col rounded-lg overflow-hidden bg-card relative">
                <div className="absolute -top-5 -right-5">
                  <div className="bg-primary text-primary-foreground px-4 py-1 rotate-45 transform translate-x-6 shadow-lg text-xs font-medium">
                    POPULAR
                  </div>
                </div>
                <div className="p-6 md:p-8 flex-1">
                  <h3 className="text-lg font-medium text-gradient mb-3">Premium</h3>
                  <div className="flex items-baseline mb-5">
                    <span className="text-4xl font-bold">$15</span>
                    <span className="text-muted-foreground ml-2">/month</span>
                  </div>
                  <ul className="space-y-3 mb-8">
                    <li className="flex items-center">
                      <div className="mr-2 h-5 w-5 text-primary">✓</div>
                      <span>Unlimited AI-generated websites</span>
                    </li>
                    <li className="flex items-center">
                      <div className="mr-2 h-5 w-5 text-primary">✓</div>
                      <span>Advanced customization</span>
                    </li>
                    <li className="flex items-center">
                      <div className="mr-2 h-5 w-5 text-primary">✓</div>
                      <span>Free xenabyte.com subdomain</span>
                    </li>
                    <li className="flex items-center">
                      <div className="mr-2 h-5 w-5 text-primary">✓</div>
                      <span>1 custom domain</span>
                    </li>
                    <li className="flex items-center">
                      <div className="mr-2 h-5 w-5 text-primary">✓</div>
                      <span>Download zip files ($5/download)</span>
                    </li>
                    <li className="flex items-center">
                      <div className="mr-2 h-5 w-5 text-primary">✓</div>
                      <span>Export HTML/CSS/JS online</span>
                    </li>
                  </ul>
                </div>
                <div className="p-6 pt-0 md:p-8 md:pt-0 mt-auto">
                  <Link href="/signup">
                    <Button className="w-full glow">Choose Plan</Button>
                  </Link>
                </div>
              </div>
            </div>
            
            {/* Enterprise Plan */}
            <div className="card-futuristic p-1 overflow-hidden group">
              <div className="h-full flex flex-col rounded-lg overflow-hidden bg-card relative">
                <div className="p-6 md:p-8 flex-1">
                  <h3 className="text-lg font-medium text-muted-foreground mb-3">Enterprise</h3>
                  <div className="flex items-baseline mb-5">
                    <span className="text-4xl font-bold">$39</span>
                    <span className="text-muted-foreground ml-2">/month</span>
                  </div>
                  <ul className="space-y-3 mb-8">
                    <li className="flex items-center">
                      <div className="mr-2 h-5 w-5 text-primary">✓</div>
                      <span>Everything in Premium</span>
                    </li>
                    <li className="flex items-center">
                      <div className="mr-2 h-5 w-5 text-primary">✓</div>
                      <span>Multiple team members</span>
                    </li>
                    <li className="flex items-center">
                      <div className="mr-2 h-5 w-5 text-primary">✓</div>
                      <span>Free xenabyte.com subdomain</span>
                    </li>
                    <li className="flex items-center">
                      <div className="mr-2 h-5 w-5 text-primary">✓</div>
                      <span>5 custom domains</span>
                    </li>
                    <li className="flex items-center">
                      <div className="mr-2 h-5 w-5 text-primary">✓</div>
                      <span>Unlimited zip downloads included</span>
                    </li>
                    <li className="flex items-center">
                      <div className="mr-2 h-5 w-5 text-primary">✓</div>
                      <span>Admin dashboard</span>
                    </li>
                    <li className="flex items-center">
                      <div className="mr-2 h-5 w-5 text-primary">✓</div>
                      <span>Priority support</span>
                    </li>
                  </ul>
                </div>
                <div className="p-6 pt-0 md:p-8 md:pt-0 mt-auto">
                  <Link href="/signup">
                    <Button variant="outline" size="lg" className="w-full">Get Started</Button>
                  </Link>
                </div>
              </div>
            </div>
          </div>
          
          <div className="mt-12 text-center">
            <div className="inline-flex items-center justify-center p-4 rounded-lg bg-card border border-border">
              <div className="flex items-center mr-4">
                <svg viewBox="0 0 40 40" className="h-6 w-6 mr-2 text-primary" fill="currentColor">
                  <path d="M20 0C8.96 0 0 8.96 0 20s8.96 20 20 20 20-8.96 20-20S31.04 0 20 0zm0 36c-8.84 0-16-7.16-16-16S11.16 4 20 4s16 7.16 16 16-7.16 16-16 16z"/>
                  <path d="M22 10h-4v10h-6l8 10 8-10h-6z"/>
                </svg>
                <span>M-Pesa</span>
              </div>
              <div className="h-6 w-px bg-border mx-2"></div>
              <div className="flex items-center">
                <svg viewBox="0 0 24 24" className="h-6 w-6 mr-2 text-primary" fill="none" stroke="currentColor" strokeWidth="2">
                  <rect x="1" y="4" width="22" height="16" rx="2" />
                  <line x1="1" y1="10" x2="23" y2="10" />
                </svg>
                <span>Card Payments</span>
              </div>
            </div>
          </div>
        </div>
      </section>
      
      {/* Template Showcase */}
      <section className="py-16 lg:py-24 bg-muted/50">
        <div className="container mx-auto px-4 md:px-6">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Stunning Templates for Any Purpose
            </h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Browse our collection of AI-generated templates to get
              started quickly.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <TemplateCard
              title="Portfolio"
              image="https://images.unsplash.com/photo-1467232004584-a241de8bcf5d?auto=format&fit=crop&w=600&h=400&q=80"
            />
            <TemplateCard
              title="Business"
              image="https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=600&h=400&q=80"
            />
            <TemplateCard
              title="E-Commerce"
              image="https://images.unsplash.com/photo-1472851294608-062f824d29cc?auto=format&fit=crop&w=600&h=400&q=80"
            />
            <TemplateCard
              title="Blog"
              image="https://images.unsplash.com/photo-1499750310107-5fef28a66643?auto=format&fit=crop&w=600&h=400&q=80"
            />
          </div>

          <div className="text-center mt-12">
            <Button variant="outline">View All Templates</Button>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="relative py-24 lg:py-32 overflow-hidden">
        {/* Animated background */}
        <div className="absolute inset-0 bg-gradient-to-r from-primary to-secondary opacity-90 z-0">
          <div className="absolute inset-0" style={{
            backgroundImage: 'radial-gradient(circle at 25% 25%, transparent 0%, rgba(0,0,0,0.4) 80%), radial-gradient(circle at 75% 75%, transparent 0%, rgba(0,0,0,0.4) 80%)'
          }}></div>
        </div>
        
        {/* Cyber grid overlay */}
        <div className="absolute inset-0 z-10 opacity-10">
          <div className="absolute inset-0" style={{
            backgroundImage: `linear-gradient(to right, rgba(255,255,255,0.2) 1px, transparent 1px), 
                             linear-gradient(to bottom, rgba(255,255,255,0.2) 1px, transparent 1px)`,
            backgroundSize: '40px 40px'
          }}></div>
        </div>
        
        {/* Glitch line effects */}
        <div className="absolute top-0 left-0 right-0 h-px bg-white opacity-30"></div>
        <div className="absolute bottom-0 left-0 right-0 h-px bg-white opacity-30"></div>
        
        <div className="container mx-auto px-4 md:px-6 text-center relative z-20">
          <div className="max-w-3xl mx-auto">
            <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 text-white drop-shadow-lg">
              The <span className="text-transparent bg-clip-text bg-gradient-to-r from-white via-white to-white/80">Future</span> of Website Creation
            </h2>
            <p className="text-xl max-w-2xl mx-auto mb-10 text-white/90">
              Harness the power of artificial intelligence to build and deploy stunning websites in minutes, 
              not months. No coding or design skills required.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-5 justify-center">
              <Link href="/ai-builder">
                <Button
                  size="lg"
                  className="bg-white text-primary hover:bg-white/90 hover:scale-105 transition-transform px-8 py-6 text-lg glow-secondary"
                >
                  <span className="flex items-center gap-2">
                    Start Creating <Sparkles className="h-5 w-5" />
                  </span>
                </Button>
              </Link>
              <Link href="/pricing">
                <Button
                  variant="outline"
                  size="lg"
                  className="border-white text-white hover:bg-white/10 hover:scale-105 transition-transform px-8 py-6 text-lg"
                >
                  See Plans
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

function FeatureCard({
  icon,
  title,
  description,
}: {
  icon: React.ReactNode;
  title: string;
  description: string;
}) {
  return (
    <div className="card-futuristic p-6 hover:shadow-lg transition-all duration-300 hover:-translate-y-1 group">
      <div className="mb-5 p-3 rounded-lg inline-flex bg-primary/10 group-hover:bg-primary/20 transition-colors duration-300">{icon}</div>
      <h3 className="text-xl font-semibold mb-3 group-hover:text-gradient transition-colors duration-300">{title}</h3>
      <p className="text-muted-foreground">{description}</p>
    </div>
  );
}

function StepCard({
  number,
  title,
  description,
  image,
}: {
  number: string;
  title: string;
  description: string;
  image: string;
}) {
  return (
    <div className="card-futuristic p-1 overflow-hidden group hover:-translate-y-2 transition-all duration-500">
      <div className="rounded-lg overflow-hidden bg-card h-full">
        <div className="relative h-44 md:h-48 overflow-hidden">
          <img
            src={image}
            alt={title}
            className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-background to-transparent opacity-50"></div>
          <div className="absolute top-4 left-4 w-10 h-10 glow rounded-full bg-primary text-primary-foreground flex items-center justify-center font-bold text-lg">
            {number}
          </div>
          
          {/* Futuristic accent elements */}
          <div className="absolute bottom-0 left-0 w-1/3 h-1 bg-gradient-to-r from-primary to-transparent"></div>
          <div className="absolute top-0 right-0 w-1/3 h-1 bg-gradient-to-l from-secondary to-transparent"></div>
        </div>
        <div className="p-6">
          <h3 className="text-xl font-bold mb-3 group-hover:text-gradient transition-colors duration-300">{title}</h3>
          <p className="text-muted-foreground">{description}</p>
        </div>
      </div>
    </div>
  );
}

function TemplateCard({
  title,
  image,
}: {
  title: string;
  image: string;
}) {
  return (
    <div className="card-futuristic p-1 overflow-hidden group hover:-translate-y-1 transition-all duration-300">
      <div className="bg-card rounded-lg overflow-hidden">
        <div className="relative h-64">
          <img
            src={image}
            alt={`${title} template`}
            className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-background/90 via-background/30 to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
            <Button className="glow" size="sm">
              Preview
            </Button>
          </div>
          {/* Futuristic accents */}
          <div className="absolute bottom-0 left-0 w-1/3 h-0.5 bg-gradient-to-r from-primary to-transparent"></div>
          <div className="absolute top-0 right-0 w-1/3 h-0.5 bg-gradient-to-l from-secondary to-transparent"></div>
        </div>
        <div className="p-4 text-center">
          <h3 className="font-medium group-hover:text-gradient transition-colors duration-300">{title}</h3>
        </div>
      </div>
    </div>
  );
}
