import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/hooks/useAuth";
import { Edit, Download, ExternalLink, Save, Share, Check, Sparkles } from "lucide-react";
import RequireAuthPrompt from "@/components/auth/RequireAuthPrompt";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";

export default function AIBuilderResult() {
  const [, navigate] = useLocation();
  const { isAuthenticated, user } = useAuth();
  const { toast } = useToast();
  const [websiteData, setWebsiteData] = useState<any>(null);
  const [showLoginPrompt, setShowLoginPrompt] = useState(false);
  const [websiteSaved, setWebsiteSaved] = useState(false);
  const [websitePublished, setWebsitePublished] = useState(false);
  const [isLoading, setIsLoading] = useState({
    save: false,
    publish: false,
    download: false
  });
  
  // Check if we have pending website data in localStorage
  useEffect(() => {
    const storedData = localStorage.getItem('currentGeneratedWebsite');
    
    if (storedData) {
      try {
        const parsedData = JSON.parse(storedData);
        setWebsiteData(parsedData);
      } catch (error) {
        console.error("Error parsing stored website data:", error);
      }
    } else {
      // If no data, redirect back to AI builder
      navigate("/ai-builder");
    }
  }, [navigate]);

  // Check if user just completed authentication after generation
  useEffect(() => {
    if (isAuthenticated) {
      const pendingData = localStorage.getItem('pendingWebsiteData');
      if (pendingData) {
        // User has authenticated and has pending data - save it
        try {
          const parsedData = JSON.parse(pendingData);
          handleSaveWebsite(parsedData, true);
          localStorage.removeItem('pendingWebsiteData');
        } catch (error) {
          console.error("Error processing pending website data:", error);
        }
      }
    }
  }, [isAuthenticated]);

  // Handle saving the website to the user's account
  const handleSaveWebsite = async (data = websiteData, autoSave = false) => {
    if (!isAuthenticated) {
      setShowLoginPrompt(true);
      return;
    }
    
    setIsLoading(prev => ({ ...prev, save: true }));
    
    try {
      const response = await apiRequest("POST", "/api/websites", {
        name: data.content.siteName,
        data: data
      });
      
      if (!response.ok) {
        throw new Error("Failed to save website");
      }
      
      const savedWebsite = await response.json();
      setWebsiteSaved(true);
      
      // Remove from localStorage now that it's saved
      localStorage.removeItem('currentGeneratedWebsite');
      
      // Show feedback
      if (!autoSave) {
        toast({
          title: "Website saved",
          description: "Your website has been saved to your account",
        });
      }
      
      return savedWebsite;
    } catch (error) {
      console.error("Save error:", error);
      toast({
        title: "Save failed",
        description: "There was a problem saving your website. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(prev => ({ ...prev, save: false }));
    }
  };

  // Handle publishing the website
  const handlePublishWebsite = async () => {
    if (!isAuthenticated) {
      setShowLoginPrompt(true);
      return;
    }
    
    // First save if not already saved
    let websiteId;
    if (!websiteSaved) {
      const savedWebsite = await handleSaveWebsite();
      if (!savedWebsite) return;
      websiteId = savedWebsite.id;
    } else {
      websiteId = websiteData.id;
    }
    
    setIsLoading(prev => ({ ...prev, publish: true }));
    
    try {
      // Create a free subdomain
      const response = await apiRequest("POST", "/api/domains", {
        websiteId,
        subdomain: websiteData.content.siteName.toLowerCase().replace(/[^a-z0-9]/g, "")
      });
      
      if (!response.ok) {
        throw new Error("Failed to publish website");
      }
      
      const domainData = await response.json();
      setWebsitePublished(true);
      
      toast({
        title: "Website published!",
        description: `Your website is now live at ${domainData.subdomain}.xenabyte.com`,
      });
    } catch (error) {
      console.error("Publish error:", error);
      toast({
        title: "Publish failed",
        description: "There was a problem publishing your website. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(prev => ({ ...prev, publish: false }));
    }
  };

  // Handle downloading the website
  const handleDownloadWebsite = async () => {
    if (!isAuthenticated) {
      setShowLoginPrompt(true);
      return;
    }
    
    // Check subscription status
    if (user?.subscriptionTier === 'free') {
      toast({
        title: "Upgrade required",
        description: "Website downloads are available on Basic and Premium plans",
        variant: "destructive",
      });
      navigate("/pricing");
      return;
    }
    
    // First save if not already saved
    let websiteId;
    if (!websiteSaved) {
      const savedWebsite = await handleSaveWebsite();
      if (!savedWebsite) return;
      websiteId = savedWebsite.id;
    } else {
      websiteId = websiteData.id;
    }
    
    setIsLoading(prev => ({ ...prev, download: true }));
    
    try {
      // Download the website
      window.location.href = `/api/websites/${websiteId}/export`;
    } catch (error) {
      console.error("Download error:", error);
      toast({
        title: "Download failed",
        description: "There was a problem downloading your website. Please try again.",
        variant: "destructive",
      });
      setIsLoading(prev => ({ ...prev, download: false }));
    }
  };

  if (!websiteData) {
    return (
      <div className="container py-16 text-center">
        <div className="animate-spin w-10 h-10 border-4 border-primary border-t-transparent rounded-full mx-auto mb-4"></div>
        <p className="text-muted-foreground">Loading your website...</p>
      </div>
    );
  }

  return (
    <div className="container py-12">
      <div className="flex flex-col md:flex-row justify-between items-start gap-6 mb-10">
        <div>
          <h1 className="text-3xl md:text-4xl font-bold">{websiteData.content.siteName}</h1>
          <p className="text-muted-foreground mt-2">{websiteData.content.tagline}</p>
        </div>
        
        <div className="flex gap-3 flex-wrap sm:flex-nowrap">
          <Button 
            variant="outline" 
            className="gap-2 w-full sm:w-auto" 
            onClick={() => navigate("/ai-builder")}
          >
            <Sparkles className="h-4 w-4" />
            Create New
          </Button>
          
          <Button 
            variant="outline" 
            className="gap-2 w-full sm:w-auto" 
            onClick={() => navigate("/builder")}
          >
            <Edit className="h-4 w-4" />
            Edit
          </Button>
          
          <Button 
            disabled={isLoading.save || websiteSaved} 
            className="gap-2 w-full sm:w-auto"
            onClick={() => handleSaveWebsite()}
          >
            {websiteSaved ? (
              <><Check className="h-4 w-4" /> Saved</>
            ) : isLoading.save ? (
              "Saving..."
            ) : (
              <><Save className="h-4 w-4" /> Save</>
            )}
          </Button>
        </div>
      </div>
      
      {/* Website Preview */}
      <Card className="mb-8 card-futuristic">
        <CardHeader className="pb-0">
          <CardTitle>Website Preview</CardTitle>
        </CardHeader>
        <CardContent className="pt-6">
          <div className="border rounded-lg overflow-hidden h-[600px] bg-white">
            <div className="h-10 bg-muted flex items-center px-4 border-b">
              <div className="flex gap-1.5">
                <div className="w-3 h-3 rounded-full bg-red-500"></div>
                <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
                <div className="w-3 h-3 rounded-full bg-green-500"></div>
              </div>
              <div className="text-xs text-center mx-auto bg-white/80 rounded px-2 py-1">
                {websitePublished ? `${websiteData.domain}.xenabyte.com` : 'preview.xenabyte.com'}
              </div>
            </div>
            
            <div className="h-[calc(100%-2.5rem)] overflow-auto">
              {/* Simplified website preview */}
              <header className="p-4 border-b" style={{ 
                backgroundColor: websiteData.style.colors.primary,
                color: websiteData.style.colors.background
              }}>
                <div className="container mx-auto flex justify-between items-center">
                  <div className="text-xl font-bold" style={{ fontFamily: websiteData.style.fonts.heading }}>
                    {websiteData.content.siteName}
                  </div>
                  <nav>
                    <ul className="flex gap-4">
                      <li>Home</li>
                      <li>About</li>
                      <li>Contact</li>
                    </ul>
                  </nav>
                </div>
              </header>
              
              <main>
                <section className="py-16 px-4 text-center" style={{ 
                  backgroundColor: websiteData.style.colors.secondary,
                  color: websiteData.style.colors.background
                }}>
                  <div className="container mx-auto">
                    <h1 className="text-4xl font-bold mb-4" style={{ fontFamily: websiteData.style.fonts.heading }}>
                      {websiteData.content.tagline}
                    </h1>
                    <p className="max-w-2xl mx-auto mb-8" style={{ fontFamily: websiteData.style.fonts.body }}>
                      Welcome to your new website, built with Xenabyte AI. This is a preview of what your site could look like.
                    </p>
                    <button className="px-6 py-2 rounded-md font-medium" style={{ 
                      backgroundColor: websiteData.style.colors.accent,
                      color: websiteData.style.colors.background
                    }}>
                      Get Started
                    </button>
                  </div>
                </section>
                
                <section className="py-16 px-4" style={{ 
                  backgroundColor: websiteData.style.colors.background,
                  color: websiteData.style.colors.text
                }}>
                  <div className="container mx-auto">
                    <h2 className="text-2xl font-bold mb-8 text-center" style={{ 
                      fontFamily: websiteData.style.fonts.heading,
                      color: websiteData.style.colors.primary
                    }}>
                      Features
                    </h2>
                    
                    <div className="grid md:grid-cols-3 gap-6">
                      {[1, 2, 3].map((i) => (
                        <div key={i} className="p-6 rounded-lg border">
                          <h3 className="text-xl font-semibold mb-2" style={{ 
                            fontFamily: websiteData.style.fonts.heading,
                            color: websiteData.style.colors.primary
                          }}>
                            Feature {i}
                          </h3>
                          <p style={{ fontFamily: websiteData.style.fonts.body }}>
                            This is a sample feature description. Your actual content will be tailored to your website's purpose.
                          </p>
                        </div>
                      ))}
                    </div>
                  </div>
                </section>
              </main>
              
              <footer className="p-4 border-t" style={{ 
                backgroundColor: websiteData.style.colors.primary,
                color: websiteData.style.colors.background
              }}>
                <div className="container mx-auto text-center">
                  <p>© {new Date().getFullYear()} {websiteData.content.siteName}. All rights reserved.</p>
                  <p className="text-sm mt-1">Built with Xenabyte</p>
                </div>
              </footer>
            </div>
          </div>
        </CardContent>
      </Card>
      
      {/* Action Cards */}
      <div className="grid md:grid-cols-3 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <ExternalLink className="h-5 w-5 text-primary" />
              Publish Website
            </CardTitle>
            <CardDescription>
              Make your website available online with a free subdomain
            </CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground mb-4">
              Get a free <span className="font-semibold">[name].xenabyte.com</span> subdomain to share your website with the world.
            </p>
          </CardContent>
          <CardFooter>
            <Button 
              className="w-full" 
              onClick={handlePublishWebsite}
              disabled={isLoading.publish || websitePublished}
            >
              {websitePublished ? (
                <><Check className="mr-2 h-4 w-4" /> Published</>
              ) : isLoading.publish ? (
                "Publishing..."
              ) : (
                "Publish Now"
              )}
            </Button>
          </CardFooter>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Download className="h-5 w-5 text-primary" />
              Download Website
            </CardTitle>
            <CardDescription>
              Download your website's files to use elsewhere
            </CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground mb-4">
              {user?.subscriptionTier === "free" ? (
                <span className="text-primary">Available on Basic and Premium plans</span>
              ) : (
                "Get the full HTML, CSS, and JavaScript files for your website."
              )}
            </p>
          </CardContent>
          <CardFooter>
            <Button 
              className="w-full" 
              onClick={handleDownloadWebsite}
              disabled={isLoading.download || user?.subscriptionTier === "free"}
              variant={user?.subscriptionTier === "free" ? "outline" : "default"}
            >
              {isLoading.download ? (
                "Preparing..."
              ) : user?.subscriptionTier === "free" ? (
                "Upgrade to Download"
              ) : (
                "Download Files"
              )}
            </Button>
          </CardFooter>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Share className="h-5 w-5 text-primary" />
              Share Website
            </CardTitle>
            <CardDescription>
              Share your website with others
            </CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground mb-4">
              {websitePublished ? (
                <>Share your website using the URL: <span className="font-semibold">{websiteData.domain}.xenabyte.com</span></>
              ) : (
                "Publish your website first to get a shareable URL."
              )}
            </p>
          </CardContent>
          <CardFooter>
            <Button 
              className="w-full" 
              disabled={!websitePublished}
              variant={websitePublished ? "default" : "outline"}
              onClick={() => {
                if (websitePublished) {
                  navigator.clipboard.writeText(`https://${websiteData.domain}.xenabyte.com`);
                  toast({
                    title: "URL copied",
                    description: "Website URL copied to clipboard!",
                  });
                }
              }}
            >
              {websitePublished ? "Copy URL" : "Publish First"}
            </Button>
          </CardFooter>
        </Card>
      </div>
      
      {/* Login prompt dialog */}
      <RequireAuthPrompt
        isOpen={showLoginPrompt}
        onClose={() => setShowLoginPrompt(false)}
        websiteData={websiteData}
        redirectUrl="/ai-builder-result"
      />
    </div>
  );
}