import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { GlobeIcon, ExternalLink, Check, AlertTriangle, RefreshCw, Trash2 } from "lucide-react";

import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function DomainsPage() {
  const { user, isAuthenticated } = useAuth();
  const { toast } = useToast();
  const [newSubdomain, setNewSubdomain] = useState("");
  const [newCustomDomain, setNewCustomDomain] = useState("");
  const [selectedWebsite, setSelectedWebsite] = useState<number | null>(null);
  const [isSubdomainDialogOpen, setIsSubdomainDialogOpen] = useState(false);
  const [isCustomDomainDialogOpen, setIsCustomDomainDialogOpen] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Fetch domains
  const { data: domains, isLoading: isLoadingDomains, refetch: refetchDomains } = useQuery({
    queryKey: ["/api/domains"],
    enabled: isAuthenticated,
  });

  // Fetch websites for dropdown selection
  const { data: websites, isLoading: isLoadingWebsites } = useQuery({
    queryKey: ["/api/websites"],
    enabled: isAuthenticated,
  });

  // Create subdomain
  const handleCreateSubdomain = async () => {
    if (!newSubdomain || !selectedWebsite) return;
    
    setIsSubmitting(true);
    try {
      await apiRequest("POST", "/api/domains", {
        websiteId: selectedWebsite,
        subdomain: newSubdomain,
      });
      
      toast({
        title: "Subdomain created",
        description: `Your subdomain ${newSubdomain}.xenabyte.com has been created successfully!`,
      });
      
      setNewSubdomain("");
      setSelectedWebsite(null);
      setIsSubdomainDialogOpen(false);
      refetchDomains();
    } catch (error) {
      toast({
        title: "Failed to create subdomain",
        description: "Please try a different subdomain name",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  // Create custom domain (premium feature)
  const handleCreateCustomDomain = async () => {
    if (!newCustomDomain || !selectedWebsite) return;
    
    setIsSubmitting(true);
    try {
      await apiRequest("POST", "/api/domains/custom", {
        websiteId: selectedWebsite,
        customDomain: newCustomDomain,
      });
      
      toast({
        title: "Custom domain added",
        description: "Please configure your DNS settings according to the instructions provided.",
      });
      
      setNewCustomDomain("");
      setSelectedWebsite(null);
      setIsCustomDomainDialogOpen(false);
      refetchDomains();
    } catch (error) {
      toast({
        title: "Failed to add custom domain",
        description: "Please check your subscription status or try a different domain",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  // Delete domain
  const handleDeleteDomain = async (domainId: number) => {
    try {
      await apiRequest("DELETE", `/api/domains/${domainId}`);
      toast({
        title: "Domain deleted",
        description: "The domain has been successfully removed",
      });
      refetchDomains();
    } catch (error) {
      toast({
        title: "Failed to delete domain",
        description: "Please try again later",
        variant: "destructive",
      });
    }
  };

  // Verify custom domain
  const handleVerifyDomain = async (domainId: number) => {
    try {
      await apiRequest("POST", `/api/domains/${domainId}/verify`);
      toast({
        title: "Verification initiated",
        description: "Domain verification is in progress. This may take a few minutes.",
      });
      refetchDomains();
    } catch (error) {
      toast({
        title: "Verification failed",
        description: "Please check your DNS configuration and try again",
        variant: "destructive",
      });
    }
  };

  if (!isAuthenticated) {
    return (
      <div className="container py-10">
        <Card>
          <CardHeader>
            <CardTitle>Authentication Required</CardTitle>
            <CardDescription>
              You need to be logged in to manage your domains
            </CardDescription>
          </CardHeader>
          <CardFooter>
            <Button onClick={() => window.location.href = "/auth/google"}>Log In</Button>
          </CardFooter>
        </Card>
      </div>
    );
  }

  return (
    <div className="container py-10">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-8 gap-4">
        <div>
          <h1 className="text-3xl md:text-4xl font-bold">Domain Management</h1>
          <p className="text-muted-foreground mt-2">Manage your websites' domains and subdomains</p>
        </div>
        
        <div className="flex flex-col sm:flex-row gap-3">
          {/* Free subdomain button - available to all users */}
          <Dialog open={isSubdomainDialogOpen} onOpenChange={setIsSubdomainDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <GlobeIcon className="mr-2 h-4 w-4" />
                Create Free Subdomain
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Create a Free Subdomain</DialogTitle>
                <DialogDescription>
                  Choose a subdomain to make your website accessible at yourdomain.xenabyte.com
                </DialogDescription>
              </DialogHeader>
              
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="website">Select Website</Label>
                  <Select value={selectedWebsite?.toString()} onValueChange={(value) => setSelectedWebsite(parseInt(value))}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select a website" />
                    </SelectTrigger>
                    <SelectContent>
                      {websites?.map((website: any) => (
                        <SelectItem key={website.id} value={website.id.toString()}>
                          {website.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="subdomain">Subdomain</Label>
                  <div className="flex">
                    <Input
                      id="subdomain"
                      value={newSubdomain}
                      onChange={(e) => setNewSubdomain(e.target.value.toLowerCase().replace(/[^a-z0-9-]/g, ''))}
                      className="rounded-r-none"
                      placeholder="mysite"
                    />
                    <div className="flex items-center border border-l-0 border-input bg-muted px-3 rounded-r-md">
                      .xenabyte.com
                    </div>
                  </div>
                  <p className="text-xs text-muted-foreground">
                    Only lowercase letters, numbers, and hyphens allowed
                  </p>
                </div>
              </div>
              
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsSubdomainDialogOpen(false)}>
                  Cancel
                </Button>
                <Button 
                  onClick={handleCreateSubdomain} 
                  disabled={!newSubdomain || !selectedWebsite || isSubmitting}
                >
                  {isSubmitting ? "Creating..." : "Create Subdomain"}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
          
          {/* Custom domain button - only for premium users */}
          <Dialog open={isCustomDomainDialogOpen} onOpenChange={setIsCustomDomainDialogOpen}>
            <DialogTrigger asChild>
              <Button variant="outline" className="glow-secondary">
                <ExternalLink className="mr-2 h-4 w-4" />
                Add Custom Domain
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Add a Custom Domain</DialogTitle>
                <DialogDescription>
                  <span className="text-primary font-medium">Premium Feature:</span> Connect your own domain to your website
                </DialogDescription>
              </DialogHeader>
              
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="website">Select Website</Label>
                  <Select value={selectedWebsite?.toString()} onValueChange={(value) => setSelectedWebsite(parseInt(value))}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select a website" />
                    </SelectTrigger>
                    <SelectContent>
                      {websites?.map((website: any) => (
                        <SelectItem key={website.id} value={website.id.toString()}>
                          {website.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="customDomain">Custom Domain</Label>
                  <Input
                    id="customDomain"
                    value={newCustomDomain}
                    onChange={(e) => setNewCustomDomain(e.target.value.toLowerCase())}
                    placeholder="example.com"
                  />
                  <p className="text-xs text-muted-foreground">
                    Enter the domain without 'http://' or 'https://'
                  </p>
                </div>
              </div>
              
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsCustomDomainDialogOpen(false)}>
                  Cancel
                </Button>
                <Button 
                  onClick={handleCreateCustomDomain}
                  disabled={!newCustomDomain || !selectedWebsite || isSubmitting}
                  className="glow-sm"
                >
                  {isSubmitting ? "Adding..." : "Add Domain"}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </div>
      
      <Tabs defaultValue="all">
        <TabsList>
          <TabsTrigger value="all">All Domains</TabsTrigger>
          <TabsTrigger value="subdomains">Subdomains</TabsTrigger>
          <TabsTrigger value="custom">Custom Domains</TabsTrigger>
        </TabsList>
        
        <TabsContent value="all" className="space-y-4">
          <DomainsTable 
            domains={domains} 
            isLoading={isLoadingDomains}
            onDelete={handleDeleteDomain}
            onVerify={handleVerifyDomain}
          />
        </TabsContent>
        
        <TabsContent value="subdomains" className="space-y-4">
          <DomainsTable 
            domains={domains?.filter((domain: any) => domain.subdomain && !domain.customDomain)} 
            isLoading={isLoadingDomains}
            onDelete={handleDeleteDomain}
            onVerify={handleVerifyDomain}
          />
        </TabsContent>
        
        <TabsContent value="custom" className="space-y-4">
          <DomainsTable 
            domains={domains?.filter((domain: any) => domain.customDomain)} 
            isLoading={isLoadingDomains}
            onDelete={handleDeleteDomain}
            onVerify={handleVerifyDomain}
          />
        </TabsContent>
      </Tabs>
      
      <h2 className="text-2xl font-bold mt-12 mb-4">DNS Configuration</h2>
      <Card>
        <CardHeader>
          <CardTitle>Custom Domain Setup Instructions</CardTitle>
          <CardDescription>
            Follow these steps to configure your custom domain to work with Xenabyte
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="cyber-box">
              <h3 className="text-lg font-medium mb-2">Step 1: Configure DNS Records</h3>
              <p className="mb-4">Add the following DNS records to your domain's DNS settings:</p>
              
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Type</TableHead>
                    <TableHead>Name</TableHead>
                    <TableHead>Value</TableHead>
                    <TableHead>TTL</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  <TableRow>
                    <TableCell className="font-medium">A</TableCell>
                    <TableCell>@</TableCell>
                    <TableCell>203.0.113.1</TableCell>
                    <TableCell>3600</TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell className="font-medium">CNAME</TableCell>
                    <TableCell>www</TableCell>
                    <TableCell>proxy.xenabyte.com</TableCell>
                    <TableCell>3600</TableCell>
                  </TableRow>
                  <TableRow>
                    <TableCell className="font-medium">TXT</TableCell>
                    <TableCell>_xenabyte-verify</TableCell>
                    <TableCell>xenabyte-verify={'{verification-code}'}</TableCell>
                    <TableCell>3600</TableCell>
                  </TableRow>
                </TableBody>
              </Table>
            </div>
            
            <div className="cyber-box">
              <h3 className="text-lg font-medium mb-2">Step 2: Wait for DNS Propagation</h3>
              <p>DNS changes can take up to 48 hours to propagate globally, though it often happens much faster. After configuring your DNS records, click "Verify Domain" to check if your configuration is correct.</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

interface DomainsTableProps {
  domains: any[];
  isLoading: boolean;
  onDelete: (id: number) => void;
  onVerify: (id: number) => void;
}

function DomainsTable({ domains, isLoading, onDelete, onVerify }: DomainsTableProps) {
  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-10">
        <div className="animate-spin w-10 h-10 border-4 border-primary border-t-transparent rounded-full"></div>
      </div>
    );
  }
  
  if (!domains || domains.length === 0) {
    return (
      <Card className="text-center p-10">
        <div className="flex flex-col items-center justify-center p-4">
          <GlobeIcon className="h-12 w-12 text-muted-foreground mb-4" />
          <h3 className="text-xl font-medium mb-2">No domains found</h3>
          <p className="text-muted-foreground mb-6">
            You haven't set up any domains yet. Create your first domain to make your website accessible online.
          </p>
        </div>
      </Card>
    );
  }
  
  return (
    <div className="rounded-md border">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Domain</TableHead>
            <TableHead>Website</TableHead>
            <TableHead className="text-center">Status</TableHead>
            <TableHead className="text-right">Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {domains.map((domain: any) => {
            const domainUrl = domain.customDomain || `${domain.subdomain}.xenabyte.com`;
            
            return (
              <TableRow key={domain.id}>
                <TableCell className="font-medium">
                  <div className="flex items-center">
                    <GlobeIcon className="h-4 w-4 mr-2 text-primary" />
                    <span>{domainUrl}</span>
                  </div>
                </TableCell>
                <TableCell>{domain.websiteName}</TableCell>
                <TableCell className="text-center">
                  {domain.status === "active" ? (
                    <Badge variant="outline" className="bg-green-100 text-green-800 hover:bg-green-200 border-green-200">
                      <Check className="h-3 w-3 mr-1" /> Active
                    </Badge>
                  ) : domain.status === "pending" ? (
                    <Badge variant="outline" className="bg-yellow-100 text-yellow-800 hover:bg-yellow-200 border-yellow-200">
                      <AlertTriangle className="h-3 w-3 mr-1" /> Pending
                    </Badge>
                  ) : (
                    <Badge variant="outline" className="bg-red-100 text-red-800 hover:bg-red-200 border-red-200">
                      <AlertTriangle className="h-3 w-3 mr-1" /> Error
                    </Badge>
                  )}
                </TableCell>
                <TableCell className="text-right">
                  <div className="flex justify-end gap-2">
                    <Button 
                      variant="ghost" 
                      size="icon"
                      onClick={() => window.open(`https://${domainUrl}`, "_blank")}
                      disabled={domain.status !== "active"}
                    >
                      <ExternalLink className="h-4 w-4" />
                    </Button>
                    
                    {domain.customDomain && (
                      <Button 
                        variant="ghost" 
                        size="icon"
                        onClick={() => onVerify(domain.id)}
                        disabled={domain.status === "active"}
                      >
                        <RefreshCw className="h-4 w-4" />
                      </Button>
                    )}
                    
                    <Button 
                      variant="ghost" 
                      size="icon"
                      onClick={() => onDelete(domain.id)}
                    >
                      <Trash2 className="h-4 w-4 text-red-500" />
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            );
          })}
        </TableBody>
      </Table>
    </div>
  );
}