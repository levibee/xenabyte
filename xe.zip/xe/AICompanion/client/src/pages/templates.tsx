import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { LayoutTemplate, FileDown, ShoppingCart, Tag, Filter, Search, Sparkles } from "lucide-react";

import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";

export default function TemplatesPage() {
  const { user, isAuthenticated } = useAuth();
  const { toast } = useToast();
  const [searchQuery, setSearchQuery] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("all");
  const [isPurchaseDialogOpen, setIsPurchaseDialogOpen] = useState(false);
  const [selectedTemplate, setSelectedTemplate] = useState<any>(null);
  const [isProcessing, setIsProcessing] = useState(false);

  // Fetch HTML templates
  const { data: templates, isLoading } = useQuery({
    queryKey: ["/api/templates"],
  });

  // Purchase/download template
  const handlePurchaseTemplate = async () => {
    if (!selectedTemplate) return;
    
    setIsProcessing(true);
    try {
      // For premium users or free templates, download is free
      // For paid templates with free users, they need to purchase
      const isPremium = user?.subscriptionTier === "premium" || user?.subscriptionTier === "enterprise";
      const endpoint = isPremium || !selectedTemplate.isPremium
        ? `/api/templates/${selectedTemplate.id}/download`
        : `/api/templates/${selectedTemplate.id}/purchase`;
      
      const response = await apiRequest("POST", endpoint, {});
      
      // If response contains a download URL, open it
      if (response.downloadUrl) {
        window.open(response.downloadUrl, "_blank");
      }
      
      toast({
        title: isPremium || !selectedTemplate.isPremium ? "Download started" : "Purchase successful",
        description: isPremium || !selectedTemplate.isPremium 
          ? "Your template download has started" 
          : "Payment successful! Your template download has started",
      });
      
      setIsPurchaseDialogOpen(false);
    } catch (error) {
      toast({
        title: "Failed",
        description: "There was an error processing your request. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsProcessing(false);
    }
  };

  // Filter templates based on search and category
  const filteredTemplates = templates
    ? templates.filter((template: any) => {
        const matchesSearch = !searchQuery || 
          template.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
          template.description.toLowerCase().includes(searchQuery.toLowerCase());
        
        const matchesCategory = categoryFilter === "all" || template.category === categoryFilter;
        
        return matchesSearch && matchesCategory;
      })
    : [];

  return (
    <div className="container py-10">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-8 gap-4">
        <div>
          <h1 className="text-3xl md:text-4xl font-bold">Template Library</h1>
          <p className="text-muted-foreground mt-2">Browse, download, or purchase premium HTML templates</p>
        </div>
      </div>
      
      {/* Search and filters */}
      <div className="mb-8 flex flex-col sm:flex-row gap-4">
        <div className="relative flex-grow">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search templates..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-9"
          />
        </div>
        
        <div className="flex gap-2 items-center min-w-[200px]">
          <Filter className="h-4 w-4 text-muted-foreground" />
          <Select value={categoryFilter} onValueChange={setCategoryFilter}>
            <SelectTrigger>
              <SelectValue placeholder="Filter by category" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Categories</SelectItem>
              <SelectItem value="business">Business</SelectItem>
              <SelectItem value="portfolio">Portfolio</SelectItem>
              <SelectItem value="ecommerce">E-commerce</SelectItem>
              <SelectItem value="blog">Blog</SelectItem>
              <SelectItem value="landing">Landing Page</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
      
      <Tabs defaultValue="all">
        <TabsList>
          <TabsTrigger value="all">All Templates</TabsTrigger>
          <TabsTrigger value="free">Free Templates</TabsTrigger>
          <TabsTrigger value="premium">Premium Templates</TabsTrigger>
        </TabsList>
        
        <TabsContent value="all" className="space-y-6">
          <TemplateGrid 
            templates={filteredTemplates}
            isLoading={isLoading}
            onSelectTemplate={(template) => {
              setSelectedTemplate(template);
              setIsPurchaseDialogOpen(true);
            }}
            userSubscription={user?.subscriptionTier}
          />
        </TabsContent>
        
        <TabsContent value="free" className="space-y-6">
          <TemplateGrid 
            templates={filteredTemplates.filter((t: any) => !t.isPremium)}
            isLoading={isLoading}
            onSelectTemplate={(template) => {
              setSelectedTemplate(template);
              setIsPurchaseDialogOpen(true);
            }}
            userSubscription={user?.subscriptionTier}
          />
        </TabsContent>
        
        <TabsContent value="premium" className="space-y-6">
          <TemplateGrid 
            templates={filteredTemplates.filter((t: any) => t.isPremium)}
            isLoading={isLoading}
            onSelectTemplate={(template) => {
              setSelectedTemplate(template);
              setIsPurchaseDialogOpen(true);
            }}
            userSubscription={user?.subscriptionTier}
          />
        </TabsContent>
      </Tabs>
      
      {/* Purchase/Download Dialog */}
      {selectedTemplate && (
        <Dialog open={isPurchaseDialogOpen} onOpenChange={setIsPurchaseDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>
                {user?.subscriptionTier === "premium" || user?.subscriptionTier === "enterprise" || !selectedTemplate.isPremium
                  ? "Download Template"
                  : "Purchase Template"}
              </DialogTitle>
              <DialogDescription>
                {user?.subscriptionTier === "premium" || user?.subscriptionTier === "enterprise"
                  ? "Premium benefit: Download this template for free"
                  : selectedTemplate.isPremium
                  ? `This premium template costs $${(selectedTemplate.downloadPrice / 100).toFixed(2)}`
                  : "This template is free to download"}
              </DialogDescription>
            </DialogHeader>
            
            <div className="py-4">
              <div className="flex gap-4 items-start">
                <div className="h-20 w-20 bg-primary/10 rounded-md flex items-center justify-center flex-shrink-0">
                  <LayoutTemplate className="h-10 w-10 text-primary" />
                </div>
                <div>
                  <h3 className="font-medium text-lg">{selectedTemplate.name}</h3>
                  <p className="text-muted-foreground text-sm">{selectedTemplate.description}</p>
                  <div className="flex gap-2 mt-2">
                    <Badge variant="outline">{selectedTemplate.category}</Badge>
                    {selectedTemplate.isPremium && (
                      <Badge className="bg-primary">Premium</Badge>
                    )}
                  </div>
                </div>
              </div>
              
              {!isAuthenticated && selectedTemplate.isPremium && (
                <div className="mt-6 bg-yellow-50 border border-yellow-200 rounded-md p-4 text-sm text-yellow-800">
                  <p className="font-medium">Login required</p>
                  <p>You need to log in to download premium templates.</p>
                </div>
              )}
              
              {isAuthenticated && user?.subscriptionTier === "free" && selectedTemplate.isPremium && (
                <div className="mt-6 bg-gradient-to-r from-primary/5 to-secondary/5 border border-primary/20 rounded-md p-4">
                  <div className="flex gap-2 items-center mb-2">
                    <Sparkles className="h-4 w-4 text-primary" />
                    <p className="font-medium text-sm">Premium User Benefit</p>
                  </div>
                  <p className="text-sm text-muted-foreground">Upgrade to Premium and download all templates for free!</p>
                </div>
              )}
            </div>
            
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsPurchaseDialogOpen(false)}>
                Cancel
              </Button>
              <Button 
                onClick={handlePurchaseTemplate}
                disabled={isProcessing || (!isAuthenticated && selectedTemplate.isPremium)}
                className={user?.subscriptionTier === "premium" || user?.subscriptionTier === "enterprise" ? "glow" : ""}
              >
                {isProcessing ? "Processing..." : (
                  <>
                    {user?.subscriptionTier === "premium" || user?.subscriptionTier === "enterprise" || !selectedTemplate.isPremium
                      ? <><FileDown className="h-4 w-4 mr-2" /> Download</>
                      : <><ShoppingCart className="h-4 w-4 mr-2" /> Purchase ${(selectedTemplate.downloadPrice / 100).toFixed(2)}</>
                    }
                  </>
                )}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}

interface TemplateGridProps {
  templates: any[];
  isLoading: boolean;
  onSelectTemplate: (template: any) => void;
  userSubscription?: string;
}

function TemplateGrid({ templates, isLoading, onSelectTemplate, userSubscription }: TemplateGridProps) {
  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-10">
        <div className="animate-spin w-10 h-10 border-4 border-primary border-t-transparent rounded-full"></div>
      </div>
    );
  }
  
  if (!templates || templates.length === 0) {
    return (
      <Card className="text-center p-10">
        <div className="flex flex-col items-center justify-center p-4">
          <LayoutTemplate className="h-12 w-12 text-muted-foreground mb-4" />
          <h3 className="text-xl font-medium mb-2">No templates found</h3>
          <p className="text-muted-foreground">
            No templates match your current search or filter criteria.
          </p>
        </div>
      </Card>
    );
  }
  
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {templates.map((template: any) => (
        <TemplateCard
          key={template.id}
          template={template}
          onClick={() => onSelectTemplate(template)}
          isPremiumUser={userSubscription === "premium" || userSubscription === "enterprise"}
        />
      ))}
    </div>
  );
}

interface TemplateCardProps {
  template: any;
  onClick: () => void;
  isPremiumUser: boolean;
}

function TemplateCard({ template, onClick, isPremiumUser }: TemplateCardProps) {
  return (
    <div className="group card-futuristic p-1 overflow-hidden">
      <Card className="overflow-hidden h-full">
        <div className="relative h-48 bg-gradient-to-br from-primary/10 to-secondary/10 flex items-center justify-center overflow-hidden">
          {template.previewImage ? (
            <img 
              src={template.previewImage} 
              alt={template.name} 
              className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
            />
          ) : (
            <div className="p-4 rounded-full bg-primary/10">
              <LayoutTemplate className="h-12 w-12 text-primary" />
            </div>
          )}
          
          {/* Futuristic accents */}
          <div className="absolute bottom-0 left-0 w-1/3 h-0.5 bg-gradient-to-r from-primary to-transparent"></div>
          <div className="absolute top-0 right-0 w-1/3 h-0.5 bg-gradient-to-l from-secondary to-transparent"></div>
          
          {/* Premium badge */}
          {template.isPremium && (
            <div className="absolute top-2 right-2">
              <Badge className="bg-gradient-to-r from-primary to-secondary text-white font-medium">
                <Sparkles className="h-3 w-3 mr-1" /> Premium
              </Badge>
            </div>
          )}
        </div>
        
        <CardHeader className="pb-2">
          <CardTitle>{template.name}</CardTitle>
          <CardDescription>{template.category}</CardDescription>
        </CardHeader>
        
        <CardContent>
          <p className="text-sm text-muted-foreground line-clamp-2 mb-4">
            {template.description}
          </p>
          
          <div className="flex justify-between items-center">
            <div>
              {template.isPremium && !isPremiumUser ? (
                <div className="flex items-center">
                  <Tag className="h-4 w-4 mr-1 text-primary" />
                  <span className="font-medium">${(template.downloadPrice / 100).toFixed(2)}</span>
                </div>
              ) : (
                <Badge variant="outline" className="bg-green-50 text-green-700 hover:bg-green-100 border-green-200">
                  Free Download
                </Badge>
              )}
            </div>
            
            <div className="text-sm text-muted-foreground">
              {template.downloads} downloads
            </div>
          </div>
        </CardContent>
        
        <CardFooter>
          <Button 
            className="w-full"
            variant={template.isPremium && !isPremiumUser ? "default" : "outline"}
            onClick={onClick}
          >
            {template.isPremium && !isPremiumUser ? (
              <><ShoppingCart className="h-4 w-4 mr-2" /> Purchase</>
            ) : (
              <><FileDown className="h-4 w-4 mr-2" /> Download</>
            )}
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
}