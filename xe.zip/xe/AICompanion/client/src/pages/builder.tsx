import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { ArrowLeft, ArrowRight } from "lucide-react";
import StepIndicator from "@/components/builder/step-indicator";
import TemplateSelection from "@/components/builder/template-selection";
import StyleCustomization from "@/components/builder/style-customization";
import ContentEditor from "@/components/builder/content-editor";
import FineTuning from "@/components/builder/fine-tuning";
import ExportOptions from "@/components/builder/export-options";
import WebsitePreview from "@/components/preview/website-preview";
import useWebsiteBuilder from "@/hooks/use-website-builder";
import { useToast } from "@/hooks/use-toast";

export default function Builder() {
  const [currentStep, setCurrentStep] = useState(1);
  const { toast } = useToast();
  const {
    templates,
    websiteData,
    selectTemplate,
    updateStyle,
    updateContent,
    updateSettings,
    isLoading,
    error,
  } = useWebsiteBuilder();

  useEffect(() => {
    if (error) {
      toast({
        title: "Error",
        description: error,
        variant: "destructive",
      });
    }
  }, [error, toast]);

  const handleNextStep = () => {
    if (currentStep === 1 && !websiteData.templateId) {
      toast({
        title: "Template Required",
        description: "Please select a template to continue.",
        variant: "destructive",
      });
      return;
    }
    
    if (currentStep < 5) {
      setCurrentStep(currentStep + 1);
      window.scrollTo(0, 0);
    }
  };

  const handlePrevStep = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
      window.scrollTo(0, 0);
    }
  };

  const handleStepClick = (step: number) => {
    if (step < currentStep || websiteData.templateId) {
      setCurrentStep(step);
      window.scrollTo(0, 0);
    } else if (step > 1 && !websiteData.templateId) {
      toast({
        title: "Template Required",
        description: "Please select a template first.",
        variant: "destructive",
      });
    }
  };

  const steps = [
    { id: 1, title: "Choose Template" },
    { id: 2, title: "Customize Style" },
    { id: 3, title: "Add Content" },
    { id: 4, title: "Fine-tune" },
    { id: 5, title: "Export" },
  ];

  return (
    <div className="flex flex-col min-h-[calc(100vh-64px-56px)]">
      <StepIndicator
        currentStep={currentStep}
        steps={steps}
        onStepClick={handleStepClick}
      />

      <main className="flex flex-col lg:flex-row flex-1 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 gap-6">
        {/* Editor panel */}
        <div className="w-full lg:w-1/2 space-y-6">
          {isLoading ? (
            <div className="flex items-center justify-center h-64">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
            </div>
          ) : (
            <>
              {currentStep === 1 && (
                <TemplateSelection
                  templates={templates}
                  selectedTemplate={websiteData.templateId}
                  onSelectTemplate={selectTemplate}
                />
              )}

              {currentStep === 2 && (
                <StyleCustomization
                  style={websiteData.style}
                  onStyleChange={updateStyle}
                />
              )}

              {currentStep === 3 && (
                <ContentEditor
                  content={websiteData.content}
                  onContentChange={updateContent}
                />
              )}

              {currentStep === 4 && (
                <FineTuning
                  settings={websiteData.settings}
                  onSettingsChange={updateSettings}
                />
              )}

              {currentStep === 5 && (
                <ExportOptions websiteData={websiteData} />
              )}

              <div className="flex justify-between mt-6">
                <Button
                  onClick={handlePrevStep}
                  variant="outline"
                  className="gap-2"
                  disabled={currentStep === 1}
                >
                  <ArrowLeft className="h-4 w-4" />
                  Previous
                </Button>
                {currentStep < 5 ? (
                  <Button onClick={handleNextStep} className="gap-2">
                    Next
                    <ArrowRight className="h-4 w-4" />
                  </Button>
                ) : null}
              </div>
            </>
          )}
        </div>

        {/* Preview panel */}
        <div className="w-full lg:w-1/2 flex flex-col">
          <WebsitePreview websiteData={websiteData} />
        </div>
      </main>
    </div>
  );
}
