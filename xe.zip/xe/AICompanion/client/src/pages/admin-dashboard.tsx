import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { 
  Users, 
  CreditCard, 
  BarChart3, 
  Settings, 
  Globe, 
  Shield, 
  BellRing,
  CheckCircle2,
  XCircle,
  LayoutTemplate,
  Upload,
  FileType,
  Trash2
} from "lucide-react";

import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/hooks/useAuth";
import { apiRequest } from "@/lib/queryClient";

export default function AdminDashboard() {
  const { user, isAuthenticated } = useAuth();
  const [activeTab, setActiveTab] = useState("users");
  
  // Redirecting non-admin users
  if (!isAuthenticated) {
    return (
      <div className="flex h-screen items-center justify-center">
        <Card className="w-[400px]">
          <CardHeader>
            <CardTitle className="text-center">Access Denied</CardTitle>
            <CardDescription className="text-center">
              You need to be logged in as an admin to access this page.
            </CardDescription>
          </CardHeader>
          <CardContent className="flex justify-center">
            <Button onClick={() => window.location.href = "/"}>Return to Home</Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="container py-10">
      <div className="mb-8 space-y-4">
        <h1 className="text-4xl font-bold tracking-tight">Admin Dashboard</h1>
        <p className="text-muted-foreground">
          Manage users, monitor payments, and view analytics for your AI website generator platform.
        </p>
      </div>

      {/* Main Dashboard Layout */}
      <div className="flex flex-col space-y-8">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
          <div className="flex items-center justify-between">
            <TabsList className="grid w-full md:w-auto grid-cols-2 md:grid-cols-6 gap-2">
              <TabsTrigger value="users" className="flex items-center gap-2">
                <Users className="h-4 w-4" />
                <span className="hidden md:inline">Users</span>
              </TabsTrigger>
              <TabsTrigger value="payments" className="flex items-center gap-2">
                <CreditCard className="h-4 w-4" />
                <span className="hidden md:inline">Payments</span>
              </TabsTrigger>
              <TabsTrigger value="websites" className="flex items-center gap-2">
                <Globe className="h-4 w-4" />
                <span className="hidden md:inline">Websites</span>
              </TabsTrigger>
              <TabsTrigger value="templates" className="flex items-center gap-2">
                <LayoutTemplate className="h-4 w-4" />
                <span className="hidden md:inline">Templates</span>
              </TabsTrigger>
              <TabsTrigger value="analytics" className="flex items-center gap-2">
                <BarChart3 className="h-4 w-4" />
                <span className="hidden md:inline">Analytics</span>
              </TabsTrigger>
              <TabsTrigger value="settings" className="flex items-center gap-2">
                <Settings className="h-4 w-4" />
                <span className="hidden md:inline">Settings</span>
              </TabsTrigger>
            </TabsList>

            <div className="hidden md:flex items-center space-x-2">
              <Button variant="outline" size="sm" className="h-8 gap-1">
                <BellRing className="h-3.5 w-3.5" />
                <span className="hidden md:inline">Notifications</span>
              </Button>
              <Button variant="outline" size="sm" className="h-8 gap-1">
                <Shield className="h-3.5 w-3.5" />
                <span className="hidden md:inline">Security Log</span>
              </Button>
            </div>
          </div>

          {/* Users Tab */}
          <TabsContent value="users" className="space-y-4">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold">User Management</h2>
              <div className="flex space-x-2">
                <div className="relative">
                  <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                  <Input
                    type="search"
                    placeholder="Search users..."
                    className="w-full pl-8 md:w-[250px] lg:w-[300px]"
                  />
                </div>
                <Select defaultValue="all">
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="Filter by status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Users</SelectItem>
                    <SelectItem value="active">Active</SelectItem>
                    <SelectItem value="inactive">Inactive</SelectItem>
                    <SelectItem value="premium">Premium</SelectItem>
                    <SelectItem value="enterprise">Enterprise</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <Card>
              <CardContent className="p-0">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-[50px]">ID</TableHead>
                      <TableHead>User</TableHead>
                      <TableHead>Email</TableHead>
                      <TableHead>Subscription</TableHead>
                      <TableHead className="text-center">Status</TableHead>
                      <TableHead className="text-center">Websites</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {mockUserData.map((user) => (
                      <TableRow key={user.id}>
                        <TableCell className="font-mono">{user.id}</TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center">
                              <span className="font-semibold text-primary">{user.name.charAt(0)}</span>
                            </div>
                            <div>
                              <div className="font-medium">{user.name}</div>
                              <div className="text-xs text-muted-foreground">Created {user.createdAt}</div>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>{user.email}</TableCell>
                        <TableCell>
                          <SubscriptionBadge plan={user.subscription} />
                        </TableCell>
                        <TableCell className="text-center">
                          {user.status === "active" ? (
                            <Badge variant="outline" className="border-green-500 text-green-500 bg-green-500/10">Active</Badge>
                          ) : (
                            <Badge variant="outline" className="border-red-500 text-red-500 bg-red-500/10">Inactive</Badge>
                          )}
                        </TableCell>
                        <TableCell className="text-center">{user.websites}</TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end gap-2">
                            <Button variant="ghost" size="sm">Edit</Button>
                            <Button variant="ghost" size="sm" className="text-red-500 hover:text-red-700 hover:bg-red-100">
                              Delete
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Payments Tab */}
          <TabsContent value="payments" className="space-y-4">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold">Payment History</h2>
              <div className="flex space-x-2">
                <Select defaultValue="all">
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="Payment method" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Methods</SelectItem>
                    <SelectItem value="mpesa">M-Pesa</SelectItem>
                    <SelectItem value="card">Card Payment</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <Card>
              <CardContent className="p-0">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-[100px]">Transaction ID</TableHead>
                      <TableHead>Date</TableHead>
                      <TableHead>User</TableHead>
                      <TableHead>Amount</TableHead>
                      <TableHead>Plan</TableHead>
                      <TableHead>Method</TableHead>
                      <TableHead className="text-center">Status</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {mockPaymentData.map((payment) => (
                      <TableRow key={payment.id}>
                        <TableCell className="font-mono text-xs">{payment.id}</TableCell>
                        <TableCell>{payment.date}</TableCell>
                        <TableCell>{payment.userName}</TableCell>
                        <TableCell className="font-medium">${payment.amount}</TableCell>
                        <TableCell>
                          <SubscriptionBadge plan={payment.plan} />
                        </TableCell>
                        <TableCell>
                          {payment.method === "mpesa" ? (
                            <div className="flex items-center gap-1">
                              <div className="h-4 w-4 rounded-full bg-green-500 flex items-center justify-center">
                                <span className="text-[8px] text-white font-bold">M</span>
                              </div>
                              <span>M-Pesa</span>
                            </div>
                          ) : (
                            <div className="flex items-center gap-1">
                              <CreditCard className="h-4 w-4" />
                              <span>Card</span>
                            </div>
                          )}
                        </TableCell>
                        <TableCell className="text-center">
                          {payment.status === "successful" ? (
                            <Badge variant="outline" className="border-green-500 text-green-500 bg-green-500/10">
                              <CheckCircle2 className="h-3 w-3 mr-1" />
                              Successful
                            </Badge>
                          ) : (
                            <Badge variant="outline" className="border-red-500 text-red-500 bg-red-500/10">
                              <XCircle className="h-3 w-3 mr-1" />
                              Failed
                            </Badge>
                          )}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Websites Tab */}
          <TabsContent value="websites" className="space-y-4">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold">Generated Websites</h2>
              <div className="flex space-x-2">
                <Input
                  type="search"
                  placeholder="Search websites..."
                  className="w-[250px]"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {mockWebsiteData.map((website) => (
                <Card key={website.id} className="overflow-hidden">
                  <div className="h-40 bg-gradient-to-br from-primary/80 to-secondary/80 flex items-center justify-center">
                    <Globe className="h-12 w-12 text-white" />
                  </div>
                  <CardHeader className="pb-2">
                    <CardTitle>{website.name}</CardTitle>
                    <CardDescription>Created by {website.creator}</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Created:</span>
                      <span>{website.created}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Type:</span>
                      <span>{website.type}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Status:</span>
                      <Badge variant="outline" className={
                        website.status === "Published" 
                          ? "border-green-500 text-green-500 bg-green-500/10"
                          : "border-amber-500 text-amber-500 bg-amber-500/10"
                      }>
                        {website.status}
                      </Badge>
                    </div>
                    <div className="flex gap-2 pt-2">
                      <Button variant="outline" size="sm" className="w-full">View</Button>
                      <Button variant="default" size="sm" className="w-full">Edit</Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Templates Tab */}
          <TabsContent value="templates" className="space-y-4">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold">HTML Templates Management</h2>
              <Button className="glow">
                <Upload className="h-4 w-4 mr-2" />
                Upload New Template
              </Button>
            </div>
            
            <Card>
              <CardHeader>
                <CardTitle>Upload Template</CardTitle>
                <CardDescription>
                  Upload HTML templates that users can customize and use as starting points for their websites
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div className="border-2 border-dashed border-border rounded-lg p-8 text-center">
                    <div className="flex flex-col items-center justify-center gap-4">
                      <div className="p-4 rounded-full bg-primary/10">
                        <FileType className="h-10 w-10 text-primary" />
                      </div>
                      <div className="space-y-2">
                        <h3 className="font-medium">Drag and drop files here</h3>
                        <p className="text-sm text-muted-foreground">
                          Upload HTML, CSS, and JS files for your template, or click to browse
                        </p>
                      </div>
                      <input 
                        type="file" 
                        className="hidden" 
                        accept=".html,.css,.js,.zip" 
                        id="template-upload"
                      />
                      <Button 
                        variant="outline" 
                        onClick={() => document.getElementById('template-upload')?.click()}
                      >
                        Choose Files
                      </Button>
                    </div>
                  </div>
                  
                  <div className="bg-muted/40 rounded-lg p-4">
                    <h3 className="font-medium mb-4">Template Requirements</h3>
                    <ul className="space-y-2 text-sm">
                      <li className="flex items-start">
                        <div className="mr-2 h-5 w-5 text-primary flex-shrink-0">✓</div>
                        <span>HTML files must be valid HTML5</span>
                      </li>
                      <li className="flex items-start">
                        <div className="mr-2 h-5 w-5 text-primary flex-shrink-0">✓</div>
                        <span>Include placeholders for user content with specially formatted comments</span>
                      </li>
                      <li className="flex items-start">
                        <div className="mr-2 h-5 w-5 text-primary flex-shrink-0">✓</div>
                        <span>ZIP files should contain a complete website structure</span>
                      </li>
                      <li className="flex items-start">
                        <div className="mr-2 h-5 w-5 text-primary flex-shrink-0">✓</div>
                        <span>All external resources must be properly referenced</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <h3 className="text-xl font-medium mt-8 mb-4">Existing Templates</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {/* Template Cards - These would be dynamically generated from database */}
              <TemplateCard 
                name="Business Portfolio"
                category="Business"
                preview="/templates/business-preview.jpg"
                downloads={156}
                dateAdded="May 10, 2024"
              />
              <TemplateCard 
                name="E-commerce Store"
                category="E-commerce"
                preview="/templates/ecommerce-preview.jpg"
                downloads={342}
                dateAdded="April 28, 2024"
              />
              <TemplateCard 
                name="Personal Blog"
                category="Blog"
                preview="/templates/blog-preview.jpg"
                downloads={98}
                dateAdded="May 15, 2024"
              />
              <TemplateCard 
                name="Landing Page"
                category="Marketing"
                preview="/templates/landing-preview.jpg"
                downloads={211}
                dateAdded="May 5, 2024"
              />
            </div>
          </TabsContent>
          
          {/* Analytics Tab */}
          <TabsContent value="analytics" className="space-y-4">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold">Platform Analytics</h2>
              <div className="flex space-x-2">
                <Select defaultValue="month">
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="Time period" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="day">Today</SelectItem>
                    <SelectItem value="week">This Week</SelectItem>
                    <SelectItem value="month">This Month</SelectItem>
                    <SelectItem value="year">This Year</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <AnalyticsCard 
                title="Total Users" 
                value="345" 
                trend="+12%" 
                trendType="positive" 
                icon={<Users className="h-4 w-4" />} 
              />
              <AnalyticsCard 
                title="Websites Generated" 
                value="874" 
                trend="+27%" 
                trendType="positive" 
                icon={<Globe className="h-4 w-4" />} 
              />
              <AnalyticsCard 
                title="Revenue" 
                value="$12,580" 
                trend="+18%" 
                trendType="positive" 
                icon={<CreditCard className="h-4 w-4" />} 
              />
              <AnalyticsCard 
                title="Active Subscriptions" 
                value="187" 
                trend="+5%" 
                trendType="positive" 
                icon={<CheckCircle2 className="h-4 w-4" />} 
              />
            </div>

            <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
              <Card className="lg:col-span-2">
                <CardHeader>
                  <CardTitle>Revenue Overview</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-[300px] flex items-center justify-center">
                    <div className="text-muted-foreground">Revenue chart goes here</div>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader>
                  <CardTitle>Subscription Distribution</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-[300px] flex items-center justify-center">
                    <div className="text-muted-foreground">Pie chart goes here</div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Settings Tab */}
          <TabsContent value="settings" className="space-y-4">
            <h2 className="text-2xl font-bold">Admin Settings</h2>
            
            <Card>
              <CardHeader>
                <CardTitle>API Keys</CardTitle>
                <CardDescription>
                  Manage your API keys for external services
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <div>
                      <h3 className="font-medium">OpenAI API Key</h3>
                      <p className="text-sm text-muted-foreground">Used for AI content generation</p>
                    </div>
                    <Button variant="outline" size="sm">Update</Button>
                  </div>
                  <Input type="password" value="●●●●●●●●●●●●●●●●●●●●●●" readOnly />
                </div>
                
                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <div>
                      <h3 className="font-medium">Anthropic API Key</h3>
                      <p className="text-sm text-muted-foreground">Used for advanced AI responses</p>
                    </div>
                    <Button variant="outline" size="sm">Update</Button>
                  </div>
                  <Input type="password" value="●●●●●●●●●●●●●●●●●●●●●●" readOnly />
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <div>
                      <h3 className="font-medium">Stripe Secret Key</h3>
                      <p className="text-sm text-muted-foreground">For payment processing</p>
                    </div>
                    <Button variant="outline" size="sm">Update</Button>
                  </div>
                  <Input type="password" value="●●●●●●●●●●●●●●●●●●●●●●" readOnly />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>General Settings</CardTitle>
                <CardDescription>
                  Configure system-wide settings
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <h3 className="font-medium">Maximum websites per free user</h3>
                  <Input type="number" defaultValue="3" />
                </div>
                
                <div className="space-y-2">
                  <h3 className="font-medium">Maximum websites per premium user</h3>
                  <Input type="number" defaultValue="25" />
                </div>

                <div className="space-y-2">
                  <h3 className="font-medium">System Notifications</h3>
                  <div className="flex items-center space-x-2">
                    <Switch id="notifications" defaultChecked />
                    <Label htmlFor="notifications">Enable email notifications for payments</Label>
                  </div>
                </div>

                <div className="pt-4">
                  <Button>Save Settings</Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}

// Mock Data
const mockUserData = [
  { id: "U1001", name: "Alex Johnson", email: "alex@example.com", subscription: "premium", status: "active", websites: 7, createdAt: "2023-08-15" },
  { id: "U1002", name: "Maria Garcia", email: "maria@example.com", subscription: "free", status: "active", websites: 2, createdAt: "2023-09-22" },
  { id: "U1003", name: "John Smith", email: "john@example.com", subscription: "enterprise", status: "active", websites: 15, createdAt: "2023-07-10" },
  { id: "U1004", name: "Sarah Williams", email: "sarah@example.com", subscription: "premium", status: "inactive", websites: 4, createdAt: "2023-11-05" },
  { id: "U1005", name: "David Lee", email: "david@example.com", subscription: "free", status: "active", websites: 1, createdAt: "2024-01-20" },
];

const mockPaymentData = [
  { id: "T25839", date: "2024-05-01", userName: "Alex Johnson", amount: 15.00, plan: "premium", method: "card", status: "successful" },
  { id: "T25838", date: "2024-05-01", userName: "John Smith", amount: 39.00, plan: "enterprise", method: "mpesa", status: "successful" },
  { id: "T25837", date: "2024-04-30", userName: "Sarah Williams", amount: 15.00, plan: "premium", method: "card", status: "failed" },
  { id: "T25836", date: "2024-04-28", userName: "Alex Johnson", amount: 15.00, plan: "premium", method: "mpesa", status: "successful" },
  { id: "T25835", date: "2024-04-25", userName: "Maria Garcia", amount: 15.00, plan: "premium", method: "card", status: "successful" },
];

const mockWebsiteData = [
  { id: 1, name: "TechStartup Homepage", creator: "Alex Johnson", created: "May 2, 2024", type: "Business", status: "Published" },
  { id: 2, name: "Fashion Blog", creator: "Maria Garcia", created: "May 1, 2024", type: "Blog", status: "Draft" },
  { id: 3, name: "Restaurant Menu", creator: "John Smith", created: "April 28, 2024", type: "E-Commerce", status: "Published" },
  { id: 4, name: "Fitness Coaching", creator: "Sarah Williams", created: "April 25, 2024", type: "Portfolio", status: "Published" },
  { id: 5, name: "Photography Portfolio", creator: "David Lee", created: "April 20, 2024", type: "Portfolio", status: "Draft" },
  { id: 6, name: "E-Book Landing Page", creator: "Alex Johnson", created: "April 15, 2024", type: "Landing Page", status: "Published" },
];

// Utility Components
function Search({ className, ...props }: React.ComponentProps<typeof Users>) {
  return (
    <Users className={className} {...props} />
  );
}

function Label({ className, ...props }: React.ComponentProps<"label">) {
  return (
    <label className={className} {...props} />
  );
}

function Switch({ className, ...props }: React.ComponentProps<"input">) {
  return (
    <div className="relative inline-flex h-6 w-11 items-center rounded-full bg-muted transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background disabled:pointer-events-none disabled:opacity-50 data-[state=checked]:bg-primary">
      <input 
        type="checkbox" 
        className="peer h-6 w-11 cursor-pointer appearance-none rounded-full" 
        {...props} 
      />
      <span className="pointer-events-none absolute h-5 w-5 translate-x-0.5 rounded-full bg-background shadow-lg ring-0 transition-transform peer-checked:translate-x-5" />
    </div>
  );
}

function SubscriptionBadge({ plan }: { plan: string }) {
  switch (plan) {
    case "free":
      return <Badge variant="outline">Free</Badge>;
    case "premium":
      return <Badge variant="outline" className="border-primary text-primary bg-primary/10">Premium</Badge>;
    case "enterprise":
      return <Badge variant="outline" className="border-secondary text-secondary bg-secondary/10">Enterprise</Badge>;
    default:
      return <Badge variant="outline">Unknown</Badge>;
  }
}

function TemplateCard({
  name,
  category,
  preview,
  downloads,
  dateAdded
}: {
  name: string;
  category: string;
  preview: string;
  downloads: number;
  dateAdded: string;
}) {
  return (
    <Card className="overflow-hidden">
      <div className="h-40 bg-gradient-to-br from-primary/20 to-secondary/20 flex items-center justify-center">
        <div className="p-3 rounded-full bg-primary/10">
          <LayoutTemplate className="h-8 w-8 text-primary" />
        </div>
      </div>
      <CardHeader className="pb-2">
        <CardTitle>{name}</CardTitle>
        <CardDescription>Category: {category}</CardDescription>
      </CardHeader>
      <CardContent className="space-y-2">
        <div className="flex justify-between text-sm">
          <span className="text-muted-foreground">Downloads:</span>
          <span>{downloads}</span>
        </div>
        <div className="flex justify-between text-sm">
          <span className="text-muted-foreground">Added:</span>
          <span>{dateAdded}</span>
        </div>
        <div className="flex gap-2 pt-2">
          <Button variant="outline" size="sm" className="w-full">Preview</Button>
          <Button variant="outline" size="sm" className="w-full text-red-500 hover:text-red-700 hover:bg-red-100">
            <Trash2 className="h-4 w-4 mr-1" />
            Delete
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

function AnalyticsCard({ 
  title, 
  value, 
  trend, 
  trendType, 
  icon 
}: { 
  title: string; 
  value: string; 
  trend: string; 
  trendType: "positive" | "negative"; 
  icon: React.ReactNode; 
}) {
  return (
    <Card>
      <CardContent className="p-6">
        <div className="flex justify-between items-start">
          <div>
            <p className="text-sm font-medium text-muted-foreground">{title}</p>
            <h3 className="text-2xl font-bold mt-2">{value}</h3>
          </div>
          <div className="p-2 bg-primary/10 rounded-full">
            {icon}
          </div>
        </div>
        <div className="mt-4">
          <span 
            className={`text-xs font-medium ${
              trendType === "positive" ? "text-green-500" : "text-red-500"
            }`}
          >
            {trend}
          </span>
          <span className="text-xs text-muted-foreground ml-1">from last month</span>
        </div>
      </CardContent>
    </Card>
  );
}