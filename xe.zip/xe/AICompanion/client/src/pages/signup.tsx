import { useState } from "react";
import { Link } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { Checkbox } from "@/components/ui/checkbox";
import { CreditCard, CheckCircle, ArrowRight, LockIcon, Sparkles } from "lucide-react";

const signupSchema = z.object({
  firstName: z.string().min(2, "First name must be at least 2 characters"),
  lastName: z.string().min(2, "Last name must be at least 2 characters"),
  email: z.string().email("Please enter a valid email address"),
  password: z.string().min(8, "Password must be at least 8 characters"),
  terms: z.boolean().refine(val => val === true, {
    message: "You must agree to the terms and conditions",
  }),
});

type SignupFormValues = z.infer<typeof signupSchema>;

export default function Signup() {
  const [selectedPlan, setSelectedPlan] = useState<string>("free");
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);

  const form = useForm<SignupFormValues>({
    resolver: zodResolver(signupSchema),
    defaultValues: {
      firstName: "",
      lastName: "",
      email: "",
      password: "",
      terms: false,
    },
  });

  async function onSubmit(data: SignupFormValues) {
    setIsSubmitting(true);
    try {
      // In a real implementation, this would send the data to your server
      await apiRequest("POST", "/api/signup", {
        ...data, 
        plan: selectedPlan
      });
      
      toast({
        title: "Account created!",
        description: "Redirecting you to login...",
      });
      
      // Redirect to login page after successful signup
      setTimeout(() => {
        window.location.href = "/auth/google";
      }, 2000);
    } catch (error) {
      toast({
        title: "Something went wrong",
        description: "Please try again later",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  }

  return (
    <div className="container max-w-6xl py-10 lg:py-16">
      <div className="text-center mb-8">
        <h1 className="text-4xl font-bold mb-4">Join Xenabyte</h1>
        <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
          Create an account to start building your AI-powered websites and unlock the full potential of our platform.
        </p>
      </div>

      <div className="grid md:grid-cols-5 gap-8 items-start">
        {/* Subscription Selection */}
        <div className="md:col-span-2">
          <Card className="border-border">
            <CardHeader>
              <CardTitle>Choose Your Plan</CardTitle>
              <CardDescription>
                Select the plan that works best for your needs
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Tabs 
                defaultValue="free" 
                value={selectedPlan}
                onValueChange={setSelectedPlan}
                className="w-full"
              >
                <TabsList className="grid grid-cols-3 mb-4">
                  <TabsTrigger value="free">Free</TabsTrigger>
                  <TabsTrigger value="premium">Premium</TabsTrigger>
                  <TabsTrigger value="enterprise">Enterprise</TabsTrigger>
                </TabsList>
                
                <TabsContent value="free">
                  <PlanDetails 
                    title="Free Plan" 
                    price="$0/month"
                    features={[
                      "3 AI-generated websites",
                      "Basic customization",
                      "Export HTML/CSS",
                      "Community support"
                    ]}
                  />
                </TabsContent>
                
                <TabsContent value="premium">
                  <div className="border-2 border-primary rounded-lg p-4 relative">
                    <div className="absolute -top-3 right-4 bg-primary text-primary-foreground px-3 py-1 text-xs rounded-full">
                      POPULAR
                    </div>
                    <PlanDetails 
                      title="Premium Plan" 
                      price="$15/month"
                      features={[
                        "Unlimited AI-generated websites",
                        "Advanced customization",
                        "Export HTML/CSS/JS",
                        "1 custom domain",
                        "Priority email support"
                      ]}
                    />
                  </div>
                </TabsContent>
                
                <TabsContent value="enterprise">
                  <PlanDetails 
                    title="Enterprise Plan" 
                    price="$39/month"
                    features={[
                      "Everything in Premium",
                      "Multiple team members",
                      "5 custom domains",
                      "Admin dashboard",
                      "Priority support",
                      "Advanced analytics"
                    ]}
                  />
                </TabsContent>
              </Tabs>
            </CardContent>
            <CardFooter className="flex flex-col text-sm text-muted-foreground">
              <div className="flex items-center mb-2">
                <LockIcon className="h-4 w-4 mr-2" />
                <span>Secured payment processing</span>
              </div>
              <div className="flex items-center">
                <Sparkles className="h-4 w-4 mr-2" />
                <span>Cancel or change your plan anytime</span>
              </div>
            </CardFooter>
          </Card>
        </div>

        {/* Registration Form */}
        <div className="md:col-span-3">
          <Card className="border-border">
            <CardHeader>
              <CardTitle>Create your account</CardTitle>
              <CardDescription>
                Enter your information to get started
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="firstName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>First name</FormLabel>
                          <FormControl>
                            <Input placeholder="John" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="lastName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Last name</FormLabel>
                          <FormControl>
                            <Input placeholder="Doe" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <FormField
                    control={form.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Email</FormLabel>
                        <FormControl>
                          <Input placeholder="john.doe@example.com" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="password"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Password</FormLabel>
                        <FormControl>
                          <Input 
                            type="password" 
                            placeholder="Create a strong password" 
                            {...field} 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="terms"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                        <FormControl>
                          <Checkbox
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                        <div className="space-y-1 leading-none">
                          <FormLabel>
                            I agree to the{" "}
                            <Link href="/terms" className="text-primary underline">
                              terms of service
                            </Link>{" "}
                            and{" "}
                            <Link href="/privacy" className="text-primary underline">
                              privacy policy
                            </Link>
                          </FormLabel>
                          <FormMessage />
                        </div>
                      </FormItem>
                    )}
                  />

                  <div className="pt-4">
                    <Button 
                      type="submit" 
                      className="w-full glow"
                      disabled={isSubmitting}
                    >
                      {isSubmitting ? (
                        <div className="flex items-center">
                          <div className="animate-spin mr-2 h-4 w-4 border-2 border-white border-t-transparent rounded-full"></div>
                          Creating account...
                        </div>
                      ) : (
                        <div className="flex items-center justify-center">
                          Create Account
                          <ArrowRight className="ml-2 h-4 w-4" />
                        </div>
                      )}
                    </Button>
                  </div>

                  <div className="text-center text-sm text-muted-foreground">
                    Already have an account?{" "}
                    <Link href="/auth/google" className="text-primary font-medium">
                      Log in
                    </Link>
                  </div>
                </form>
              </Form>
            </CardContent>
            <CardFooter className="flex justify-center border-t pt-4">
              <div className="flex items-center gap-4">
                <div className="flex items-center">
                  <svg viewBox="0 0 40 40" className="h-6 w-6 mr-2 text-primary" fill="currentColor">
                    <path d="M20 0C8.96 0 0 8.96 0 20s8.96 20 20 20 20-8.96 20-20S31.04 0 20 0zm0 36c-8.84 0-16-7.16-16-16S11.16 4 20 4s16 7.16 16 16-7.16 16-16 16z"/>
                    <path d="M22 10h-4v10h-6l8 10 8-10h-6z"/>
                  </svg>
                  <span>M-Pesa</span>
                </div>
                <Separator orientation="vertical" className="h-6" />
                <div className="flex items-center">
                  <CreditCard className="h-6 w-6 mr-2 text-primary" />
                  <span>Card Payments</span>
                </div>
              </div>
            </CardFooter>
          </Card>
        </div>
      </div>
    </div>
  );
}

function PlanDetails({ 
  title, 
  price, 
  features 
}: { 
  title: string; 
  price: string; 
  features: string[]; 
}) {
  return (
    <div className="space-y-4">
      <div>
        <h3 className="font-medium text-lg">{title}</h3>
        <div className="text-3xl font-bold">{price}</div>
      </div>
      
      <ul className="space-y-2">
        {features.map((feature, index) => (
          <li key={index} className="flex items-start">
            <CheckCircle className="h-5 w-5 text-primary mr-2 mt-0.5" />
            <span>{feature}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}