import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export default function Login() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-100">
      <Card className="w-full max-w-md shadow-lg p-6 bg-white rounded-2xl">
        <CardContent>
          <h2 className="text-2xl font-bold mb-6 text-center">Welcome Back</h2>

          <div className="mb-4">
            <Label htmlFor="email">Email</Label>
            <Input id="email" type="email" placeholder="Enter your email" />
          </div>
          <div className="mb-6">
            <Label htmlFor="password">Password</Label>
            <Input id="password" type="password" placeholder="Enter your password" />
          </div>

          <Button className="w-full mb-4">Log In</Button>

          <hr className="my-4" />

          <Button
            variant="outline"
            className="w-full"
            onClick={() => window.location.href = "https://www.xenabyte.com/auth/google"}
          >
            Sign in with Google
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
