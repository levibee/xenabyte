import { useState, useRef, useEffect } from 'react';
import { Bot, X, Send, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { apiRequest } from '@/lib/queryClient';

// Simple auth state management until we implement the full auth system
const useAuth = () => {
  return {
    user: null,
    isLoading: false,
    isAuthenticated: false
  };
};

type Message = {
  id: number;
  content: string;
  role: 'user' | 'assistant';
  timestamp: Date;
};

export default function Chatbot() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 1,
      content: "Hi! I'm Xenabyte AI assistant. How can I help you with your website creation today?",
      role: 'assistant',
      timestamp: new Date(),
    },
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { user, isAuthenticated } = useAuth();

  // Generate a session ID for unauthenticated users
  const [sessionId] = useState(() => {
    return `guest-${Math.random().toString(36).substring(2, 15)}`;
  });

  // Scroll to bottom of messages
  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages]);

  const handleSendMessage = async () => {
    if (!input.trim()) return;

    // Add user message
    const userMessage: Message = {
      id: messages.length + 1,
      content: input,
      role: 'user',
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);

    try {
      // Send message to API
      const response = await apiRequest('POST', '/api/chat', {
        message: input,
        sessionId,
      });

      if (response.ok) {
        const data = await response.json();
        
        // Add bot response
        const botMessage: Message = {
          id: messages.length + 2,
          content: data.message,
          role: 'assistant',
          timestamp: new Date(),
        };

        setMessages((prev) => [...prev, botMessage]);
      } else {
        // Handle error with fallback message
        const botMessage: Message = {
          id: messages.length + 2,
          content: "I'm having trouble connecting to my systems. Please try again later.",
          role: 'assistant',
          timestamp: new Date(),
        };

        setMessages((prev) => [...prev, botMessage]);
      }
    } catch (error) {
      console.error('Chat error:', error);
      
      // Add error message
      const botMessage: Message = {
        id: messages.length + 2,
        content: "I'm having trouble connecting to my systems. Please try again later.",
        role: 'assistant',
        timestamp: new Date(),
      };

      setMessages((prev) => [...prev, botMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  return (
    <div className="chatbot-container">
      {isOpen && (
        <div className="chatbot-panel border-animated">
          <div className="chatbot-header">
            <div className="flex items-center gap-2">
              <Bot size={20} />
              <span>Xenabyte Assistant</span>
            </div>
            <Button
              variant="ghost"
              size="icon"
              className="h-6 w-6 text-white hover:bg-primary-foreground/20"
              onClick={() => setIsOpen(false)}
            >
              <X size={18} />
            </Button>
          </div>
          <div className="chatbot-messages">
            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex ${
                  message.role === 'user' ? 'justify-end' : 'justify-start'
                }`}
              >
                <div className={message.role === 'user' ? 'message-user' : 'message-bot'}>
                  {message.content}
                </div>
              </div>
            ))}
            <div ref={messagesEndRef} />
          </div>
          <div className="chatbot-input">
            <Input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Type your message..."
              disabled={isLoading}
              className="flex-1"
            />
            <Button
              size="icon"
              disabled={isLoading || !input.trim()}
              onClick={handleSendMessage}
              className="bg-primary text-white"
            >
              {isLoading ? (
                <div className="h-5 w-5 animate-spin rounded-full border-2 border-t-transparent" />
              ) : (
                <Send size={18} />
              )}
            </Button>
          </div>
        </div>
      )}

      <div
        className="chatbot-button"
        onClick={() => setIsOpen(!isOpen)}
      >
        {isOpen ? <X size={24} /> : <Sparkles size={24} />}
      </div>
    </div>
  );
}