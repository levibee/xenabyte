import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/useAuth";
import { Menu, X, ChevronDown, User, LogOut } from "lucide-react";
import xenabyteLogo from "@assets/xenabyte2.png";

import {
  NavigationMenu,
  NavigationMenuContent,
  NavigationMenuItem,
  NavigationMenuLink,
  NavigationMenuList,
  NavigationMenuTrigger,
  navigationMenuTriggerStyle,
} from "@/components/ui/navigation-menu";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { cn } from "@/lib/utils";
import { useIsMobile } from "@/hooks/use-mobile";

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const { user, isAuthenticated, isLoading } = useAuth();
  const isMobile = useIsMobile();
  const [location] = useLocation();
  
  // Close mobile menu when navigating
  useEffect(() => {
    setIsOpen(false);
  }, [location]);

  return (
    <header className="border-b bg-background/80 backdrop-blur-sm sticky top-0 z-50">
      <div className="container flex items-center justify-between h-16 md:h-20">
        {/* Logo */}
        <Link href="/" className="flex items-center gap-2">
          <img src={xenabyteLogo} alt="Xenabyte Logo" className="h-8" />
          <span className="sr-only">Xenabyte</span>
        </Link>

        {/* Desktop Navigation */}
        <div className="hidden md:flex md:items-center gap-2">
          <NavigationMenu>
            <NavigationMenuList>
              <NavigationMenuItem>
                <NavigationMenuTrigger>Products</NavigationMenuTrigger>
                <NavigationMenuContent>
                  <ul className="grid w-[400px] gap-3 p-4 md:w-[500px] md:grid-cols-2">
                    <li className="row-span-3">
                      <NavigationMenuLink asChild>
                        <Link
                          className="flex h-full w-full select-none flex-col justify-end rounded-md bg-gradient-to-b from-primary/20 to-primary/5 p-6 no-underline outline-none focus:shadow-md"
                          href="/ai-builder"
                        >
                          <div className="mb-2 mt-4 text-lg font-medium">
                            AI Website Builder
                          </div>
                          <p className="text-sm leading-tight text-muted-foreground">
                            Generate a custom website with AI in minutes. Just describe what you want.
                          </p>
                        </Link>
                      </NavigationMenuLink>
                    </li>
                    <li>
                      <NavigationMenuLink asChild>
                        <Link
                          href="/builder"
                          className="block select-none space-y-1 rounded-md p-3 leading-none no-underline outline-none transition-colors hover:bg-accent hover:text-accent-foreground focus:bg-accent focus:text-accent-foreground"
                        >
                          <div className="text-sm font-medium leading-none">Visual Builder</div>
                          <p className="line-clamp-2 text-sm leading-snug text-muted-foreground">
                            Drag-and-drop interface to build your website visually.
                          </p>
                        </Link>
                      </NavigationMenuLink>
                    </li>
                    <li>
                      <NavigationMenuLink asChild>
                        <Link
                          href="/templates"
                          className="block select-none space-y-1 rounded-md p-3 leading-none no-underline outline-none transition-colors hover:bg-accent hover:text-accent-foreground focus:bg-accent focus:text-accent-foreground"
                        >
                          <div className="text-sm font-medium leading-none">Templates</div>
                          <p className="line-clamp-2 text-sm leading-snug text-muted-foreground">
                            Ready-made templates to jumpstart your website.
                          </p>
                        </Link>
                      </NavigationMenuLink>
                    </li>
                    <li>
                      <NavigationMenuLink asChild>
                        <Link
                          href="/domains"
                          className="block select-none space-y-1 rounded-md p-3 leading-none no-underline outline-none transition-colors hover:bg-accent hover:text-accent-foreground focus:bg-accent focus:text-accent-foreground"
                        >
                          <div className="text-sm font-medium leading-none">Domains</div>
                          <p className="line-clamp-2 text-sm leading-snug text-muted-foreground">
                            Manage your free and custom website domains.
                          </p>
                        </Link>
                      </NavigationMenuLink>
                    </li>
                  </ul>
                </NavigationMenuContent>
              </NavigationMenuItem>
              <NavigationMenuItem>
                <Link href="/pricing" legacyBehavior passHref>
                  <NavigationMenuLink className={navigationMenuTriggerStyle()}>
                    Pricing
                  </NavigationMenuLink>
                </Link>
              </NavigationMenuItem>
              {isAuthenticated && user?.isAdmin && (
                <NavigationMenuItem>
                  <Link href="/admin" legacyBehavior passHref>
                    <NavigationMenuLink className={navigationMenuTriggerStyle()}>
                      Admin
                    </NavigationMenuLink>
                  </Link>
                </NavigationMenuItem>
              )}
            </NavigationMenuList>
          </NavigationMenu>

          {isLoading ? (
            <div className="h-10 w-10 rounded-full bg-muted animate-pulse"></div>
          ) : isAuthenticated ? (
            <UserMenuDropdown user={user} />
          ) : (
            <div className="flex gap-2 items-center">
              <Button variant="ghost" asChild>
                <a href="/auth/google">Log In</a>
              </Button>
              <Button className="glow" asChild>
                <a href="/auth/google">Get Started</a>
              </Button>
            </div>
          )}
        </div>

        {/* Mobile Menu Toggle */}
        <button
          className="md:hidden flex items-center text-muted-foreground"
          onClick={() => setIsOpen(!isOpen)}
        >
          <span className="sr-only">{isOpen ? "Close menu" : "Open menu"}</span>
          {isOpen ? <X /> : <Menu />}
        </button>
      </div>

      {/* Mobile Menu */}
      {isOpen && (
        <div className="md:hidden py-4 bg-background border-b">
          <div className="container space-y-4">
            <div className="space-y-2">
              <div 
                onClick={() => setIsOpen(false)}
                className="px-2 py-1.5 rounded-md text-sm font-medium hover:bg-accent hover:text-accent-foreground transition-colors"
              >
                <Link href="/ai-builder">AI Website Builder</Link>
              </div>
              <div 
                onClick={() => setIsOpen(false)}
                className="px-2 py-1.5 rounded-md text-sm font-medium hover:bg-accent hover:text-accent-foreground transition-colors"
              >
                <Link href="/builder">Visual Builder</Link>
              </div>
              <div 
                onClick={() => setIsOpen(false)}
                className="px-2 py-1.5 rounded-md text-sm font-medium hover:bg-accent hover:text-accent-foreground transition-colors"
              >
                <Link href="/templates">Templates</Link>
              </div>
              <div 
                onClick={() => setIsOpen(false)}
                className="px-2 py-1.5 rounded-md text-sm font-medium hover:bg-accent hover:text-accent-foreground transition-colors"
              >
                <Link href="/domains">Domains</Link>
              </div>
              <div 
                onClick={() => setIsOpen(false)}
                className="px-2 py-1.5 rounded-md text-sm font-medium hover:bg-accent hover:text-accent-foreground transition-colors"
              >
                <Link href="/pricing">Pricing</Link>
              </div>
              {isAuthenticated && user?.isAdmin && (
                <div 
                  onClick={() => setIsOpen(false)}
                  className="px-2 py-1.5 rounded-md text-sm font-medium hover:bg-accent hover:text-accent-foreground transition-colors"
                >
                  <Link href="/admin">Admin</Link>
                </div>
              )}
            </div>

            <div className="pt-2 border-t">
              {isAuthenticated ? (
                <div className="space-y-2">
                  <div className="flex items-center gap-2 px-2 py-2">
                    <Avatar className="h-8 w-8">
                      <AvatarImage src={user?.profileImageUrl} />
                      <AvatarFallback>
                        {user?.firstName?.[0] || user?.email?.[0] || "U"}
                      </AvatarFallback>
                    </Avatar>
                    <div className="text-sm font-medium">
                      {user?.firstName || user?.email || "User"}
                    </div>
                  </div>
                  <div className="flex flex-col gap-1">
                    <div className="px-2 py-1.5 text-sm text-muted-foreground">
                      {user?.subscriptionTier === "premium" ? (
                        <span className="text-primary font-medium">Premium Account</span>
                      ) : user?.subscriptionTier === "enterprise" ? (
                        <span className="text-primary font-medium">Enterprise Account</span>
                      ) : (
                        <span>Free Account</span>
                      )}
                    </div>
                    <a 
                      href="/api/logout" 
                      className="flex items-center gap-1 px-2 py-1.5 rounded-md text-sm font-medium hover:bg-destructive/10 hover:text-destructive transition-colors"
                    >
                      <LogOut className="h-4 w-4" />
                      <span>Log Out</span>
                    </a>
                  </div>
                </div>
              ) : (
                <div className="space-y-2">
                  <Button variant="ghost" className="w-full justify-start" asChild>
                    <a href="/auth/google">Log In</a>
                  </Button>
                  <Button className="w-full" asChild>
                    <a href="/auth/google">Get Started</a>
                  </Button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </header>
  );
}

function UserMenuDropdown({ user }: { user: any }) {
  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" className="relative h-10 w-10 rounded-full">
          <Avatar className="h-10 w-10">
            <AvatarImage src={user?.profileImageUrl} />
            <AvatarFallback>
              {user?.firstName?.[0] || user?.email?.[0] || "U"}
            </AvatarFallback>
          </Avatar>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent className="w-56" align="end">
        <DropdownMenuLabel className="font-normal">
          <div className="flex flex-col space-y-1">
            <p className="text-sm font-medium leading-none">{user?.firstName || user?.email || "User"}</p>
            <p className="text-xs leading-none text-muted-foreground">{user?.email}</p>
          </div>
        </DropdownMenuLabel>
        <DropdownMenuSeparator />
        <DropdownMenuItem asChild>
          <Link href="/account">
            <User className="mr-2 h-4 w-4" />
            <span>Account</span>
          </Link>
        </DropdownMenuItem>
        {user?.subscriptionTier === "free" && (
          <DropdownMenuItem asChild>
            <Link href="/pricing">
              <span className="bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent font-medium">
                Upgrade to Premium
              </span>
            </Link>
          </DropdownMenuItem>
        )}
        <DropdownMenuSeparator />
        <DropdownMenuItem asChild className="text-destructive focus:text-destructive">
          <a href="/api/logout">
            <LogOut className="mr-2 h-4 w-4" />
            <span>Log out</span>
          </a>
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}