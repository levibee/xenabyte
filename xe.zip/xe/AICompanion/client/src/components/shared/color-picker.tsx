import { Check, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogClose,
} from "@/components/ui/dialog";

interface ColorPickerProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSelectColor: (color: string) => void;
}

const predefinedColors = [
  "#ef4444", // red-500
  "#f97316", // orange-500
  "#f59e0b", // amber-500
  "#84cc16", // lime-500
  "#22c55e", // green-500
  "#10b981", // emerald-500
  "#14b8a6", // teal-500
  "#06b6d4", // cyan-500
  "#0ea5e9", // sky-500
  "#3b82f6", // blue-500
  "#6366f1", // indigo-500
  "#8b5cf6", // violet-500
  "#a855f7", // purple-500
  "#d946ef", // fuchsia-500
  "#ec4899", // pink-500
  "#000000", // black
  "#4b5563", // gray-600
  "#9ca3af", // gray-400
  "#e5e7eb", // gray-200
  "#ffffff", // white
];

export default function ColorPicker({
  open,
  onOpenChange,
  onSelectColor,
}: ColorPickerProps) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Choose a color</DialogTitle>
          <DialogClose className="absolute right-4 top-4 rounded-sm opacity-70 ring-offset-background transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:pointer-events-none data-[state=open]:bg-accent data-[state=open]:text-muted-foreground">
            <X className="h-4 w-4" />
            <span className="sr-only">Close</span>
          </DialogClose>
        </DialogHeader>
        <div className="grid grid-cols-5 gap-2 py-4">
          {predefinedColors.map((color) => (
            <button
              key={color}
              onClick={() => onSelectColor(color)}
              className="w-10 h-10 rounded-md flex items-center justify-center border border-border"
              style={{ backgroundColor: color }}
              aria-label={`Select color ${color}`}
            >
              {color === "#ffffff" && <Check className="h-5 w-5 text-black" />}
            </button>
          ))}
        </div>
        <div className="flex justify-end">
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
