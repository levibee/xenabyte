import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import ColorPicker from "@/components/shared/color-picker";
import { WebsiteStyle } from "@/types";

interface StyleCustomizationProps {
  style: WebsiteStyle;
  onStyleChange: (style: Partial<WebsiteStyle>) => void;
}

export default function StyleCustomization({
  style,
  onStyleChange,
}: StyleCustomizationProps) {
  const [activeColorKey, setActiveColorKey] = useState<keyof WebsiteStyle["colors"] | null>(
    null
  );
  const [colorPickerOpen, setColorPickerOpen] = useState(false);

  const handleColorClick = (colorKey: keyof WebsiteStyle["colors"]) => {
    setActiveColorKey(colorKey);
    setColorPickerOpen(true);
  };

  const handleSelectColor = (color: string) => {
    if (activeColorKey) {
      onStyleChange({
        colors: {
          ...style.colors,
          [activeColorKey]: color,
        },
      });
      setColorPickerOpen(false);
    }
  };

  return (
    <Card>
      <CardContent className="p-6">
        <h2 className="text-xl font-semibold mb-4">Customize Style</h2>
        <p className="text-muted-foreground mb-6">
          Personalize your website's appearance with colors, fonts, and layout
          options.
        </p>

        <div className="space-y-6">
          <div>
            <h3 className="text-md font-medium mb-3">Color Scheme</h3>
            <div className="grid grid-cols-2 gap-4 mb-3">
              <div>
                <Label className="mb-1">Primary Color</Label>
                <div className="flex items-center">
                  <div
                    onClick={() => handleColorClick("primary")}
                    style={{ backgroundColor: style.colors.primary }}
                    className="w-10 h-10 rounded-md mr-2 cursor-pointer border border-border"
                  ></div>
                  <Input
                    type="text"
                    value={style.colors.primary}
                    onChange={(e) =>
                      onStyleChange({
                        colors: { ...style.colors, primary: e.target.value },
                      })
                    }
                  />
                </div>
              </div>
              <div>
                <Label className="mb-1">Secondary Color</Label>
                <div className="flex items-center">
                  <div
                    onClick={() => handleColorClick("secondary")}
                    style={{ backgroundColor: style.colors.secondary }}
                    className="w-10 h-10 rounded-md mr-2 cursor-pointer border border-border"
                  ></div>
                  <Input
                    type="text"
                    value={style.colors.secondary}
                    onChange={(e) =>
                      onStyleChange({
                        colors: { ...style.colors, secondary: e.target.value },
                      })
                    }
                  />
                </div>
              </div>
              <div>
                <Label className="mb-1">Accent Color</Label>
                <div className="flex items-center">
                  <div
                    onClick={() => handleColorClick("accent")}
                    style={{ backgroundColor: style.colors.accent }}
                    className="w-10 h-10 rounded-md mr-2 cursor-pointer border border-border"
                  ></div>
                  <Input
                    type="text"
                    value={style.colors.accent}
                    onChange={(e) =>
                      onStyleChange({
                        colors: { ...style.colors, accent: e.target.value },
                      })
                    }
                  />
                </div>
              </div>
              <div>
                <Label className="mb-1">Background Color</Label>
                <div className="flex items-center">
                  <div
                    onClick={() => handleColorClick("background")}
                    style={{ backgroundColor: style.colors.background }}
                    className="w-10 h-10 rounded-md mr-2 cursor-pointer border border-border"
                  ></div>
                  <Input
                    type="text"
                    value={style.colors.background}
                    onChange={(e) =>
                      onStyleChange({
                        colors: { ...style.colors, background: e.target.value },
                      })
                    }
                  />
                </div>
              </div>
            </div>
          </div>

          <div>
            <h3 className="text-md font-medium mb-3">Typography</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="heading-font">Heading Font</Label>
                <Select
                  value={style.fonts.heading}
                  onValueChange={(value) =>
                    onStyleChange({
                      fonts: { ...style.fonts, heading: value },
                    })
                  }
                >
                  <SelectTrigger id="heading-font">
                    <SelectValue placeholder="Select a font" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Inter">Inter</SelectItem>
                    <SelectItem value="Roboto">Roboto</SelectItem>
                    <SelectItem value="Montserrat">Montserrat</SelectItem>
                    <SelectItem value="Poppins">Poppins</SelectItem>
                    <SelectItem value="Open Sans">Open Sans</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="body-font">Body Font</Label>
                <Select
                  value={style.fonts.body}
                  onValueChange={(value) =>
                    onStyleChange({
                      fonts: { ...style.fonts, body: value },
                    })
                  }
                >
                  <SelectTrigger id="body-font">
                    <SelectValue placeholder="Select a font" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Inter">Inter</SelectItem>
                    <SelectItem value="Roboto">Roboto</SelectItem>
                    <SelectItem value="Montserrat">Montserrat</SelectItem>
                    <SelectItem value="Poppins">Poppins</SelectItem>
                    <SelectItem value="Open Sans">Open Sans</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>

          <div>
            <h3 className="text-md font-medium mb-3">Layout</h3>
            <RadioGroup
              value={style.layout}
              onValueChange={(value) => onStyleChange({ layout: value })}
              className="flex flex-wrap gap-4"
            >
              <div className="flex flex-col items-center">
                <div className="w-24 h-24 bg-muted rounded-md flex flex-col justify-between p-2 ring-offset-background focus-within:ring-2 focus-within:ring-ring focus-within:ring-offset-2">
                  <div className="bg-muted-foreground/30 h-2 rounded"></div>
                  <div className="flex-1 my-2 flex flex-col gap-1">
                    <div className="bg-muted-foreground/30 h-1 rounded"></div>
                    <div className="bg-muted-foreground/30 h-1 rounded"></div>
                  </div>
                  <div className="bg-muted-foreground/30 h-1 rounded"></div>
                  <RadioGroupItem
                    value="standard"
                    className="sr-only"
                    id="layout-standard"
                  />
                </div>
                <Label
                  htmlFor="layout-standard"
                  className="mt-1 text-xs cursor-pointer"
                >
                  Standard
                </Label>
              </div>

              <div className="flex flex-col items-center">
                <div className="w-24 h-24 bg-muted rounded-md flex flex-row justify-between p-2 ring-offset-background focus-within:ring-2 focus-within:ring-ring focus-within:ring-offset-2">
                  <div className="bg-muted-foreground/30 w-1/4 rounded"></div>
                  <div className="flex-1 ml-2 flex flex-col gap-1 justify-between">
                    <div className="bg-muted-foreground/30 h-2 rounded"></div>
                    <div className="flex-1 my-1 flex flex-col gap-1">
                      <div className="bg-muted-foreground/30 h-1 rounded"></div>
                      <div className="bg-muted-foreground/30 h-1 rounded"></div>
                    </div>
                    <div className="bg-muted-foreground/30 h-1 rounded"></div>
                  </div>
                  <RadioGroupItem
                    value="sidebar"
                    className="sr-only"
                    id="layout-sidebar"
                  />
                </div>
                <Label
                  htmlFor="layout-sidebar"
                  className="mt-1 text-xs cursor-pointer"
                >
                  Sidebar
                </Label>
              </div>

              <div className="flex flex-col items-center">
                <div className="w-24 h-24 bg-muted rounded-md flex flex-col justify-start p-2 ring-offset-background focus-within:ring-2 focus-within:ring-ring focus-within:ring-offset-2">
                  <div className="bg-muted-foreground/30 h-2 w-1/3 rounded mb-6"></div>
                  <div className="flex-1 flex flex-col gap-2">
                    <div className="bg-muted-foreground/30 h-1 rounded"></div>
                    <div className="bg-muted-foreground/30 h-1 w-2/3 rounded"></div>
                  </div>
                  <RadioGroupItem
                    value="minimal"
                    className="sr-only"
                    id="layout-minimal"
                  />
                </div>
                <Label
                  htmlFor="layout-minimal"
                  className="mt-1 text-xs cursor-pointer"
                >
                  Minimal
                </Label>
              </div>
            </RadioGroup>
          </div>
        </div>

        <ColorPicker
          open={colorPickerOpen}
          onOpenChange={setColorPickerOpen}
          onSelectColor={handleSelectColor}
        />
      </CardContent>
    </Card>
  );
}
