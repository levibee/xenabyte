import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Template } from "@/types";
import { cn } from "@/lib/utils";

interface TemplateSelectionProps {
  templates: Template[];
  selectedTemplate: number | null;
  onSelectTemplate: (templateId: number) => void;
}

export default function TemplateSelection({
  templates,
  selectedTemplate,
  onSelectTemplate,
}: TemplateSelectionProps) {
  return (
    <Card>
      <CardContent className="p-6">
        <h2 className="text-xl font-semibold mb-4">Choose a Template</h2>
        <p className="text-muted-foreground mb-6">
          Select a starting point for your website. You can customize it in the
          next steps.
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {templates.map((template) => (
            <div
              key={template.id}
              onClick={() => onSelectTemplate(template.id)}
              className={cn(
                "cursor-pointer border rounded-lg p-4 transition-all duration-150 ease-in-out",
                selectedTemplate === template.id
                  ? "ring-2 ring-primary bg-primary/5"
                  : "hover:bg-muted"
              )}
            >
              <div className="flex justify-between items-start mb-2">
                <h3 className="font-medium">{template.name}</h3>
                {template.popularity === "high" && (
                  <Badge variant="outline" className="bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200">
                    Popular
                  </Badge>
                )}
              </div>
              <p className="text-sm text-muted-foreground">
                {template.description}
              </p>
              <div className="mt-4 h-32 bg-muted rounded-md flex items-center justify-center overflow-hidden">
                <img
                  src={template.thumbnail}
                  className="w-full h-full object-cover rounded-md"
                  alt={`${template.name} template preview`}
                />
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
