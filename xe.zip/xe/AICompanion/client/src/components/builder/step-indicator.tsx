import { cn } from "@/lib/utils";

interface StepIndicatorProps {
  currentStep: number;
  steps: Array<{ id: number; title: string }>;
  onStepClick?: (stepId: number) => void;
}

export default function StepIndicator({
  currentStep,
  steps,
  onStepClick,
}: StepIndicatorProps) {
  return (
    <div className="w-full bg-muted py-4 px-4 sm:px-6 lg:px-8 border-b border-border">
      <div className="max-w-7xl mx-auto">
        <div className="relative">
          <div className="overflow-hidden h-2 mb-4 text-xs flex rounded bg-muted">
            <div
              className="transition-all duration-500 ease-out shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center bg-primary"
              style={{ width: `${(currentStep / steps.length) * 100}%` }}
            ></div>
          </div>
          <div className="flex text-sm justify-between -mt-2">
            {steps.map((step) => (
              <div key={step.id} className="w-1/5 text-center">
                <span
                  onClick={() => onStepClick && onStepClick(step.id)}
                  className={cn(
                    "flex items-center justify-center w-8 h-8 mx-auto rounded-full text-lg transition-colors duration-300 cursor-pointer",
                    currentStep >= step.id
                      ? "bg-primary text-primary-foreground"
                      : "bg-muted text-muted-foreground"
                  )}
                >
                  {step.id}
                </span>
                <span
                  className={cn(
                    "text-xs mt-1 block",
                    currentStep >= step.id
                      ? "text-foreground font-medium"
                      : "text-muted-foreground"
                  )}
                >
                  {step.title}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
