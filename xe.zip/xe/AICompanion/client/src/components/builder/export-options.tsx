import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  AlertCircle,
  Download,
  Code,
  Github,
  Server,
  Upload,
  Check,
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import ExportDialog from "@/components/preview/export-dialog";
import { WebsiteData } from "@/types";
import { apiRequest } from "@/lib/queryClient";

interface ExportOptionsProps {
  websiteData: WebsiteData;
}

export default function ExportOptions({ websiteData }: ExportOptionsProps) {
  const [exportDialogOpen, setExportDialogOpen] = useState(false);
  const [exporting, setExporting] = useState(false);
  const { toast } = useToast();

  const handleExport = async () => {
    try {
      setExporting(true);
      await apiRequest("POST", "/api/websites/export", websiteData);
      
      toast({
        title: "Export successful",
        description: "Your website files are ready to download",
        variant: "default",
      });
      
      // Simulate download after success
      setTimeout(() => {
        // In a real app, this would trigger a file download
        console.log("Downloading files...");
        toast({
          title: "Download started",
          description: "Your files are being downloaded",
        });
      }, 500);
    } catch (error) {
      toast({
        title: "Export failed",
        description: "There was an error exporting your website",
        variant: "destructive",
      });
    } finally {
      setExporting(false);
    }
  };

  return (
    <Card>
      <CardContent className="p-6">
        <h2 className="text-xl font-semibold mb-4">Export Your Website</h2>
        <p className="text-muted-foreground mb-6">
          Download your website files or get the code to deploy it.
        </p>

        <div className="space-y-6">
          <div className="bg-green-50 dark:bg-green-900/30 border border-green-200 dark:border-green-800 rounded-md p-4">
            <div className="flex">
              <div className="flex-shrink-0">
                <Check className="h-5 w-5 text-green-600 dark:text-green-400" />
              </div>
              <div className="ml-3">
                <h3 className="text-sm font-medium text-green-800 dark:text-green-300">
                  Website generated successfully!
                </h3>
                <div className="mt-2 text-sm text-green-700 dark:text-green-300">
                  <p>
                    Your website is ready to be exported. Choose one of the
                    options below to get your files.
                  </p>
                </div>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="border border-border rounded-lg p-4 hover:bg-muted transition-colors duration-150 ease-in-out cursor-pointer">
              <div className="flex items-center">
                <div className="flex-shrink-0 bg-primary/10 rounded-md p-2">
                  <Download className="text-primary h-5 w-5" />
                </div>
                <div className="ml-4">
                  <h3 className="text-lg font-medium">Download ZIP</h3>
                  <p className="text-sm text-muted-foreground">
                    Get all website files in a ZIP archive
                  </p>
                </div>
              </div>
              <div className="mt-4">
                <Button
                  className="w-full"
                  onClick={handleExport}
                  disabled={exporting}
                >
                  {exporting ? "Generating..." : "Download Files"}
                  <Download className="ml-2 h-4 w-4" />
                </Button>
              </div>
            </div>

            <div className="border border-border rounded-lg p-4 hover:bg-muted transition-colors duration-150 ease-in-out cursor-pointer">
              <div className="flex items-center">
                <div className="flex-shrink-0 bg-secondary/10 rounded-md p-2">
                  <Code className="text-secondary h-5 w-5" />
                </div>
                <div className="ml-4">
                  <h3 className="text-lg font-medium">View Source Code</h3>
                  <p className="text-sm text-muted-foreground">
                    Get HTML, CSS, and JavaScript code
                  </p>
                </div>
              </div>
              <div className="mt-4">
                <Button
                  variant="secondary"
                  className="w-full"
                  onClick={() => setExportDialogOpen(true)}
                >
                  Show Code
                  <Code className="ml-2 h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>

          <div className="bg-muted rounded-lg p-4 mt-4">
            <h3 className="text-md font-medium mb-3">Deployment Options</h3>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <Button variant="outline" className="flex gap-2">
                <Github className="h-4 w-4" />
                GitHub Pages
              </Button>
              <Button variant="outline" className="flex gap-2">
                <Server className="h-4 w-4" />
                Netlify
              </Button>
              <Button variant="outline" className="flex gap-2">
                <Upload className="h-4 w-4" />
                Vercel
              </Button>
            </div>
          </div>

          <div className="mt-4">
            <h3 className="text-md font-medium mb-2">Next Steps</h3>
            <ul className="list-disc list-inside space-y-1 text-sm text-muted-foreground">
              <li>Upload your website files to a web hosting provider</li>
              <li>Connect a custom domain name to your website</li>
              <li>Test your website on different devices and browsers</li>
              <li>Set up analytics to track visitor behavior</li>
            </ul>
          </div>
        </div>

        <ExportDialog
          open={exportDialogOpen}
          onOpenChange={setExportDialogOpen}
          websiteData={websiteData}
        />
      </CardContent>
    </Card>
  );
}
