import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Plus, Trash2, ArrowUp, ArrowDown, GripVertical } from "lucide-react";
import { WebsiteContent, Section } from "@/types";

interface ContentEditorProps {
  content: WebsiteContent;
  onContentChange: (content: Partial<WebsiteContent>) => void;
}

export default function ContentEditor({
  content,
  onContentChange,
}: ContentEditorProps) {
  const handleSectionUpdate = (
    index: number,
    sectionUpdates: Partial<Section>
  ) => {
    const updatedSections = [...content.sections];
    updatedSections[index] = { ...updatedSections[index], ...sectionUpdates };
    onContentChange({ sections: updatedSections });
  };

  const handleAddSection = () => {
    const newSection: Section = {
      id: Date.now(),
      type: "content",
      title: "New Section",
      content: "",
    };
    onContentChange({ sections: [...content.sections, newSection] });
  };

  const handleRemoveSection = (index: number) => {
    const updatedSections = [...content.sections];
    updatedSections.splice(index, 1);
    onContentChange({ sections: updatedSections });
  };

  const handleMoveSection = (index: number, direction: "up" | "down") => {
    if (
      (direction === "up" && index === 0) ||
      (direction === "down" && index === content.sections.length - 1)
    ) {
      return;
    }

    const newIndex = direction === "up" ? index - 1 : index + 1;
    const updatedSections = [...content.sections];
    const sectionToMove = updatedSections[index];
    
    updatedSections.splice(index, 1);
    updatedSections.splice(newIndex, 0, sectionToMove);
    
    onContentChange({ sections: updatedSections });
  };

  return (
    <Card>
      <CardContent className="p-6">
        <h2 className="text-xl font-semibold mb-4">Add Content</h2>
        <p className="text-muted-foreground mb-6">
          Populate your website with text, images, and sections.
        </p>

        <div className="space-y-6">
          <div>
            <Label htmlFor="site-name">Website Name</Label>
            <Input
              id="site-name"
              placeholder="My Awesome Site"
              value={content.siteName}
              onChange={(e) => onContentChange({ siteName: e.target.value })}
              className="mt-1"
            />
          </div>

          <div>
            <Label htmlFor="site-tagline">Tagline</Label>
            <Input
              id="site-tagline"
              placeholder="A short description of your website"
              value={content.tagline}
              onChange={(e) => onContentChange({ tagline: e.target.value })}
              className="mt-1"
            />
          </div>

          <div>
            <Label htmlFor="site-logo">Logo</Label>
            <div className="mt-1 flex items-center">
              <span className="inline-block h-12 w-12 rounded-md overflow-hidden bg-muted flex items-center justify-center">
                {content.logo ? (
                  <img
                    src={content.logo}
                    alt="Logo preview"
                    className="h-full w-full object-cover"
                  />
                ) : (
                  <div className="text-muted-foreground text-3xl">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      className="h-6 w-6"
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"
                      />
                    </svg>
                  </div>
                )}
              </span>
              <Button variant="outline" className="ml-5">
                Upload
              </Button>
            </div>
          </div>

          <div>
            <div className="flex justify-between items-center mb-1">
              <Label>Page Sections</Label>
              <Button
                size="sm"
                variant="outline"
                className="h-8 w-8 p-0 rounded-full"
                onClick={handleAddSection}
              >
                <Plus className="h-4 w-4" />
                <span className="sr-only">Add section</span>
              </Button>
            </div>

            {content.sections.map((section, index) => (
              <div
                key={section.id}
                className="border border-border rounded-md overflow-hidden mt-3"
              >
                <div className="bg-muted p-3 border-b border-border">
                  <div className="flex justify-between items-center">
                    <div className="flex items-center">
                      <GripVertical className="text-muted-foreground mr-2 cursor-move h-5 w-5" />
                      <span className="font-medium">{section.title}</span>
                    </div>
                    <div className="flex space-x-2">
                      <Button
                        variant="ghost"
                        size="sm"
                        className="h-8 w-8 p-0"
                        onClick={() => handleMoveSection(index, "up")}
                        disabled={index === 0}
                      >
                        <ArrowUp className="h-4 w-4" />
                        <span className="sr-only">Move up</span>
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="h-8 w-8 p-0"
                        onClick={() => handleMoveSection(index, "down")}
                        disabled={index === content.sections.length - 1}
                      >
                        <ArrowDown className="h-4 w-4" />
                        <span className="sr-only">Move down</span>
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="h-8 w-8 p-0 text-destructive hover:text-destructive"
                        onClick={() => handleRemoveSection(index)}
                      >
                        <Trash2 className="h-4 w-4" />
                        <span className="sr-only">Delete</span>
                      </Button>
                    </div>
                  </div>
                </div>
                <div className="p-3">
                  <div className="grid grid-cols-1 gap-3">
                    <div>
                      <Label className="text-xs">Section Title</Label>
                      <Input
                        value={section.title}
                        onChange={(e) =>
                          handleSectionUpdate(index, { title: e.target.value })
                        }
                        className="mt-1"
                      />
                    </div>
                    {section.type === "hero" && (
                      <>
                        <div>
                          <Label className="text-xs">Heading</Label>
                          <Input
                            placeholder="Welcome to My Website"
                            value={section.heading || ""}
                            onChange={(e) =>
                              handleSectionUpdate(index, {
                                heading: e.target.value,
                              })
                            }
                            className="mt-1"
                          />
                        </div>
                        <div>
                          <Label className="text-xs">Subheading</Label>
                          <Input
                            placeholder="Discover what we offer"
                            value={section.subheading || ""}
                            onChange={(e) =>
                              handleSectionUpdate(index, {
                                subheading: e.target.value,
                              })
                            }
                            className="mt-1"
                          />
                        </div>
                        <div>
                          <Label className="text-xs">Background Image</Label>
                          <div className="mt-1 flex items-center">
                            <Button variant="outline" size="sm">
                              Upload Image
                            </Button>
                          </div>
                        </div>
                      </>
                    )}
                    {section.type === "features" && (
                      <>
                        <div>
                          <div className="flex justify-between items-center mb-1">
                            <Label className="text-xs">Features</Label>
                            <Button
                              size="sm"
                              variant="outline"
                              className="h-6 w-6 p-0 rounded-full text-xs"
                            >
                              <Plus className="h-3 w-3" />
                              <span className="sr-only">Add feature</span>
                            </Button>
                          </div>
                          <div className="border border-border rounded-md p-2 space-y-2">
                            {(section.features || ["", "", ""]).map(
                              (feature, featureIndex) => (
                                <div
                                  key={featureIndex}
                                  className="flex items-center"
                                >
                                  <div className="flex items-center justify-center h-5 w-5 text-primary mr-2">
                                    <svg
                                      xmlns="http://www.w3.org/2000/svg"
                                      viewBox="0 0 24 24"
                                      fill="none"
                                      stroke="currentColor"
                                      strokeWidth="2"
                                      strokeLinecap="round"
                                      strokeLinejoin="round"
                                      className="h-4 w-4"
                                    >
                                      <polyline points="20 6 9 17 4 12"></polyline>
                                    </svg>
                                  </div>
                                  <Input
                                    placeholder={`Feature ${featureIndex + 1}`}
                                    value={feature}
                                    onChange={(e) => {
                                      const updatedFeatures = [
                                        ...(section.features || []),
                                      ];
                                      updatedFeatures[featureIndex] =
                                        e.target.value;
                                      handleSectionUpdate(index, {
                                        features: updatedFeatures,
                                      });
                                    }}
                                  />
                                </div>
                              )
                            )}
                          </div>
                        </div>
                      </>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
