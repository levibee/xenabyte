import { Card, CardContent } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { WebsiteSettings } from "@/types";

interface FineTuningProps {
  settings: WebsiteSettings;
  onSettingsChange: (settings: Partial<WebsiteSettings>) => void;
}

export default function FineTuning({
  settings,
  onSettingsChange,
}: FineTuningProps) {
  const handleComponentToggle = (id: keyof typeof settings.components, checked: boolean) => {
    onSettingsChange({
      components: {
        ...settings.components,
        [id]: checked,
      },
    });
  };

  const handleEffectToggle = (id: keyof typeof settings.effects, checked: boolean) => {
    onSettingsChange({
      effects: {
        ...settings.effects,
        [id]: checked,
      },
    });
  };

  const handleSeoChange = (field: keyof typeof settings.seo, value: string) => {
    onSettingsChange({
      seo: {
        ...settings.seo,
        [field]: value,
      },
    });
  };

  const handlePerformanceToggle = (id: keyof typeof settings.performance, checked: boolean) => {
    onSettingsChange({
      performance: {
        ...settings.performance,
        [id]: checked,
      },
    });
  };

  return (
    <Card>
      <CardContent className="p-6">
        <h2 className="text-xl font-semibold mb-4">Fine-tune Your Website</h2>
        <p className="text-muted-foreground mb-6">
          Add finishing touches and adjust details for the perfect look.
        </p>

        <div className="space-y-6">
          <div>
            <h3 className="text-md font-medium mb-3">Components</h3>
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="enable-navigation"
                  checked={settings.components.navigation}
                  onCheckedChange={(checked) =>
                    handleComponentToggle("navigation", !!checked)
                  }
                />
                <Label htmlFor="enable-navigation">Navigation Menu</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="enable-footer"
                  checked={settings.components.footer}
                  onCheckedChange={(checked) =>
                    handleComponentToggle("footer", !!checked)
                  }
                />
                <Label htmlFor="enable-footer">Footer</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="enable-contact"
                  checked={settings.components.contactForm}
                  onCheckedChange={(checked) =>
                    handleComponentToggle("contactForm", !!checked)
                  }
                />
                <Label htmlFor="enable-contact">Contact Form</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="enable-gallery"
                  checked={settings.components.gallery}
                  onCheckedChange={(checked) =>
                    handleComponentToggle("gallery", !!checked)
                  }
                />
                <Label htmlFor="enable-gallery">Image Gallery</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="enable-social"
                  checked={settings.components.socialLinks}
                  onCheckedChange={(checked) =>
                    handleComponentToggle("socialLinks", !!checked)
                  }
                />
                <Label htmlFor="enable-social">Social Media Links</Label>
              </div>
            </div>
          </div>

          <div>
            <h3 className="text-md font-medium mb-3">Effects & Animation</h3>
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="enable-parallax"
                  checked={settings.effects.parallax}
                  onCheckedChange={(checked) =>
                    handleEffectToggle("parallax", !!checked)
                  }
                />
                <Label htmlFor="enable-parallax">Parallax Scrolling</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="enable-fade"
                  checked={settings.effects.fadeIn}
                  onCheckedChange={(checked) =>
                    handleEffectToggle("fadeIn", !!checked)
                  }
                />
                <Label htmlFor="enable-fade">Fade-in Elements</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="enable-smooth"
                  checked={settings.effects.smoothScroll}
                  onCheckedChange={(checked) =>
                    handleEffectToggle("smoothScroll", !!checked)
                  }
                />
                <Label htmlFor="enable-smooth">Smooth Scrolling</Label>
              </div>
            </div>
          </div>

          <div>
            <h3 className="text-md font-medium mb-3">SEO Settings</h3>
            <div className="space-y-3">
              <div>
                <Label htmlFor="meta-title" className="mb-1">
                  Meta Title
                </Label>
                <Input
                  id="meta-title"
                  placeholder="My Website | Official Site"
                  value={settings.seo.metaTitle}
                  onChange={(e) => handleSeoChange("metaTitle", e.target.value)}
                />
              </div>
              <div>
                <Label htmlFor="meta-description" className="mb-1">
                  Meta Description
                </Label>
                <Textarea
                  id="meta-description"
                  placeholder="A brief description of your website for search engines."
                  rows={2}
                  value={settings.seo.metaDescription}
                  onChange={(e) =>
                    handleSeoChange("metaDescription", e.target.value)
                  }
                />
              </div>
            </div>
          </div>

          <div>
            <h3 className="text-md font-medium mb-3">
              Performance Optimization
            </h3>
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="enable-lazy"
                  checked={settings.performance.lazyLoading}
                  onCheckedChange={(checked) =>
                    handlePerformanceToggle("lazyLoading", !!checked)
                  }
                />
                <Label htmlFor="enable-lazy">Lazy Load Images</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="enable-minify"
                  checked={settings.performance.minifyCode}
                  onCheckedChange={(checked) =>
                    handlePerformanceToggle("minifyCode", !!checked)
                  }
                />
                <Label htmlFor="enable-minify">Minify CSS & JavaScript</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="enable-cache"
                  checked={settings.performance.caching}
                  onCheckedChange={(checked) =>
                    handlePerformanceToggle("caching", !!checked)
                  }
                />
                <Label htmlFor="enable-cache">Browser Caching</Label>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
