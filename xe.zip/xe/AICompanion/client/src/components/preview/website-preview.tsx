import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { WebsiteData } from "@/types";
import PreviewControls from "./preview-controls";

interface WebsitePreviewProps {
  websiteData: WebsiteData;
}

export default function WebsitePreview({ websiteData }: WebsitePreviewProps) {
  const [previewMode, setPreviewMode] = useState<"desktop" | "tablet" | "mobile">("desktop");

  return (
    <div className="flex flex-col h-full">
      <Card className="mb-4">
        <CardContent className="p-4">
          <div className="flex justify-between items-center">
            <h2 className="text-lg font-medium">Live Preview</h2>
            <PreviewControls
              activeMode={previewMode}
              onModeChange={setPreviewMode}
            />
          </div>
        </CardContent>
      </Card>

      <Card className="flex-1 flex items-center justify-center">
        <CardContent className="p-4 h-full w-full flex flex-col items-center justify-center">
          {/* Mobile preview frame */}
          {previewMode === "mobile" && (
            <div
              className="border-4 border-gray-900 dark:border-gray-700 rounded-3xl overflow-hidden w-64 h-[500px] bg-white dark:bg-gray-900 transition-all duration-300 shadow-xl"
            >
              <div className="w-full h-6 bg-gray-900 dark:bg-gray-700 relative">
                <div className="absolute w-16 h-4 bg-gray-800 dark:bg-gray-600 rounded-b-xl left-1/2 transform -translate-x-1/2"></div>
              </div>
              <div className="w-full h-full bg-gray-100 dark:bg-gray-900 overflow-hidden">
                <MobilePreviewContent websiteData={websiteData} />
              </div>
            </div>
          )}

          {/* Tablet preview frame */}
          {previewMode === "tablet" && (
            <div
              className="border-4 border-gray-900 dark:border-gray-700 rounded-3xl overflow-hidden w-[350px] h-[500px] bg-white dark:bg-gray-900 transition-all duration-300 shadow-xl"
            >
              <div className="w-full h-6 bg-gray-900 dark:bg-gray-700 relative">
                <div className="absolute w-2 h-2 bg-gray-600 dark:bg-gray-500 rounded-full left-1/2 transform -translate-x-1/2"></div>
              </div>
              <div className="w-full h-full bg-gray-100 dark:bg-gray-900 overflow-hidden">
                <TabletPreviewContent websiteData={websiteData} />
              </div>
            </div>
          )}

          {/* Desktop preview frame */}
          {previewMode === "desktop" && (
            <div
              className="border border-gray-400 dark:border-gray-600 rounded-t-lg overflow-hidden w-full h-[500px] bg-white dark:bg-gray-900 transition-all duration-300 shadow-md"
            >
              <div className="h-8 bg-gray-200 dark:bg-gray-700 flex items-center px-2 border-b border-gray-300 dark:border-gray-600">
                <div className="flex space-x-1.5">
                  <div className="w-3 h-3 rounded-full bg-red-500"></div>
                  <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
                  <div className="w-3 h-3 rounded-full bg-green-500"></div>
                </div>
                <div className="mx-auto flex items-center space-x-2">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="h-3 w-3 text-gray-500 dark:text-gray-400"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"
                    />
                  </svg>
                  <span className="text-xs text-gray-600 dark:text-gray-300">
                    mywebsite.com
                  </span>
                </div>
              </div>

              <div className="w-full h-full bg-gray-100 dark:bg-gray-900 overflow-auto">
                <DesktopPreviewContent websiteData={websiteData} />
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

function MobilePreviewContent({ websiteData }: { websiteData: WebsiteData }) {
  const { style, content } = websiteData;
  
  return (
    <>
      <div className="h-12 bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 flex items-center px-4">
        <div className="flex items-center">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            className="text-primary h-5 w-5 mr-2"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <path d="m16 16 3-8 3 8c-.87.65-1.92 1-3 1s-2.13-.35-3-1Z" />
            <path d="m2 16 3-8 3 8c-.87.65-1.92 1-3 1s-2.13-.35-3-1Z" />
            <path d="M7 21h10" />
            <path d="M12 3v18" />
            <path d="M3 7h2c2 0 5-1 7-2 2 1 5 2 7 2h2" />
          </svg>
          <span className="font-bold text-sm">{content.siteName}</span>
        </div>
      </div>

      <div className="p-4">
        <h1 className="text-xl font-bold">{content.siteName}</h1>
        <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
          {content.tagline}
        </p>

        <div className="mt-4 h-32 bg-gray-200 dark:bg-gray-700 rounded-md flex items-center justify-center">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            className="h-8 w-8 text-gray-400 dark:text-gray-500"
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"
            />
          </svg>
        </div>

        {content.sections
          .filter((section) => section.type === "features")
          .slice(0, 1)
          .map((section) => (
            <div key={section.id} className="mt-4">
              <h2 className="text-lg font-semibold">{section.title}</h2>
              <ul className="mt-2 space-y-2">
                {(section.features || []).map((feature, index) => (
                  <li key={index} className="flex items-center">
                    <div
                      className="flex-shrink-0 h-5 w-5 flex items-center justify-center rounded-full mr-2"
                      style={{ backgroundColor: style.colors.primary + "20" }}
                    >
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        className="h-3 w-3"
                        style={{ color: style.colors.primary }}
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M5 13l4 4L19 7"
                        />
                      </svg>
                    </div>
                    <span className="text-sm">{feature}</span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
      </div>
    </>
  );
}

function TabletPreviewContent({ websiteData }: { websiteData: WebsiteData }) {
  const { style, content } = websiteData;
  
  return (
    <>
      <div className="h-12 bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 flex items-center px-4">
        <div className="flex items-center">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            className="text-primary h-5 w-5 mr-2"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <path d="m16 16 3-8 3 8c-.87.65-1.92 1-3 1s-2.13-.35-3-1Z" />
            <path d="m2 16 3-8 3 8c-.87.65-1.92 1-3 1s-2.13-.35-3-1Z" />
            <path d="M7 21h10" />
            <path d="M12 3v18" />
            <path d="M3 7h2c2 0 5-1 7-2 2 1 5 2 7 2h2" />
          </svg>
          <span className="font-bold text-sm">{content.siteName}</span>
        </div>
        <div className="ml-4 flex">
          <a href="#" className="text-sm font-medium text-foreground">
            Home
          </a>
          <a href="#" className="ml-4 text-sm font-medium text-muted-foreground">
            Features
          </a>
          <a href="#" className="ml-4 text-sm font-medium text-muted-foreground">
            Contact
          </a>
        </div>
      </div>

      <div className="p-4">
        <div className="flex">
          <div className="w-1/2 pr-2">
            <h1 className="text-2xl font-bold">{content.siteName}</h1>
            <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
              {content.tagline}
            </p>
            <button
              className="mt-3 px-4 py-2 text-sm font-medium rounded-md text-white"
              style={{ backgroundColor: style.colors.primary }}
            >
              Learn More
            </button>
          </div>
          <div className="w-1/2 pl-2">
            <div className="h-32 bg-gray-200 dark:bg-gray-700 rounded-md flex items-center justify-center">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-8 w-8 text-gray-400 dark:text-gray-500"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"
                />
              </svg>
            </div>
          </div>
        </div>

        {content.sections
          .filter((section) => section.type === "features")
          .slice(0, 1)
          .map((section) => (
            <div key={section.id} className="mt-6">
              <h2 className="text-lg font-semibold">{section.title}</h2>
              <div className="grid grid-cols-2 gap-3 mt-2">
                {(section.features || []).map((feature, index) => (
                  <div key={index} className="flex items-start">
                    <div
                      className="flex-shrink-0 h-5 w-5 flex items-center justify-center rounded-full mr-2 mt-1"
                      style={{ backgroundColor: style.colors.primary + "20" }}
                    >
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        className="h-3 w-3"
                        style={{ color: style.colors.primary }}
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M5 13l4 4L19 7"
                        />
                      </svg>
                    </div>
                    <div>
                      <h3 className="font-medium text-sm">{feature}</h3>
                      <p className="text-xs text-gray-500 dark:text-gray-400">
                        Description of feature
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
      </div>
    </>
  );
}

function DesktopPreviewContent({ websiteData }: { websiteData: WebsiteData }) {
  const { style, content, settings } = websiteData;
  
  return (
    <>
      {settings.components.navigation && (
        <header className="bg-white dark:bg-gray-800 shadow-sm">
          <div className="max-w-6xl mx-auto px-4 py-4 flex justify-between items-center">
            <div className="flex items-center">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="text-primary h-6 w-6 mr-2"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <path d="m16 16 3-8 3 8c-.87.65-1.92 1-3 1s-2.13-.35-3-1Z" />
                <path d="m2 16 3-8 3 8c-.87.65-1.92 1-3 1s-2.13-.35-3-1Z" />
                <path d="M7 21h10" />
                <path d="M12 3v18" />
                <path d="M3 7h2c2 0 5-1 7-2 2 1 5 2 7 2h2" />
              </svg>
              <span className="font-bold text-xl">{content.siteName}</span>
            </div>
            <nav className="hidden md:flex space-x-8">
              <a href="#" className="text-foreground font-medium">
                Home
              </a>
              <a
                href="#"
                className="text-muted-foreground hover:text-foreground"
              >
                Features
              </a>
              <a
                href="#"
                className="text-muted-foreground hover:text-foreground"
              >
                About
              </a>
              <a
                href="#"
                className="text-muted-foreground hover:text-foreground"
              >
                Contact
              </a>
            </nav>
            <button
              className="px-4 py-2 text-sm text-white rounded-md font-medium"
              style={{ backgroundColor: style.colors.primary }}
            >
              Get Started
            </button>
          </div>
        </header>
      )}

      <main>
        {content.sections
          .filter((section) => section.type === "hero")
          .slice(0, 1)
          .map((section) => (
            <section
              key={section.id}
              className="py-12 bg-gray-50 dark:bg-gray-800"
            >
              <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="lg:grid lg:grid-cols-12 lg:gap-8">
                  <div className="sm:text-center md:max-w-2xl md:mx-auto lg:col-span-6 lg:text-left">
                    <h1 className="text-4xl tracking-tight font-extrabold text-gray-900 dark:text-white sm:text-5xl">
                      <span className="block">{section.heading || "A better way to"}</span>
                      <span
                        className="block"
                        style={{ color: style.colors.primary }}
                      >
                        {section.subheading || "build websites"}
                      </span>
                    </h1>
                    <p className="mt-3 text-base text-gray-500 dark:text-gray-300 sm:mt-5 sm:text-lg">
                      {content.tagline}
                    </p>
                    <div className="mt-8 sm:flex sm:justify-center lg:justify-start">
                      <div className="rounded-md shadow">
                        <a
                          href="#"
                          className="w-full flex items-center justify-center px-8 py-3 border border-transparent text-base font-medium rounded-md text-white md:py-4 md:text-lg"
                          style={{ backgroundColor: style.colors.primary }}
                        >
                          Get started
                        </a>
                      </div>
                      <div className="mt-3 sm:mt-0 sm:ml-3">
                        <a
                          href="#"
                          className="w-full flex items-center justify-center px-8 py-3 border border-transparent text-base font-medium rounded-md md:py-4 md:text-lg"
                          style={{
                            backgroundColor: style.colors.primary + "20",
                            color: style.colors.primary,
                          }}
                        >
                          Learn more
                        </a>
                      </div>
                    </div>
                  </div>
                  <div className="mt-12 relative sm:max-w-lg sm:mx-auto lg:mt-0 lg:max-w-none lg:mx-0 lg:col-span-6 lg:flex lg:items-center">
                    <div className="relative mx-auto w-full rounded-lg shadow-lg lg:max-w-md">
                      <img
                        className="w-full rounded-lg"
                        src="https://images.unsplash.com/photo-1499951360447-b19be8fe80f5?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=500"
                        alt="Website creation process"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </section>
          ))}

        {content.sections
          .filter((section) => section.type === "features")
          .slice(0, 1)
          .map((section) => (
            <section key={section.id} className="py-12">
              <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="lg:text-center">
                  <h2
                    className="text-base font-semibold tracking-wide uppercase"
                    style={{ color: style.colors.primary }}
                  >
                    Features
                  </h2>
                  <p className="mt-2 text-3xl leading-8 font-extrabold tracking-tight text-gray-900 dark:text-white sm:text-4xl">
                    {section.title}
                  </p>
                  <p className="mt-4 max-w-2xl text-xl text-gray-500 dark:text-gray-300 lg:mx-auto">
                    Everything you need to build amazing websites quickly and efficiently.
                  </p>
                </div>

                <div className="mt-10">
                  <div className="grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-3">
                    {(section.features || []).slice(0, 3).map((feature, i) => (
                      <div key={i} className="pt-6">
                        <div className="flow-root bg-white dark:bg-gray-800 rounded-lg px-6 pb-8 shadow-md">
                          <div className="-mt-6">
                            <div>
                              <span
                                className="inline-flex items-center justify-center p-3 rounded-md shadow-lg"
                                style={{ backgroundColor: style.colors.primary }}
                              >
                                <svg
                                  xmlns="http://www.w3.org/2000/svg"
                                  className="h-6 w-6 text-white"
                                  fill="none"
                                  viewBox="0 0 24 24"
                                  stroke="currentColor"
                                >
                                  {i === 0 && (
                                    <path
                                      strokeLinecap="round"
                                      strokeLinejoin="round"
                                      strokeWidth={2}
                                      d="M7 21a4 4 0 01-4-4V5a2 2 0 012-2h4a2 2 0 012 2v12a4 4 0 01-4 4zm0 0h12a2 2 0 002-2v-4a2 2 0 00-2-2h-2.343M11 7.343l1.657-1.657a2 2 0 012.828 0l2.829 2.829a2 2 0 010 2.828l-8.486 8.485M7 17h.01"
                                    />
                                  )}
                                  {i === 1 && (
                                    <path
                                      strokeLinecap="round"
                                      strokeLinejoin="round"
                                      strokeWidth={2}
                                      d="M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4"
                                    />
                                  )}
                                  {i === 2 && (
                                    <path
                                      strokeLinecap="round"
                                      strokeLinejoin="round"
                                      strokeWidth={2}
                                      d="M13 10V3L4 14h7v7l9-11h-7z"
                                    />
                                  )}
                                </svg>
                              </span>
                            </div>
                            <h3 className="mt-8 text-lg font-medium text-gray-900 dark:text-white tracking-tight">
                              {feature}
                            </h3>
                            <p className="mt-5 text-base text-gray-500 dark:text-gray-400">
                              Description of the {i + 1} amazing feature of your website builder.
                            </p>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </section>
          ))}
      </main>

      {settings.components.footer && (
        <footer className="bg-white dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700 py-8">
          <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="md:flex md:justify-between">
              <div className="mb-8 md:mb-0">
                <div className="flex items-center">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="text-primary h-6 w-6 mr-2"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <path d="m16 16 3-8 3 8c-.87.65-1.92 1-3 1s-2.13-.35-3-1Z" />
                    <path d="m2 16 3-8 3 8c-.87.65-1.92 1-3 1s-2.13-.35-3-1Z" />
                    <path d="M7 21h10" />
                    <path d="M12 3v18" />
                    <path d="M3 7h2c2 0 5-1 7-2 2 1 5 2 7 2h2" />
                  </svg>
                  <span className="font-bold text-xl">{content.siteName}</span>
                </div>
                <p className="mt-2 text-sm text-gray-500 dark:text-gray-400">
                  {content.tagline}
                </p>
              </div>
              
              {settings.components.socialLinks && (
                <div className="flex space-x-6 mt-8 md:mt-0">
                  <a href="#" className="text-gray-400 hover:text-gray-500">
                    <span className="sr-only">Facebook</span>
                    <svg className="h-6 w-6" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                      <path fillRule="evenodd" d="M22 12c0-5.523-4.477-10-10-10S2 6.477 2 12c0 4.991 3.657 9.128 8.438 9.878v-6.987h-2.54V12h2.54V9.797c0-2.506 1.492-3.89 3.777-3.89 1.094 0 2.238.195 2.238.195v2.46h-1.26c-1.243 0-1.63.771-1.63 1.562V12h2.773l-.443 2.89h-2.33v6.988C18.343 21.128 22 16.991 22 12z" clipRule="evenodd" />
                    </svg>
                  </a>
                  <a href="#" className="text-gray-400 hover:text-gray-500">
                    <span className="sr-only">Instagram</span>
                    <svg className="h-6 w-6" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                      <path fillRule="evenodd" d="M12.315 2c2.43 0 2.784.013 3.808.06 1.064.049 1.791.218 2.427.465a4.902 4.902 0 011.772 1.153 4.902 4.902 0 011.153 1.772c.247.636.416 1.363.465 2.427.048 1.067.06 1.407.06 4.123v.08c0 2.643-.012 2.987-.06 4.043-.049 1.064-.218 1.791-.465 2.427a4.902 4.902 0 01-1.153 1.772 4.902 4.902 0 01-1.772 1.153c-.636.247-1.363.416-2.427.465-1.067.048-1.407.06-4.123.06h-.08c-2.643 0-2.987-.012-4.043-.06-1.064-.049-1.791-.218-2.427-.465a4.902 4.902 0 01-1.772-1.153 4.902 4.902 0 01-1.153-1.772c-.247-.636-.416-1.363-.465-2.427-.047-1.024-.06-1.379-.06-3.808v-.63c0-2.43.013-2.784.06-3.808.049-1.064.218-1.791.465-2.427a4.902 4.902 0 011.153-1.772A4.902 4.902 0 015.45 2.525c.636-.247 1.363-.416 2.427-.465C8.901 2.013 9.256 2 11.685 2h.63zm-.081 1.802h-.468c-2.456 0-2.784.011-3.807.058-.975.045-1.504.207-1.857.344-.467.182-.8.398-1.15.748-.35.35-.566.683-.748 1.15-.137.353-.3.882-.344 1.857-.047 1.023-.058 1.351-.058 3.807v.468c0 2.456.011 2.784.058 3.807.045.975.207 1.504.344 1.857.182.466.399.8.748 1.15.35.35.683.566 1.15.748.353.137.882.3 1.857.344 1.054.048 1.37.058 4.041.058h.08c2.597 0 2.917-.01 3.96-.058.976-.045 1.505-.207 1.858-.344.466-.182.8-.398 1.15-.748.35-.35.566-.683.748-1.15.137-.353.3-.882.344-1.857.048-1.055.058-1.37.058-4.041v-.08c0-2.597-.01-2.917-.058-3.96-.045-.976-.207-1.505-.344-1.858a3.097 3.097 0 00-.748-1.15 3.098 3.098 0 00-1.15-.748c-.353-.137-.882-.3-1.857-.344-1.023-.047-1.351-.058-3.807-.058zM12 6.865a5.135 5.135 0 110 10.27 5.135 5.135 0 010-10.27zm0 1.802a3.333 3.333 0 100 6.666 3.333 3.333 0 000-6.666zm5.338-3.205a1.2 1.2 0 110 2.4 1.2 1.2 0 010-2.4z" clipRule="evenodd" />
                    </svg>
                  </a>
                  <a href="#" className="text-gray-400 hover:text-gray-500">
                    <span className="sr-only">Twitter</span>
                    <svg className="h-6 w-6" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                      <path d="M8.29 20.251c7.547 0 11.675-6.253 11.675-11.675 0-.178 0-.355-.012-.53A8.348 8.348 0 0022 5.92a8.19 8.19 0 01-2.357.646 4.118 4.118 0 001.804-2.27 8.224 8.224 0 01-2.605.996 4.107 4.107 0 00-6.993 3.743 11.65 11.65 0 01-8.457-4.287 4.106 4.106 0 001.27 5.477A4.072 4.072 0 012.8 9.713v.052a4.105 4.105 0 003.292 4.022 4.095 4.095 0 01-1.853.07 4.108 4.108 0 003.834 2.85A8.233 8.233 0 012 18.407a11.616 11.616 0 006.29 1.84" />
                    </svg>
                  </a>
                </div>
              )}
            </div>
            <div className="mt-8 border-t border-gray-200 dark:border-gray-700 pt-8 md:flex md:items-center md:justify-between">
              <p className="text-base text-gray-400">
                &copy; {new Date().getFullYear()} {content.siteName}. All rights reserved.
              </p>
              <div className="flex space-x-6 mt-4 md:mt-0">
                <a href="#" className="text-gray-400 hover:text-gray-500 text-sm">
                  Privacy Policy
                </a>
                <a href="#" className="text-gray-400 hover:text-gray-500 text-sm">
                  Terms of Service
                </a>
                <a href="#" className="text-gray-400 hover:text-gray-500 text-sm">
                  Cookie Policy
                </a>
              </div>
            </div>
          </div>
        </footer>
      )}
    </>
  );
}
