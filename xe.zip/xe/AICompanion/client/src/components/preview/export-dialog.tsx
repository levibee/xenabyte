import { useState } from "react";
import { X, Copy, Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { WebsiteData } from "@/types";
import { generateHtmlCode, generateCssCode, generateJsCode } from "@/lib/utils";

interface ExportDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  websiteData: WebsiteData;
}

export default function ExportDialog({
  open,
  onOpenChange,
  websiteData,
}: ExportDialogProps) {
  const [copied, setCopied] = useState(false);
  const [activeTab, setActiveTab] = useState("html");
  const { toast } = useToast();

  const getCodeForTab = () => {
    switch (activeTab) {
      case "html":
        return generateHtmlCode(websiteData);
      case "css":
        return generateCssCode(websiteData);
      case "js":
        return generateJsCode(websiteData);
      default:
        return "";
    }
  };

  const handleCopyCode = () => {
    const code = getCodeForTab();
    navigator.clipboard.writeText(code)
      .then(() => {
        setCopied(true);
        toast({
          title: "Copied to clipboard",
          description: `${activeTab.toUpperCase()} code has been copied to your clipboard.`,
        });
        setTimeout(() => setCopied(false), 2000);
      })
      .catch(() => {
        toast({
          title: "Failed to copy",
          description: "An error occurred while copying the code.",
          variant: "destructive",
        });
      });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-xl">
        <DialogHeader>
          <DialogTitle>Website Source Code</DialogTitle>
          <Button
            variant="ghost"
            size="icon"
            className="absolute right-4 top-4"
            onClick={() => onOpenChange(false)}
          >
            <X className="h-4 w-4" />
            <span className="sr-only">Close</span>
          </Button>
        </DialogHeader>

        <Tabs
          defaultValue="html"
          value={activeTab}
          onValueChange={setActiveTab}
          className="mt-4"
        >
          <div className="flex justify-between items-center">
            <TabsList>
              <TabsTrigger value="html">HTML</TabsTrigger>
              <TabsTrigger value="css">CSS</TabsTrigger>
              <TabsTrigger value="js">JavaScript</TabsTrigger>
            </TabsList>
            <Button
              variant="outline"
              size="sm"
              onClick={handleCopyCode}
              className="gap-1"
            >
              {copied ? (
                <>
                  <Check className="h-4 w-4" />
                  Copied
                </>
              ) : (
                <>
                  <Copy className="h-4 w-4" />
                  Copy Code
                </>
              )}
            </Button>
          </div>

          <TabsContent
            value="html"
            className="mt-4 rounded-md bg-muted p-4 overflow-auto max-h-[400px]"
          >
            <pre className="text-sm text-foreground whitespace-pre-wrap">
              {generateHtmlCode(websiteData)}
            </pre>
          </TabsContent>

          <TabsContent
            value="css"
            className="mt-4 rounded-md bg-muted p-4 overflow-auto max-h-[400px]"
          >
            <pre className="text-sm text-foreground whitespace-pre-wrap">
              {generateCssCode(websiteData)}
            </pre>
          </TabsContent>

          <TabsContent
            value="js"
            className="mt-4 rounded-md bg-muted p-4 overflow-auto max-h-[400px]"
          >
            <pre className="text-sm text-foreground whitespace-pre-wrap">
              {generateJsCode(websiteData)}
            </pre>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}
