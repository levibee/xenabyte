import { Smartphone, Tablet, Monitor } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

interface PreviewControlsProps {
  activeMode: "desktop" | "tablet" | "mobile";
  onModeChange: (mode: "desktop" | "tablet" | "mobile") => void;
}

export default function PreviewControls({
  activeMode,
  onModeChange,
}: PreviewControlsProps) {
  return (
    <div className="flex space-x-2">
      <Button
        variant="ghost"
        size="sm"
        onClick={() => onModeChange("mobile")}
        className={cn(
          activeMode === "mobile"
            ? "text-primary"
            : "text-muted-foreground"
        )}
      >
        <Smartphone className="h-5 w-5" />
        <span className="sr-only">Mobile preview</span>
      </Button>
      <Button
        variant="ghost"
        size="sm"
        onClick={() => onModeChange("tablet")}
        className={cn(
          activeMode === "tablet"
            ? "text-primary"
            : "text-muted-foreground"
        )}
      >
        <Tablet className="h-5 w-5" />
        <span className="sr-only">Tablet preview</span>
      </Button>
      <Button
        variant="ghost"
        size="sm"
        onClick={() => onModeChange("desktop")}
        className={cn(
          activeMode === "desktop"
            ? "text-primary"
            : "text-muted-foreground"
        )}
      >
        <Monitor className="h-5 w-5" />
        <span className="sr-only">Desktop preview</span>
      </Button>
    </div>
  );
}
