import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { ImageGenerationRequest, generateImage, getImageCredits } from "@/lib/image-generator";
import { useQuery } from "@tanstack/react-query";
import { Paintbrush, Image as ImageIcon, Download, Sparkles, Loader2 } from "lucide-react";

import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useAuth } from "@/hooks/useAuth";
import { Progress } from "@/components/ui/progress";

interface ImageGeneratorDialogProps {
  onImageGenerated?: (imageUrl: string) => void;
  buttonLabel?: string;
  buttonVariant?: "default" | "outline" | "secondary" | "ghost" | "link";
  defaultPrompt?: string;
}

export default function ImageGeneratorDialog({
  onImageGenerated,
  buttonLabel = "Generate Image",
  buttonVariant = "default",
  defaultPrompt = ""
}: ImageGeneratorDialogProps) {
  const [open, setOpen] = useState(false);
  const [prompt, setPrompt] = useState(defaultPrompt);
  const [size, setSize] = useState<ImageGenerationRequest["size"]>("1024x1024");
  const [style, setStyle] = useState<ImageGenerationRequest["style"]>("vivid");
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedImage, setGeneratedImage] = useState<string | null>(null);
  const { toast } = useToast();
  const { isAuthenticated, user } = useAuth();

  // Get user's image credits
  const { data: credits, refetch: refetchCredits } = useQuery({
    queryKey: ["/api/image-credits"],
    enabled: open && isAuthenticated,
  });

  const handleGenerate = async () => {
    if (!prompt.trim()) {
      toast({
        title: "Please enter a prompt",
        description: "Describe the image you want to generate",
        variant: "destructive",
      });
      return;
    }

    setIsGenerating(true);
    setGeneratedImage(null);

    try {
      const result = await generateImage({
        prompt: prompt,
        size: size,
        style: style
      });

      setGeneratedImage(result.url);
      
      if (onImageGenerated) {
        onImageGenerated(result.url);
      }
      
      // Refetch credits after generating an image
      refetchCredits();
      
      toast({
        title: "Image generated",
        description: "Your image has been generated successfully",
      });
    } catch (error: any) {
      toast({
        title: "Generation failed",
        description: error.message || "Failed to generate image. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsGenerating(false);
    }
  };

  const handleDownload = () => {
    if (!generatedImage) return;
    
    // Create a temporary anchor element and trigger download
    const a = document.createElement("a");
    a.href = generatedImage;
    a.download = `xenabyte-image-${Date.now()}.png`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant={buttonVariant} className="gap-2">
          <Paintbrush className="h-4 w-4" />
          {buttonLabel}
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[600px]">
        <DialogHeader>
          <DialogTitle>AI Image Generator</DialogTitle>
          <DialogDescription>
            Generate custom images for your website using AI
          </DialogDescription>
        </DialogHeader>

        {isAuthenticated && credits && (
          <div className="mb-4">
            <div className="flex justify-between text-sm mb-1">
              <span>Credits: {credits.used} / {credits.limit}</span>
              <span>{credits.remaining} remaining</span>
            </div>
            <Progress value={(credits.used / credits.limit) * 100} />
            {credits.remaining <= 0 && (
              <p className="text-destructive text-sm mt-2">
                You've used all your image generation credits for this month.
                {user?.subscriptionTier === 'free' && (
                  <> Consider upgrading your plan for more credits.</>
                )}
              </p>
            )}
          </div>
        )}

        <div className="grid gap-4 py-4">
          <div className="grid gap-2">
            <Label htmlFor="prompt">Describe your image</Label>
            <Textarea
              id="prompt"
              placeholder="A professional logo for a tech company with futuristic design"
              rows={3}
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              className="resize-none"
            />
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div className="grid gap-2">
              <Label htmlFor="size">Size</Label>
              <Select value={size} onValueChange={(value) => setSize(value as any)}>
                <SelectTrigger id="size">
                  <SelectValue placeholder="Select size" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="1024x1024">Square (1024x1024)</SelectItem>
                  <SelectItem value="1024x1792">Portrait (1024x1792)</SelectItem>
                  <SelectItem value="1792x1024">Landscape (1792x1024)</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="grid gap-2">
              <Label htmlFor="style">Style</Label>
              <Select value={style} onValueChange={(value) => setStyle(value as any)}>
                <SelectTrigger id="style">
                  <SelectValue placeholder="Select style" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="vivid">Vivid</SelectItem>
                  <SelectItem value="natural">Natural</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          {generatedImage && (
            <div className="mt-2 border rounded-md overflow-hidden">
              <div className="relative aspect-square max-h-[300px] overflow-hidden flex items-center justify-center bg-muted">
                <img 
                  src={generatedImage} 
                  alt="Generated image" 
                  className="max-w-full max-h-full object-contain"
                />
              </div>
              <div className="p-2 flex justify-end border-t">
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="gap-1"
                  onClick={handleDownload}
                >
                  <Download className="h-4 w-4" />
                  Download
                </Button>
              </div>
            </div>
          )}
        </div>
        
        <DialogFooter className="gap-2">
          <Button 
            variant="outline" 
            onClick={() => setOpen(false)}
            disabled={isGenerating}
          >
            Cancel
          </Button>
          <Button
            onClick={handleGenerate}
            disabled={isGenerating || (credits?.remaining <= 0)}
            className="gap-2"
          >
            {isGenerating ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin" />
                Generating...
              </>
            ) : (
              <>
                <Sparkles className="h-4 w-4" />
                Generate Image
              </>
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}