import { useState, useEffect } from "react";
import { templates, getTemplateById } from "@/lib/templates";
import { 
  WebsiteData, 
  WebsiteStyle, 
  WebsiteContent, 
  WebsiteSettings,
  Template
} from "@/types";

const defaultStyle: WebsiteStyle = {
  colors: {
    primary: "#3b82f6",
    secondary: "#8b5cf6",
    accent: "#f59e0b",
    background: "#ffffff",
    text: "#1f2937",
  },
  fonts: {
    heading: "Inter",
    body: "Inter",
  },
  layout: "standard",
};

const defaultContent: WebsiteContent = {
  siteName: "My Awesome Website",
  tagline: "A short description of your website",
  sections: [],
};

const defaultSettings: WebsiteSettings = {
  components: {
    navigation: true,
    footer: true,
    contactForm: false,
    gallery: false,
    socialLinks: false,
  },
  effects: {
    parallax: false,
    fadeIn: false,
    smoothScroll: true,
  },
  seo: {
    metaTitle: "",
    metaDescription: "",
  },
  performance: {
    lazyLoading: true,
    minifyCode: true,
    caching: false,
  },
};

const initialWebsiteData: WebsiteData = {
  templateId: null,
  style: defaultStyle,
  content: defaultContent,
  settings: defaultSettings,
};

export default function useWebsiteBuilder() {
  const [websiteData, setWebsiteData] = useState<WebsiteData>(initialWebsiteData);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  useEffect(() => {
    // Initialize SEO fields with default content if empty
    if (!websiteData.settings.seo.metaTitle) {
      updateSettings({
        seo: {
          ...websiteData.settings.seo,
          metaTitle: `${websiteData.content.siteName} | Official Website`,
        },
      });
    }
    
    if (!websiteData.settings.seo.metaDescription) {
      updateSettings({
        seo: {
          ...websiteData.settings.seo,
          metaDescription: websiteData.content.tagline,
        },
      });
    }
  }, [websiteData.content.siteName, websiteData.content.tagline]);

  const selectTemplate = (templateId: number) => {
    setIsLoading(true);
    setError(null);
    
    try {
      const template = getTemplateById(templateId);
      
      if (!template) {
        throw new Error(`Template with ID ${templateId} not found`);
      }
      
      setWebsiteData({
        ...websiteData,
        templateId,
        content: {
          ...websiteData.content,
          sections: [...template.defaultSections],
        },
      });
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to select template");
    } finally {
      setIsLoading(false);
    }
  };

  const updateStyle = (styleUpdates: Partial<WebsiteStyle>) => {
    setWebsiteData({
      ...websiteData,
      style: {
        ...websiteData.style,
        ...styleUpdates,
      },
    });
  };

  const updateContent = (contentUpdates: Partial<WebsiteContent>) => {
    setWebsiteData({
      ...websiteData,
      content: {
        ...websiteData.content,
        ...contentUpdates,
      },
    });
  };

  const updateSettings = (settingsUpdates: Partial<WebsiteSettings>) => {
    setWebsiteData({
      ...websiteData,
      settings: {
        ...websiteData.settings,
        ...settingsUpdates,
      },
    });
  };

  const resetWebsite = () => {
    setWebsiteData(initialWebsiteData);
  };

  return {
    templates,
    websiteData,
    selectTemplate,
    updateStyle,
    updateContent,
    updateSettings,
    resetWebsite,
    isLoading,
    error,
  };
}
