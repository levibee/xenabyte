import { pgTable, text, serial, integer, boolean, timestamp, jsonb, varchar, index } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Session storage table for authentication
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// Define users table with enhanced features
export const users = pgTable("users", {
  id: varchar("id").primaryKey().notNull(),
  email: text("email").unique(),
  username: text("username").unique(),
  password: text("password"),
  firstName: text("first_name"),
  lastName: text("last_name"),
  profileImageUrl: text("profile_image_url"),
  role: text("role").default("user").notNull(), // "user" or "admin"
  isActive: boolean("is_active").default(true),
  subscriptionTier: text("subscription_tier").default("free"), // "free", "basic", "premium", "enterprise"
  subscriptionStatus: text("subscription_status").default("active"), // "active", "expired", "cancelled"
  mpesaPhoneNumber: text("mpesa_phone_number"),
  stripeCustomerId: text("stripe_customer_id"),
  stripeSubscriptionId: text("stripe_subscription_id"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Subscription plans table
export const subscriptionPlans = pgTable("subscription_plans", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  price: integer("price").notNull(), // in cents
  currency: text("currency").default("USD").notNull(),
  billingCycle: text("billing_cycle").default("monthly").notNull(), // "monthly", "yearly"
  features: jsonb("features").notNull(), // Array of features included in this plan
  maxWebsites: integer("max_websites").default(3).notNull(),
  aiCreditsPerMonth: integer("ai_credits_per_month").default(10).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Payment records table
export const payments = pgTable("payments", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").references(() => users.id).notNull(),
  amount: integer("amount").notNull(), // in cents
  currency: text("currency").default("USD").notNull(),
  paymentMethod: text("payment_method").notNull(), // "mpesa", "card"
  paymentReference: text("payment_reference"),
  status: text("status").default("pending").notNull(), // "pending", "completed", "failed"
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Define templates table for storing website templates
export const templates = pgTable("templates", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  popularity: text("popularity").notNull(),
  thumbnail: text("thumbnail").notNull(),
  defaultSections: jsonb("default_sections").notNull(),
  category: text("category").default("general").notNull(), // "business", "portfolio", "e-commerce", etc.
  minSubscriptionTier: text("min_subscription_tier").default("free").notNull(), // minimum subscription tier to access
  created: timestamp("created").defaultNow().notNull(),
  updated: timestamp("updated").defaultNow().notNull(),
});

// Define websites table for storing user-created websites
export const websites = pgTable("websites", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").references(() => users.id).notNull(),
  name: text("name").notNull(),
  data: jsonb("data").notNull(), // Stores the complete website data (template, styles, content, settings)
  isPublished: boolean("is_published").default(false),
  publishedUrl: text("published_url"),
  isFeatured: boolean("is_featured").default(false),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Chat messages for the chatbot
export const chatMessages = pgTable("chat_messages", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").references(() => users.id),
  sessionId: text("session_id").notNull(), // To group messages in a conversation
  content: text("content").notNull(),
  role: text("role").notNull(), // "user" or "assistant"
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Define exported_websites table for storing generated code
export const exportedWebsites = pgTable("exported_websites", {
  id: serial("id").primaryKey(),
  websiteId: integer("website_id").references(() => websites.id).notNull(),
  html: text("html").notNull(),
  css: text("css").notNull(),
  js: text("js").notNull(),
  downloadUrl: text("download_url"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// HTML Templates that admins can upload and manage
export const htmlTemplates = pgTable("html_templates", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  category: text("category").default("general").notNull(), // business, portfolio, blog, etc.
  html: text("html").notNull(),
  css: text("css"),
  js: text("js"),
  previewImage: text("preview_image"),
  isPremium: boolean("is_premium").default(false),
  downloadPrice: integer("download_price").default(0), // in cents, for premium templates
  downloads: integer("downloads").default(0),
  createdBy: varchar("created_by", { length: 255 }).references(() => users.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Create Zod schemas for inserting and validating data
export const insertUserSchema = createInsertSchema(users).pick({
  email: true,
  username: true,
  password: true,
  firstName: true,
  lastName: true,
  profileImageUrl: true,
  mpesaPhoneNumber: true,
});

export const upsertUserSchema = createInsertSchema(users);

export const insertSubscriptionPlanSchema = createInsertSchema(subscriptionPlans).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertPaymentSchema = createInsertSchema(payments).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertChatMessageSchema = createInsertSchema(chatMessages).omit({
  id: true,
  createdAt: true,
});

export const insertTemplateSchema = createInsertSchema(templates).omit({
  id: true,
  created: true, 
  updated: true,
});

export const insertWebsiteSchema = createInsertSchema(websites).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
}).extend({
  // Extend with more specific validation for the data field
  data: z.object({
    templateId: z.number().nullable(),
    style: z.object({
      colors: z.object({
        primary: z.string(),
        secondary: z.string(),
        accent: z.string(),
        background: z.string(),
        text: z.string(),
      }),
      fonts: z.object({
        heading: z.string(),
        body: z.string(),
      }),
      layout: z.enum(["standard", "sidebar", "minimal"]),
    }),
    content: z.object({
      siteName: z.string(),
      tagline: z.string(),
      logo: z.string().optional(),
      sections: z.array(z.object({
        id: z.number(),
        type: z.enum(["hero", "features", "content", "gallery", "testimonials", "contact"]),
        title: z.string(),
        heading: z.string().optional(),
        subheading: z.string().optional(),
        content: z.string().optional(),
        image: z.string().optional(),
        features: z.array(z.string()).optional(),
        items: z.array(z.object({
          title: z.string(),
          description: z.string(),
          image: z.string().optional(),
          content: z.string().optional(),
        })).optional(),
      })),
    }),
    settings: z.object({
      components: z.object({
        navigation: z.boolean(),
        footer: z.boolean(),
        contactForm: z.boolean(),
        gallery: z.boolean(),
        socialLinks: z.boolean(),
      }),
      effects: z.object({
        parallax: z.boolean(),
        fadeIn: z.boolean(),
        smoothScroll: z.boolean(),
      }),
      seo: z.object({
        metaTitle: z.string(),
        metaDescription: z.string(),
      }),
      performance: z.object({
        lazyLoading: z.boolean(),
        minifyCode: z.boolean(),
        caching: z.boolean(),
      }),
    }),
  }),
});

export const insertExportedWebsiteSchema = createInsertSchema(exportedWebsites).omit({
  id: true,
  createdAt: true,
});

export const insertHtmlTemplateSchema = createInsertSchema(htmlTemplates).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  downloads: true,
});

// Domain management table for tracking subdomains and custom domains
export const domains = pgTable("domains", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").references(() => users.id).notNull(),
  websiteId: integer("website_id").references(() => websites.id),
  subdomain: text("subdomain").unique(), // e.g., "mysite" for mysite.xenabyte.com
  customDomain: text("custom_domain").unique(), // Premium feature: custom domain
  status: text("status").default("pending").notNull(), // "pending", "active", "inactive"
  isVerified: boolean("is_verified").default(false),
  verificationCode: text("verification_code"),
  dnsRecords: jsonb("dns_records"), // DNS configuration data
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertDomainSchema = createInsertSchema(domains).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

// Define types
export type UpsertUser = typeof users.$inferInsert;
export type User = typeof users.$inferSelect;

export type InsertSubscriptionPlan = z.infer<typeof insertSubscriptionPlanSchema>;
export type SubscriptionPlan = typeof subscriptionPlans.$inferSelect;

export type InsertPayment = z.infer<typeof insertPaymentSchema>;
export type Payment = typeof payments.$inferSelect;

export type InsertChatMessage = z.infer<typeof insertChatMessageSchema>;
export type ChatMessage = typeof chatMessages.$inferSelect;

export type InsertTemplate = z.infer<typeof insertTemplateSchema>;
export type Template = typeof templates.$inferSelect;

export type InsertWebsite = z.infer<typeof insertWebsiteSchema>;
export type Website = typeof websites.$inferSelect;

export type InsertExportedWebsite = z.infer<typeof insertExportedWebsiteSchema>;
export type ExportedWebsite = typeof exportedWebsites.$inferSelect;

export type InsertHtmlTemplate = z.infer<typeof insertHtmlTemplateSchema>;
export type HtmlTemplate = typeof htmlTemplates.$inferSelect;

export type InsertDomain = z.infer<typeof insertDomainSchema>;
export type Domain = typeof domains.$inferSelect;
