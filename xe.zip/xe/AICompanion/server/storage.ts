import { db } from "./db";
import { eq, and } from "drizzle-orm";
import { 
  users, User, UpsertUser,
  websites, Website, InsertWebsite,
  templates, Template,
  exportedWebsites, ExportedWebsite, InsertExportedWebsite,
  subscriptionPlans, SubscriptionPlan,
  payments, Payment, InsertPayment,
  chatMessages, ChatMessage, InsertChatMessage,
  htmlTemplates, HtmlTemplate, InsertHtmlTemplate,
  domains, Domain, InsertDomain
} from "@shared/schema";

export interface IStorage {
  // User operations
  getUser(id: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  upsertUser(userData: UpsertUser): Promise<User>;
  updateUserSubscription(userId: string, tier: string, status: string): Promise<User>;
  updateStripeInfo(userId: string, customerId: string, subscriptionId: string): Promise<User>;
  
  // Website operations
  getAllWebsites(): Promise<Website[]>;
  getWebsites(userId: string): Promise<Website[]>;
  getWebsiteById(id: number): Promise<Website | undefined>;
  createWebsite(website: InsertWebsite): Promise<Website>;
  updateWebsite(id: number, data: Partial<InsertWebsite>): Promise<Website>;
  deleteWebsite(id: number): Promise<boolean>;
  
  // Template operations
  getAllTemplates(): Promise<Template[]>;
  getTemplateById(id: number): Promise<Template | undefined>;
  
  // HTML Template operations for admin uploads
  getAllHtmlTemplates(): Promise<HtmlTemplate[]>;
  getHtmlTemplateById(id: number): Promise<HtmlTemplate | undefined>;
  createHtmlTemplate(template: InsertHtmlTemplate): Promise<HtmlTemplate>;
  updateHtmlTemplate(id: number, data: Partial<InsertHtmlTemplate>): Promise<HtmlTemplate>;
  deleteHtmlTemplate(id: number): Promise<boolean>;
  incrementHtmlTemplateDownloads(id: number): Promise<HtmlTemplate>;
  
  // Domain operations
  getDomains(userId: string): Promise<Domain[]>;
  getDomainById(id: number): Promise<Domain | undefined>;
  getDomainBySubdomain(subdomain: string): Promise<Domain | undefined>;
  getDomainByCustomDomain(customDomain: string): Promise<Domain | undefined>;
  createDomain(domain: InsertDomain): Promise<Domain>;
  updateDomain(id: number, data: Partial<InsertDomain>): Promise<Domain>;
  deleteDomain(id: number): Promise<boolean>;
  verifyDomain(id: number): Promise<Domain>;
  
  // Export operations
  createExportedWebsite(exportedWebsite: InsertExportedWebsite): Promise<ExportedWebsite>;
  getExportedWebsiteById(id: number): Promise<ExportedWebsite | undefined>;
  
  // Subscription operations
  getSubscriptionPlans(): Promise<SubscriptionPlan[]>;
  
  // Payment operations
  createPayment(payment: InsertPayment): Promise<Payment>;
  updatePaymentStatus(id: number, status: string): Promise<Payment>;
  
  // Chat operations
  getChatMessages(sessionId: string): Promise<ChatMessage[]>;
  createChatMessage(message: InsertChatMessage): Promise<ChatMessage>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  async updateUserSubscription(userId: string, tier: string, status: string): Promise<User> {
    const [user] = await db
      .update(users)
      .set({ 
        subscriptionTier: tier, 
        subscriptionStatus: status,
        updatedAt: new Date()
      })
      .where(eq(users.id, userId))
      .returning();
    return user;
  }

  async updateStripeInfo(userId: string, customerId: string, subscriptionId: string): Promise<User> {
    const [user] = await db
      .update(users)
      .set({ 
        stripeCustomerId: customerId, 
        stripeSubscriptionId: subscriptionId,
        updatedAt: new Date()
      })
      .where(eq(users.id, userId))
      .returning();
    return user;
  }

  // Website operations
  async getAllWebsites(): Promise<Website[]> {
    return db.select().from(websites);
  }
  
  async getWebsites(userId: string): Promise<Website[]> {
    return db.select().from(websites).where(eq(websites.userId, userId));
  }

  async getWebsiteById(id: number): Promise<Website | undefined> {
    const [website] = await db.select().from(websites).where(eq(websites.id, id));
    return website;
  }

  async createWebsite(website: InsertWebsite): Promise<Website> {
    const [newWebsite] = await db.insert(websites).values(website).returning();
    return newWebsite;
  }

  async updateWebsite(id: number, data: Partial<InsertWebsite>): Promise<Website> {
    const [updatedWebsite] = await db
      .update(websites)
      .set({
        ...data,
        updatedAt: new Date(),
      })
      .where(eq(websites.id, id))
      .returning();
    return updatedWebsite;
  }

  async deleteWebsite(id: number): Promise<boolean> {
    const result = await db.delete(websites).where(eq(websites.id, id)).returning();
    return result.length > 0;
  }

  // Template operations
  async getAllTemplates(): Promise<Template[]> {
    return db.select().from(templates);
  }

  async getTemplateById(id: number): Promise<Template | undefined> {
    const [template] = await db.select().from(templates).where(eq(templates.id, id));
    return template;
  }

  // Export operations
  async createExportedWebsite(exportedWebsite: InsertExportedWebsite): Promise<ExportedWebsite> {
    const [newExport] = await db.insert(exportedWebsites).values(exportedWebsite).returning();
    return newExport;
  }

  // Subscription plans
  async getSubscriptionPlans(): Promise<SubscriptionPlan[]> {
    return db.select().from(subscriptionPlans);
  }

  // Payment operations
  async createPayment(payment: InsertPayment): Promise<Payment> {
    const [newPayment] = await db.insert(payments).values(payment).returning();
    return newPayment;
  }

  async updatePaymentStatus(id: number, status: string): Promise<Payment> {
    const [updatedPayment] = await db
      .update(payments)
      .set({
        status,
        updatedAt: new Date(),
      })
      .where(eq(payments.id, id))
      .returning();
    return updatedPayment;
  }

  // Chat operations
  async getChatMessages(sessionId: string): Promise<ChatMessage[]> {
    return db.select().from(chatMessages).where(eq(chatMessages.sessionId, sessionId));
  }

  async createChatMessage(message: InsertChatMessage): Promise<ChatMessage> {
    const [newMessage] = await db.insert(chatMessages).values(message).returning();
    return newMessage;
  }
}

export const storage = new DatabaseStorage();
