import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";
import { insertWebsiteSchema, insertExportedWebsiteSchema } from "@shared/schema";
import { isAuthenticated, isAdmin } from "./replitAuth";
import chatRoutes from "./routes/chatRoutes";

export async function registerRoutes(app: Express): Promise<Server> {
  // Use chat routes
  app.use("/api", chatRoutes);
  
  // Auth routes
  app.get("/api/auth/user", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });
  
  // prefix all routes with /api
  
  // Get all templates
  app.get("/api/templates", async (req, res) => {
    try {
      const templates = await storage.getAllTemplates();
      res.json(templates);
    } catch (error) {
      console.error("Error fetching templates:", error);
      res.status(500).json({ message: "Failed to fetch templates" });
    }
  });

  // Get template by ID
  app.get("/api/templates/:id", async (req, res) => {
    try {
      const templateId = parseInt(req.params.id);
      if (isNaN(templateId)) {
        return res.status(400).json({ message: "Invalid template ID" });
      }
      
      const template = await storage.getTemplateById(templateId);
      if (!template) {
        return res.status(404).json({ message: "Template not found" });
      }
      
      res.json(template);
    } catch (error) {
      console.error("Error fetching template:", error);
      res.status(500).json({ message: "Failed to fetch template" });
    }
  });

  // Get all websites
  app.get("/api/websites", async (req, res) => {
    try {
      const websites = await storage.getAllWebsites();
      res.json(websites);
    } catch (error) {
      console.error("Error fetching websites:", error);
      res.status(500).json({ message: "Failed to fetch websites" });
    }
  });

  // Get website by ID
  app.get("/api/websites/:id", async (req, res) => {
    try {
      const websiteId = parseInt(req.params.id);
      if (isNaN(websiteId)) {
        return res.status(400).json({ message: "Invalid website ID" });
      }
      
      const website = await storage.getWebsiteById(websiteId);
      if (!website) {
        return res.status(404).json({ message: "Website not found" });
      }
      
      res.json(website);
    } catch (error) {
      console.error("Error fetching website:", error);
      res.status(500).json({ message: "Failed to fetch website" });
    }
  });

  // Create a new website
  app.post("/api/websites", async (req, res) => {
    try {
      const validatedData = insertWebsiteSchema.parse(req.body);
      const newWebsite = await storage.createWebsite(validatedData);
      res.status(201).json(newWebsite);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid website data", errors: error.errors });
      }
      console.error("Error creating website:", error);
      res.status(500).json({ message: "Failed to create website" });
    }
  });

  // Update a website
  app.put("/api/websites/:id", async (req, res) => {
    try {
      const websiteId = parseInt(req.params.id);
      if (isNaN(websiteId)) {
        return res.status(400).json({ message: "Invalid website ID" });
      }
      
      const validatedData = insertWebsiteSchema.parse(req.body);
      const updatedWebsite = await storage.updateWebsite(websiteId, validatedData);
      
      if (!updatedWebsite) {
        return res.status(404).json({ message: "Website not found" });
      }
      
      res.json(updatedWebsite);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid website data", errors: error.errors });
      }
      console.error("Error updating website:", error);
      res.status(500).json({ message: "Failed to update website" });
    }
  });

  // Delete a website
  app.delete("/api/websites/:id", async (req, res) => {
    try {
      const websiteId = parseInt(req.params.id);
      if (isNaN(websiteId)) {
        return res.status(400).json({ message: "Invalid website ID" });
      }
      
      const success = await storage.deleteWebsite(websiteId);
      
      if (!success) {
        return res.status(404).json({ message: "Website not found" });
      }
      
      res.status(204).end();
    } catch (error) {
      console.error("Error deleting website:", error);
      res.status(500).json({ message: "Failed to delete website" });
    }
  });

  // Export a website
  app.post("/api/websites/export", async (req, res) => {
    try {
      // For exporting, we'll create generated code based on the website data
      const websiteData = req.body;
      
      // Generate HTML, CSS, and JS code based on the website data
      const html = generateHtml(websiteData);
      const css = generateCss(websiteData);
      const js = generateJs(websiteData);
      
      // Store the exported website if there's an associated website ID
      if (websiteData.id) {
        const exportData = {
          websiteId: websiteData.id,
          html,
          css,
          js,
        };
        
        const validatedExportData = insertExportedWebsiteSchema.parse(exportData);
        await storage.createExportedWebsite(validatedExportData);
      }
      
      res.json({ 
        html, 
        css, 
        js,
        success: true,
        message: "Website exported successfully" 
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid export data", errors: error.errors });
      }
      console.error("Error exporting website:", error);
      res.status(500).json({ message: "Failed to export website" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

// Helper functions for generating code
function generateHtml(websiteData: any): string {
  const { content, style, settings } = websiteData;
  
  // This is a simplified example. In a real implementation, this would be more complex
  // with proper templating based on the website structure, sections, components, etc.
  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${content.siteName}</title>
  <meta name="description" content="${settings.seo.metaDescription || content.tagline}">
  <link href="https://fonts.googleapis.com/css2?family=${style.fonts.heading.replace(' ', '+')}:wght@300;400;500;600;700&family=${style.fonts.body.replace(' ', '+')}:wght@300;400;500&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <header>
    <div class="container">
      <div class="logo">
        <span>${content.siteName}</span>
      </div>
      <nav>
        <a href="#" class="active">Home</a>
        <a href="#">Features</a>
        <a href="#">About</a>
        <a href="#">Contact</a>
      </nav>
      <button class="btn-primary">Get Started</button>
    </div>
  </header>

  <main>
    ${content.sections.map(section => {
      if (section.type === "hero") {
        return `<section class="hero">
      <div class="container">
        <div class="hero-content">
          <h1>${section.heading || 'Welcome'} <span>${section.subheading || ''}</span></h1>
          <p>${section.content || content.tagline}</p>
          <div class="buttons">
            <a href="#" class="btn-primary">Get started</a>
            <a href="#" class="btn-secondary">Learn more</a>
          </div>
        </div>
        <div class="hero-image">
          <img src="${section.image || 'assets/hero-image.jpg'}" alt="Hero image">
        </div>
      </div>
    </section>`;
      } else if (section.type === "features") {
        return `<section class="features">
      <div class="container">
        <div class="section-header">
          <span>Features</span>
          <h2>${section.title}</h2>
          <p>Everything you need for your website.</p>
        </div>
        <div class="features-grid">
          ${(section.features || []).map(feature => `
          <div class="feature-card">
            <div class="icon"></div>
            <h3>${feature}</h3>
            <p>Description of this amazing feature.</p>
          </div>
          `).join('')}
        </div>
      </div>
    </section>`;
      } else {
        return `<section class="content">
      <div class="container">
        <h2>${section.title}</h2>
        <div class="content-inner">
          <p>${section.content || ''}</p>
        </div>
      </div>
    </section>`;
      }
    }).join('\n')}
  </main>

  <footer>
    <div class="container">
      <div class="footer-content">
        <div class="footer-logo">
          <span>${content.siteName}</span>
          <p>${content.tagline}</p>
        </div>
        ${settings.components.socialLinks ? `
        <div class="social-links">
          <a href="#"><span class="social-icon">Facebook</span></a>
          <a href="#"><span class="social-icon">Twitter</span></a>
          <a href="#"><span class="social-icon">Instagram</span></a>
        </div>
        ` : ''}
      </div>
      <div class="footer-bottom">
        <p>&copy; ${new Date().getFullYear()} ${content.siteName}. All rights reserved.</p>
      </div>
    </div>
  </footer>

  <script src="script.js"></script>
</body>
</html>`;
}

function generateCss(websiteData: any): string {
  const { style } = websiteData;
  
  return `/* Main Styles */
:root {
  --primary-color: ${style.colors.primary};
  --secondary-color: ${style.colors.secondary};
  --accent-color: ${style.colors.accent};
  --background-color: ${style.colors.background};
  --text-color: ${style.colors.text};
  --heading-font: "${style.fonts.heading}", sans-serif;
  --body-font: "${style.fonts.body}", sans-serif;
}

/* Reset and base styles */
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

body {
  font-family: var(--body-font);
  color: var(--text-color);
  background-color: var(--background-color);
  line-height: 1.6;
}

.container {
  width: 100%;
  max-width: 1200px;
  margin: 0 auto;
  padding: 0 20px;
}

h1, h2, h3, h4, h5, h6 {
  font-family: var(--heading-font);
  font-weight: 700;
  line-height: 1.3;
}

a {
  text-decoration: none;
  color: var(--primary-color);
  transition: color 0.3s ease;
}

a:hover {
  color: var(--secondary-color);
}

.btn-primary {
  display: inline-block;
  background-color: var(--primary-color);
  color: white;
  padding: 12px 24px;
  border-radius: 6px;
  font-weight: 600;
  transition: background-color 0.3s ease;
  border: none;
  cursor: pointer;
}

.btn-primary:hover {
  background-color: var(--primary-color);
  opacity: 0.9;
}

.btn-secondary {
  display: inline-block;
  background-color: transparent;
  color: var(--primary-color);
  border: 2px solid var(--primary-color);
  padding: 12px 24px;
  border-radius: 6px;
  font-weight: 600;
  transition: all 0.3s ease;
  cursor: pointer;
}

.btn-secondary:hover {
  background-color: var(--primary-color);
  color: white;
}

/* Layout styles for header, hero, features, etc. */
/* Additional CSS would be generated based on the website structure and components */
`;
}

function generateJs(websiteData: any): string {
  const { settings } = websiteData;
  
  let js = `// Main script file
document.addEventListener('DOMContentLoaded', function() {
  console.log('Website initialized!');
  
  // Mobile navigation toggle
  const navToggle = document.querySelector('.nav-toggle');
  const navMenu = document.querySelector('nav');
  
  if (navToggle) {
    navToggle.addEventListener('click', function() {
      navMenu.classList.toggle('active');
    });
  }
`;
  
  // Add smooth scrolling if enabled
  if (settings.effects.smoothScroll) {
    js += `
  // Smooth scrolling
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
      e.preventDefault();
      
      document.querySelector(this.getAttribute('href')).scrollIntoView({
        behavior: 'smooth'
      });
    });
  });`;
  }
  
  // Add fade-in animations if enabled
  if (settings.effects.fadeIn) {
    js += `
  // Fade-in animations
  const fadeElements = document.querySelectorAll('.fade-in');
  
  const fadeInObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('visible');
        fadeInObserver.unobserve(entry.target);
      }
    });
  }, { threshold: 0.1 });
  
  fadeElements.forEach(element => {
    fadeInObserver.observe(element);
  });`;
  }
  
  // Add parallax if enabled
  if (settings.effects.parallax) {
    js += `
  // Parallax scrolling effect
  const parallaxElems = document.querySelectorAll('.parallax');
  
  window.addEventListener('scroll', () => {
    const scrollY = window.scrollY;
    
    parallaxElems.forEach(elem => {
      const speed = elem.dataset.speed || 0.5;
      elem.style.transform = \`translateY(\${scrollY * speed}px)\`;
    });
  });`;
  }
  
  // Close the main function
  js += `
});`;
  
  return js;
}
