import express from "express";
import { isAuthenticated } from "../replitAuth";
import { storage } from "../storage";
import Anthropic from '@anthropic-ai/sdk';

const router = express.Router();

// Initialize Anthropic client
// The newest Anthropic model is "claude-3-7-sonnet-20250219" which was released February 24, 2025
const anthropic = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY || '',
});

// Helper function to get a response from AI
async function getAIResponse(message: string): Promise<string> {
  try {
    // Check if we have an API key
    if (!process.env.ANTHROPIC_API_KEY) {
      // Return a fallback response if no API key is available
      return getFallbackResponse(message);
    }

    const response = await anthropic.messages.create({
      model: 'claude-3-7-sonnet-20250219',
      max_tokens: 500,
      system: `You are a helpful and friendly AI assistant for Xenabyte, a cutting-edge website that uses AI to generate other websites. Your name is Xenabyte Assistant.
      
      When users ask about website creation, provide helpful tips and guide them to use the AI Builder feature.
      When users ask about pricing, mention we have free, basic ($15/month), premium ($39/month), and enterprise (custom pricing) plans.
      When users ask about features, explain that Xenabyte can generate complete websites based on descriptions, supports customization, and offers exporting/publishing options.
      
      Keep responses concise (1-3 sentences) and friendly. Focus on helping the user understand how Xenabyte works and encouraging them to try the AI Builder.`,
      messages: [
        {
          role: 'user',
          content: message
        }
      ],
    });

    return response.content[0].type === 'text' ? response.content[0].text : 'I apologize, but I was unable to process your request properly.';
  } catch (error) {
    console.error("Error getting AI response:", error);
    return "I'm having trouble connecting to my systems. Please try again in a moment.";
  }
}

// Get a deterministic response based on keywords in the message
function getFallbackResponse(message: string): string {
  const messageLC = message.toLowerCase();
  
  if (messageLC.includes("hello") || messageLC.includes("hi") || messageLC.includes("hey")) {
    return "Hello! I'm Xenabyte Assistant. How can I help you with website creation today?";
  }
  
  if (messageLC.includes("website") && (messageLC.includes("create") || messageLC.includes("make") || messageLC.includes("build"))) {
    return "To create a website, head to our AI Builder page and describe what you want. Our AI will generate multiple designs for you to choose from.";
  }
  
  if (messageLC.includes("price") || messageLC.includes("cost") || messageLC.includes("subscription")) {
    return "We offer Free (limited features), Basic ($15/mo), Premium ($39/mo), and Enterprise (custom pricing) plans. Each tier unlocks more features and AI credits.";
  }
  
  if (messageLC.includes("feature") || messageLC.includes("can you")) {
    return "Xenabyte can generate custom websites based on text descriptions, allows full customization of designs, and supports exporting or publishing your sites.";
  }
  
  if (messageLC.includes("payment") || messageLC.includes("mpesa") || messageLC.includes("card")) {
    return "We accept payments via credit/debit cards and M-Pesa. Your payment information is securely processed and never stored on our servers.";
  }
  
  if (messageLC.includes("account") || messageLC.includes("sign up") || messageLC.includes("login")) {
    return "You can create an account by clicking the login button in the top right. We use secure authentication to protect your account.";
  }
  
  return "I'm here to help with any questions about Xenabyte's website building tools. What would you like to know?";
}

// Chat API endpoint
router.post("/chat", async (req, res) => {
  try {
    const { message, sessionId } = req.body;
    
    if (!message || !sessionId) {
      return res.status(400).json({ error: "Message and sessionId are required" });
    }
    
    // Get user ID if authenticated
    let userId: string | undefined;
    if (req.isAuthenticated()) {
      const user = req.user as any;
      userId = user.claims?.sub;
    }
    
    // Store user message
    await storage.createChatMessage({
      userId,
      sessionId,
      content: message,
      role: "user",
    });
    
    // Get AI response
    const response = await getAIResponse(message);
    
    // Store assistant message
    await storage.createChatMessage({
      userId,
      sessionId,
      content: response,
      role: "assistant",
    });
    
    // Return response
    res.json({ message: response });
  } catch (error) {
    console.error("Chat error:", error);
    res.status(500).json({ error: "Failed to process chat message" });
  }
});

// Get chat history (requires authentication)
router.get("/chat/history/:sessionId", isAuthenticated, async (req, res) => {
  try {
    const { sessionId } = req.params;
    const messages = await storage.getChatMessages(sessionId);
    res.json(messages);
  } catch (error) {
    console.error("Error fetching chat history:", error);
    res.status(500).json({ error: "Failed to fetch chat history" });
  }
});

export default router;