import { Router } from "express";
import { isAuthenticated } from "../replitAuth";
import { storage } from "../storage";
import { createObjectCsvWriter } from "csv-writer";
import JSZip from "jszip";
import path from "path";
import fs from "fs";
import { promisify } from "util";
import { db } from "../db";
import { Readable } from "stream";
import pg from "pg";

const router = Router();
const mkdirAsync = promisify(fs.mkdir);
const writeFileAsync = promisify(fs.writeFile);
const unlinkAsync = promisify(fs.unlink);

// Endpoint to export a website with all assets, code, and database (if user has permission)
router.post("/websites/:id/export", isAuthenticated, async (req: any, res) => {
  try {
    const websiteId = parseInt(req.params.id);
    const userId = req.user.claims.sub;
    
    // Check if the website exists and belongs to the user
    const website = await storage.getWebsiteById(websiteId);
    if (!website || website.userId !== userId) {
      return res.status(404).json({ error: "Website not found" });
    }
    
    // Get user subscription to check permissions
    const user = await storage.getUser(userId);
    if (!user) {
      return res.status(404).json({ error: "User not found" });
    }
    
    // Check if user's subscription allows exports
    const canExport = user.subscriptionTier === "basic" || user.subscriptionTier === "premium";
    const includeDatabase = user.subscriptionTier === "premium"; // Only premium gets database export
    
    if (!canExport) {
      return res.status(403).json({ 
        error: "Export not allowed", 
        message: "Please upgrade your subscription to export websites"
      });
    }
    
    // Create a new export record
    const exportId = Date.now(); // Use timestamp for unique export ID
    const exportDir = path.join(__dirname, "../../exports", exportId.toString());
    
    // Create export directory
    await mkdirAsync(exportDir, { recursive: true });
    
    // Generate the website code
    const htmlCode = generateHtmlCode(website.data);
    const cssCode = generateCssCode(website.data);
    const jsCode = generateJsCode(website.data);
    
    // Create a ZIP file
    const zip = new JSZip();
    
    // Add website files to the ZIP
    zip.file("index.html", htmlCode);
    zip.file("styles.css", cssCode);
    zip.file("script.js", jsCode);
    
    // Add assets folder with images
    const assetsFolder = zip.folder("assets");
    
    // TODO: Add images from the website to the assets folder
    // This would require fetching and adding any images used in the website
    
    // Add README with export information
    const readmeContent = generateReadme(website, user);
    zip.file("README.md", readmeContent);
    
    // If user subscription allows, include database export
    if (includeDatabase) {
      const dbFolder = zip.folder("database");
      
      // Export database schema as SQL
      const dbSchema = await exportDatabaseSchema();
      dbFolder.file("schema.sql", dbSchema);
      
      // Export website data as SQL
      const websiteData = await exportWebsiteData(websiteId);
      dbFolder.file("website_data.sql", websiteData);
      
      // Export as CSV for easy import to other systems
      await exportAsCsv(websiteId, exportDir);
      
      // Add CSV files to zip
      const csvFiles = fs.readdirSync(path.join(exportDir, "csv"));
      for (const file of csvFiles) {
        const content = fs.readFileSync(path.join(exportDir, "csv", file));
        dbFolder.file(`csv/${file}`, content);
      }
    }
    
    // Generate the ZIP file
    const zipContent = await zip.generateAsync({ type: "nodebuffer" });
    
    // Save the ZIP file
    const zipPath = path.join(exportDir, `website_${websiteId}.zip`);
    await writeFileAsync(zipPath, zipContent);
    
    // Create a record of this export in the database
    const exportedWebsite = await storage.createExportedWebsite({
      websiteId,
      html: htmlCode,
      css: cssCode,
      js: jsCode,
      includesDatabase: includeDatabase,
    });
    
    // Stream the ZIP file to the client
    res.download(zipPath, `xenabyte_website_${websiteId}.zip`, async (err) => {
      // Cleanup after download (or error)
      try {
        // Delete the ZIP file and export directory after download
        await unlinkAsync(zipPath);
        
        // Use a more robust directory removal that handles files within
        fs.rm(exportDir, { recursive: true, force: true }, (err) => {
          if (err) {
            console.error("Error cleaning up export directory:", err);
          }
        });
      } catch (cleanupError) {
        console.error("Error cleaning up export files:", cleanupError);
      }
    });
  } catch (error) {
    console.error("Export error:", error);
    res.status(500).json({ error: "Failed to export website" });
  }
});

// Helper function to generate HTML code from website data
function generateHtmlCode(websiteData: any): string {
  // Generate HTML for the website based on its data
  // This is a simplified example - you'd replace with your actual code generation logic
  const { siteName, tagline, sections } = websiteData.content;
  
  let sectionsHtml = '';
  if (sections && sections.length > 0) {
    sectionsHtml = sections.map((section: any) => {
      if (section.type === 'hero') {
        return `
          <section id="hero" class="hero-section">
            <div class="container">
              <h1>${section.heading || ''}</h1>
              <p>${section.subheading || ''}</p>
              ${section.content ? `<div class="content">${section.content}</div>` : ''}
            </div>
          </section>
        `;
      } else if (section.type === 'features') {
        const featuresHtml = section.features?.map((feature: any) => 
          `<div class="feature">${feature}</div>`
        ).join('') || '';
        
        return `
          <section id="features" class="features-section">
            <div class="container">
              <h2>${section.heading || 'Features'}</h2>
              <div class="features-grid">
                ${featuresHtml}
              </div>
            </div>
          </section>
        `;
      } else if (section.type === 'content') {
        return `
          <section id="content-${section.id}" class="content-section">
            <div class="container">
              <h2>${section.heading || ''}</h2>
              <div class="content">
                ${section.content || ''}
              </div>
            </div>
          </section>
        `;
      }
      
      return '';
    }).join('\n');
  }

  return `
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${siteName}</title>
  <meta name="description" content="${tagline}">
  <link rel="stylesheet" href="styles.css">
</head>
<body>
  <header>
    <div class="container">
      <div class="logo">
        <h1>${siteName}</h1>
      </div>
      <nav>
        <ul>
          <li><a href="#hero">Home</a></li>
          <li><a href="#features">Features</a></li>
          <li><a href="#contact">Contact</a></li>
        </ul>
      </nav>
    </div>
  </header>
  
  <main>
    ${sectionsHtml}
  </main>
  
  <footer>
    <div class="container">
      <p>&copy; ${new Date().getFullYear()} ${siteName}. All rights reserved.</p>
      <p><small>Built with Xenabyte.</small></p>
    </div>
  </footer>
  
  <script src="script.js"></script>
</body>
</html>
  `;
}

// Helper function to generate CSS code from website data
function generateCssCode(websiteData: any): string {
  // Generate CSS for the website based on its data
  // This is a simplified example - you'd replace with your actual code generation logic
  const { colors, fonts } = websiteData.style;
  
  return `
/* Generated by Xenabyte Website Builder */

:root {
  --primary-color: ${colors.primary};
  --secondary-color: ${colors.secondary};
  --accent-color: ${colors.accent};
  --background-color: ${colors.background};
  --text-color: ${colors.text};
  --heading-font: ${fonts.heading || 'sans-serif'};
  --body-font: ${fonts.body || 'sans-serif'};
}

* {
  box-sizing: border-box;
  margin: 0;
  padding: 0;
}

body {
  font-family: var(--body-font);
  color: var(--text-color);
  background-color: var(--background-color);
  line-height: 1.6;
}

.container {
  width: 100%;
  max-width: 1200px;
  margin: 0 auto;
  padding: 0 20px;
}

header {
  background-color: var(--primary-color);
  color: white;
  padding: 20px 0;
}

header .container {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

nav ul {
  display: flex;
  list-style: none;
}

nav ul li {
  margin-left: 20px;
}

nav ul li a {
  color: white;
  text-decoration: none;
}

h1, h2, h3, h4, h5, h6 {
  font-family: var(--heading-font);
  color: var(--primary-color);
  margin-bottom: 20px;
}

section {
  padding: 60px 0;
}

.hero-section {
  background-color: var(--secondary-color);
  color: white;
  text-align: center;
  padding: 100px 0;
}

.hero-section h1 {
  font-size: 3rem;
  color: white;
}

.features-section {
  background-color: var(--background-color);
}

.features-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
  gap: 30px;
  margin-top: 40px;
}

.feature {
  background-color: white;
  padding: 30px;
  border-radius: 5px;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
}

footer {
  background-color: var(--primary-color);
  color: white;
  text-align: center;
  padding: 30px 0;
}

/* Responsive styles */
@media (max-width: 768px) {
  header .container {
    flex-direction: column;
  }
  
  nav ul {
    margin-top: 20px;
  }
  
  .hero-section h1 {
    font-size: 2rem;
  }
}
  `;
}

// Helper function to generate JS code from website data
function generateJsCode(websiteData: any): string {
  // Generate JavaScript for the website based on its data
  // This is a simplified example - you'd replace with your actual code generation logic
  return `
// Generated by Xenabyte Website Builder

document.addEventListener('DOMContentLoaded', function() {
  // Smooth scrolling for anchor links
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
      e.preventDefault();
      
      const targetId = this.getAttribute('href');
      const targetElement = document.querySelector(targetId);
      
      if (targetElement) {
        window.scrollTo({
          top: targetElement.offsetTop - 70,
          behavior: 'smooth'
        });
      }
    });
  });
  
  // Add any custom JavaScript functionality here
  console.log('Website created with Xenabyte');
});
  `;
}

// Helper function to generate README content
function generateReadme(website: any, user: any): string {
  return `# ${website.data.content.siteName}

This website was exported from Xenabyte on ${new Date().toLocaleDateString()}.

## Website Information
- Created by: ${user.firstName || user.email || 'Xenabyte User'}
- Export date: ${new Date().toISOString()}
- Subscription: ${user.subscriptionTier}

## Files Included
- \`index.html\`: The main HTML file for your website
- \`styles.css\`: All styles for your website
- \`script.js\`: JavaScript functionality
- \`assets/\`: Folder containing all images and media files

${user.subscriptionTier === 'premium' ? `
## Database Export (Premium Feature)
This export includes a database dump in the \`database/\` folder:
- \`schema.sql\`: Database schema
- \`website_data.sql\`: SQL statements to recreate your website data
- \`csv/\`: CSV exports of your data for easy import to other systems
` : ''}

## Made with Xenabyte
This website was created using Xenabyte Website Builder.
Visit https://xenabyte.com for more information.

---
© ${new Date().getFullYear()} Xenabyte
`;
}

// Export database schema as SQL
async function exportDatabaseSchema(): Promise<string> {
  // This is a simplified example - in a real scenario, you'd use pg_dump or similar
  try {
    const tableInfoQuery = `
      SELECT 
        table_name,
        column_name,
        data_type,
        column_default,
        is_nullable
      FROM 
        information_schema.columns
      WHERE 
        table_schema = 'public'
      ORDER BY 
        table_name, ordinal_position;
    `;
    
    const { rows } = await db.query(tableInfoQuery);
    
    let schemaSQL = '-- Xenabyte Database Schema Export\n';
    schemaSQL += `-- Generated: ${new Date().toISOString()}\n\n`;
    
    const tables = [...new Set(rows.map(row => row.table_name))];
    
    for (const table of tables) {
      const tableColumns = rows.filter(row => row.table_name === table);
      
      schemaSQL += `DROP TABLE IF EXISTS "${table}" CASCADE;\n`;
      schemaSQL += `CREATE TABLE "${table}" (\n`;
      
      const columnDefinitions = tableColumns.map(col => {
        let colDef = `  "${col.column_name}" ${col.data_type}`;
        
        if (col.column_default) {
          colDef += ` DEFAULT ${col.column_default}`;
        }
        
        if (col.is_nullable === 'NO') {
          colDef += ' NOT NULL';
        }
        
        return colDef;
      });
      
      schemaSQL += columnDefinitions.join(',\n');
      schemaSQL += '\n);\n\n';
    }
    
    return schemaSQL;
  } catch (error) {
    console.error('Error generating database schema:', error);
    return '-- Error generating database schema';
  }
}

// Export website data as SQL
async function exportWebsiteData(websiteId: number): Promise<string> {
  try {
    // Get all website-related data
    const website = await storage.getWebsiteById(websiteId);
    
    if (!website) {
      return '-- No website data found';
    }
    
    let dataSQL = '-- Xenabyte Website Data Export\n';
    dataSQL += `-- Generated: ${new Date().toISOString()}\n`;
    dataSQL += `-- Website ID: ${websiteId}\n\n`;
    
    // Generate INSERT statements for the website
    dataSQL += `INSERT INTO websites (id, "userId", name, data, "createdAt", "updatedAt") VALUES (\n`;
    dataSQL += `  ${website.id},\n`;
    dataSQL += `  '${website.userId}',\n`;
    dataSQL += `  '${escapeSQL(website.name)}',\n`;
    dataSQL += `  '${escapeSQL(JSON.stringify(website.data))}',\n`;
    dataSQL += `  '${website.createdAt.toISOString()}',\n`;
    dataSQL += `  '${website.updatedAt.toISOString()}'\n`;
    dataSQL += `);\n\n`;
    
    // Get all domains for this website
    const domains = await storage.getDomains(website.userId);
    const websiteDomains = domains.filter(domain => domain.websiteId === websiteId);
    
    if (websiteDomains.length > 0) {
      dataSQL += '-- Domains for this website\n';
      
      for (const domain of websiteDomains) {
        dataSQL += `INSERT INTO domains (id, "userId", "websiteId", subdomain, "customDomain", status, "verificationToken", "createdAt", "updatedAt") VALUES (\n`;
        dataSQL += `  ${domain.id},\n`;
        dataSQL += `  '${domain.userId}',\n`;
        dataSQL += `  ${domain.websiteId},\n`;
        dataSQL += `  ${domain.subdomain ? `'${escapeSQL(domain.subdomain)}'` : 'NULL'},\n`;
        dataSQL += `  ${domain.customDomain ? `'${escapeSQL(domain.customDomain)}'` : 'NULL'},\n`;
        dataSQL += `  '${domain.status}',\n`;
        dataSQL += `  ${domain.verificationToken ? `'${domain.verificationToken}'` : 'NULL'},\n`;
        dataSQL += `  '${domain.createdAt.toISOString()}',\n`;
        dataSQL += `  '${domain.updatedAt.toISOString()}'\n`;
        dataSQL += `);\n`;
      }
    }
    
    return dataSQL;
  } catch (error) {
    console.error('Error generating website data SQL:', error);
    return '-- Error generating website data';
  }
}

// Escape SQL special characters
function escapeSQL(text: string): string {
  return text.replace(/'/g, "''");
}

// Export tables as CSV files
async function exportAsCsv(websiteId: number, exportDir: string): Promise<void> {
  try {
    const csvDir = path.join(exportDir, 'csv');
    await mkdirAsync(csvDir, { recursive: true });
    
    // Export website data
    const website = await storage.getWebsiteById(websiteId);
    
    if (!website) {
      return;
    }
    
    // Export websites table
    const websiteCsvWriter = createObjectCsvWriter({
      path: path.join(csvDir, 'websites.csv'),
      header: [
        { id: 'id', title: 'id' },
        { id: 'userId', title: 'userId' },
        { id: 'name', title: 'name' },
        { id: 'data', title: 'data' },
        { id: 'createdAt', title: 'createdAt' },
        { id: 'updatedAt', title: 'updatedAt' }
      ]
    });
    
    await websiteCsvWriter.writeRecords([{
      id: website.id,
      userId: website.userId,
      name: website.name,
      data: JSON.stringify(website.data),
      createdAt: website.createdAt.toISOString(),
      updatedAt: website.updatedAt.toISOString()
    }]);
    
    // Export domains
    const domains = await storage.getDomains(website.userId);
    const websiteDomains = domains.filter(domain => domain.websiteId === websiteId);
    
    if (websiteDomains.length > 0) {
      const domainsCsvWriter = createObjectCsvWriter({
        path: path.join(csvDir, 'domains.csv'),
        header: [
          { id: 'id', title: 'id' },
          { id: 'userId', title: 'userId' },
          { id: 'websiteId', title: 'websiteId' },
          { id: 'subdomain', title: 'subdomain' },
          { id: 'customDomain', title: 'customDomain' },
          { id: 'status', title: 'status' },
          { id: 'verificationToken', title: 'verificationToken' },
          { id: 'createdAt', title: 'createdAt' },
          { id: 'updatedAt', title: 'updatedAt' }
        ]
      });
      
      await domainsCsvWriter.writeRecords(websiteDomains.map(domain => ({
        id: domain.id,
        userId: domain.userId,
        websiteId: domain.websiteId,
        subdomain: domain.subdomain,
        customDomain: domain.customDomain,
        status: domain.status,
        verificationToken: domain.verificationToken,
        createdAt: domain.createdAt.toISOString(),
        updatedAt: domain.updatedAt.toISOString()
      })));
    }
  } catch (error) {
    console.error('Error exporting CSV files:', error);
    throw error;
  }
}

export default router;