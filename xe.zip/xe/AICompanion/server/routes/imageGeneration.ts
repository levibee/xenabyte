import { Router } from "express";
import OpenAI from "openai";
import { z } from "zod";
import { storage } from "../storage";
import { isAuthenticated } from "../replitAuth";

// Image generation schema validation
const imageGenerationSchema = z.object({
  prompt: z.string().min(1).max(1000),
  size: z.enum(["256x256", "512x512", "1024x1024", "1024x1792", "1792x1024"]).default("1024x1024"),
  style: z.enum(["natural", "vivid"]).default("vivid"),
  quality: z.enum(["standard", "hd"]).default("standard"),
});

// Image credits schema for database
const imageCreditsSchema = z.object({
  userId: z.string(),
  used: z.number().int().min(0),
  limit: z.number().int().min(0),
  resetDate: z.date(),
});

const router = Router();

// Initialize OpenAI client
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

// Generate image endpoint
router.post("/generate-image", isAuthenticated, async (req: any, res) => {
  try {
    // Validate request body
    const validationResult = imageGenerationSchema.safeParse(req.body);
    if (!validationResult.success) {
      return res.status(400).json({
        error: "Invalid request parameters",
        details: validationResult.error.format(),
      });
    }

    const { prompt, size, style, quality } = validationResult.data;
    const userId = req.user.claims.sub;

    // Check user's image generation credits
    const credits = await getImageCredits(userId);
    
    if (credits.remaining <= 0) {
      return res.status(403).json({
        error: "Image generation limit reached",
        message: "You've reached your monthly limit for AI image generation. Please upgrade your plan or wait until your credits reset.",
        resetDate: credits.resetDate,
      });
    }

    // The newest OpenAI model is "gpt-4o" which was released May 13, 2024
    // Generate image using OpenAI API
    const response = await openai.images.generate({
      model: "dall-e-3",
      prompt,
      n: 1,
      size,
      style,
      quality,
    });

    // Update user's image generation count
    await updateImageCredits(userId);

    // Get updated credits
    const updatedCredits = await getImageCredits(userId);

    // Return the generated image URL
    return res.status(200).json({
      url: response.data[0].url,
      generatedAt: new Date().toISOString(),
      prompt,
      size,
      credits: {
        remaining: updatedCredits.remaining,
        limit: updatedCredits.limit,
      },
    });
  } catch (error: any) {
    console.error("Image generation error:", error);
    return res.status(500).json({
      error: "Failed to generate image",
      message: error.message || "An unexpected error occurred",
    });
  }
});

// Get current user's image credits
router.get("/image-credits", isAuthenticated, async (req: any, res) => {
  try {
    const userId = req.user.claims.sub;
    const credits = await getImageCredits(userId);
    
    return res.status(200).json(credits);
  } catch (error: any) {
    console.error("Error fetching image credits:", error);
    return res.status(500).json({
      error: "Failed to fetch image credits",
      message: error.message || "An unexpected error occurred",
    });
  }
});

// Helper function to get user's image generation credits
async function getImageCredits(userId: string) {
  // Get user subscription
  const user = await storage.getUser(userId);
  if (!user) {
    throw new Error("User not found");
  }

  // Set limit based on subscription tier
  let limit = 5; // Default for free tier
  if (user.subscriptionTier === "premium") {
    limit = 50;
  } else if (user.subscriptionTier === "enterprise") {
    limit = 1000; // Practically unlimited
  }

  // Try to get existing image credits record
  let imageCreditsRecord = await storage.getImageCredits(userId);
  
  // If no record exists or it's a new month, create/reset the record
  const now = new Date();
  if (!imageCreditsRecord || isNewMonth(imageCreditsRecord.resetDate, now)) {
    // Calculate next reset date (1st of next month)
    const resetDate = new Date(now.getFullYear(), now.getMonth() + 1, 1);
    
    // Create or reset record
    imageCreditsRecord = await storage.upsertImageCredits({
      userId,
      used: 0,
      limit,
      resetDate,
    });
  }

  return {
    used: imageCreditsRecord.used,
    limit: imageCreditsRecord.limit,
    remaining: Math.max(0, imageCreditsRecord.limit - imageCreditsRecord.used),
    resetDate: imageCreditsRecord.resetDate.toISOString(),
  };
}

// Helper function to update user's image generation count
async function updateImageCredits(userId: string) {
  const credits = await getImageCredits(userId);
  
  if (credits.remaining <= 0) {
    throw new Error("Image generation limit reached");
  }
  
  await storage.incrementImageCreditsUsed(userId);
}

// Helper function to check if it's a new month since the last reset
function isNewMonth(resetDate: Date, currentDate: Date): boolean {
  return (
    resetDate.getMonth() !== currentDate.getMonth() ||
    resetDate.getFullYear() !== currentDate.getFullYear()
  );
}

export default router;